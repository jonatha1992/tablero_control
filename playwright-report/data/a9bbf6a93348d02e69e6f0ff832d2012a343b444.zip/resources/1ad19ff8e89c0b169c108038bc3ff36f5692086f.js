(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_sonner_dist_index_mjs_07zdd2m._.js",
  "static/chunks/node_modules_sonner_dist_index_mjs_02vveac._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);