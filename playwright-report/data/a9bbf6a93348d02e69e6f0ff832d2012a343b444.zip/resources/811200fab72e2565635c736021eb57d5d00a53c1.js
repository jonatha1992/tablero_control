(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0vpswnh._.js","static/chunks/node_modules_@dnd-kit_core_dist_core_esm_0avyu8m.js","static/chunks/node_modules_@fullcalendar_core_0n18y-m._.js","static/chunks/node_modules_@fullcalendar_interaction_index_09-uoq8.js","static/chunks/node_modules_0wuvfkc._.js"],
    source: "dynamic"
});
