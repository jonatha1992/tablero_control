(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@dnd-kit/utilities/dist/utilities.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CSS",
    ()=>CSS,
    "add",
    ()=>add,
    "canUseDOM",
    ()=>canUseDOM,
    "findFirstFocusableNode",
    ()=>findFirstFocusableNode,
    "getEventCoordinates",
    ()=>getEventCoordinates,
    "getOwnerDocument",
    ()=>getOwnerDocument,
    "getWindow",
    ()=>getWindow,
    "hasViewportRelativeCoordinates",
    ()=>hasViewportRelativeCoordinates,
    "isDocument",
    ()=>isDocument,
    "isHTMLElement",
    ()=>isHTMLElement,
    "isKeyboardEvent",
    ()=>isKeyboardEvent,
    "isNode",
    ()=>isNode,
    "isSVGElement",
    ()=>isSVGElement,
    "isTouchEvent",
    ()=>isTouchEvent,
    "isWindow",
    ()=>isWindow,
    "subtract",
    ()=>subtract,
    "useCombinedRefs",
    ()=>useCombinedRefs,
    "useEvent",
    ()=>useEvent,
    "useInterval",
    ()=>useInterval,
    "useIsomorphicLayoutEffect",
    ()=>useIsomorphicLayoutEffect,
    "useLatestValue",
    ()=>useLatestValue,
    "useLazyMemo",
    ()=>useLazyMemo,
    "useNodeRef",
    ()=>useNodeRef,
    "usePrevious",
    ()=>usePrevious,
    "useUniqueId",
    ()=>useUniqueId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function useCombinedRefs() {
    for(var _len = arguments.length, refs = new Array(_len), _key = 0; _key < _len; _key++){
        refs[_key] = arguments[_key];
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useCombinedRefs.useMemo": ()=>({
                "useCombinedRefs.useMemo": (node)=>{
                    refs.forEach({
                        "useCombinedRefs.useMemo": (ref)=>ref(node)
                    }["useCombinedRefs.useMemo"]);
                }
            })["useCombinedRefs.useMemo"]
    }["useCombinedRefs.useMemo"], refs);
}
// https://github.com/facebook/react/blob/master/packages/shared/ExecutionEnvironment.js
const canUseDOM = typeof window !== 'undefined' && typeof window.document !== 'undefined' && typeof window.document.createElement !== 'undefined';
function isWindow(element) {
    const elementString = Object.prototype.toString.call(element);
    return elementString === '[object Window]' || // In Electron context the Window object serializes to [object global]
    elementString === '[object global]';
}
function isNode(node) {
    return 'nodeType' in node;
}
function getWindow(target) {
    var _target$ownerDocument, _target$ownerDocument2;
    if (!target) {
        return window;
    }
    if (isWindow(target)) {
        return target;
    }
    if (!isNode(target)) {
        return window;
    }
    return (_target$ownerDocument = (_target$ownerDocument2 = target.ownerDocument) == null ? void 0 : _target$ownerDocument2.defaultView) != null ? _target$ownerDocument : window;
}
function isDocument(node) {
    const { Document } = getWindow(node);
    return node instanceof Document;
}
function isHTMLElement(node) {
    if (isWindow(node)) {
        return false;
    }
    return node instanceof getWindow(node).HTMLElement;
}
function isSVGElement(node) {
    return node instanceof getWindow(node).SVGElement;
}
function getOwnerDocument(target) {
    if (!target) {
        return document;
    }
    if (isWindow(target)) {
        return target.document;
    }
    if (!isNode(target)) {
        return document;
    }
    if (isDocument(target)) {
        return target;
    }
    if (isHTMLElement(target) || isSVGElement(target)) {
        return target.ownerDocument;
    }
    return document;
}
/**
 * A hook that resolves to useEffect on the server and useLayoutEffect on the client
 * @param callback {function} Callback function that is invoked when the dependencies of the hook change
 */ const useIsomorphicLayoutEffect = canUseDOM ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"];
function useEvent(handler) {
    const handlerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(handler);
    useIsomorphicLayoutEffect({
        "useEvent.useIsomorphicLayoutEffect": ()=>{
            handlerRef.current = handler;
        }
    }["useEvent.useIsomorphicLayoutEffect"]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useEvent.useCallback": function() {
            for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                args[_key] = arguments[_key];
            }
            return handlerRef.current == null ? void 0 : handlerRef.current(...args);
        }
    }["useEvent.useCallback"], []);
}
function useInterval() {
    const intervalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const set = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useInterval.useCallback[set]": (listener, duration)=>{
            intervalRef.current = setInterval(listener, duration);
        }
    }["useInterval.useCallback[set]"], []);
    const clear = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useInterval.useCallback[clear]": ()=>{
            if (intervalRef.current !== null) {
                clearInterval(intervalRef.current);
                intervalRef.current = null;
            }
        }
    }["useInterval.useCallback[clear]"], []);
    return [
        set,
        clear
    ];
}
function useLatestValue(value, dependencies) {
    if (dependencies === void 0) {
        dependencies = [
            value
        ];
    }
    const valueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    useIsomorphicLayoutEffect({
        "useLatestValue.useIsomorphicLayoutEffect": ()=>{
            if (valueRef.current !== value) {
                valueRef.current = value;
            }
        }
    }["useLatestValue.useIsomorphicLayoutEffect"], dependencies);
    return valueRef;
}
function useLazyMemo(callback, dependencies) {
    const valueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useLazyMemo.useMemo": ()=>{
            const newValue = callback(valueRef.current);
            valueRef.current = newValue;
            return newValue;
        }
    }["useLazyMemo.useMemo"], [
        ...dependencies
    ]);
}
function useNodeRef(onChange) {
    const onChangeHandler = useEvent(onChange);
    const node = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const setNodeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useNodeRef.useCallback[setNodeRef]": (element)=>{
            if (element !== node.current) {
                onChangeHandler == null ? void 0 : onChangeHandler(element, node.current);
            }
            node.current = element;
        }
    }["useNodeRef.useCallback[setNodeRef]"], []);
    return [
        node,
        setNodeRef
    ];
}
function usePrevious(value) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePrevious.useEffect": ()=>{
            ref.current = value;
        }
    }["usePrevious.useEffect"], [
        value
    ]);
    return ref.current;
}
let ids = {};
function useUniqueId(prefix, value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useUniqueId.useMemo": ()=>{
            if (value) {
                return value;
            }
            const id = ids[prefix] == null ? 0 : ids[prefix] + 1;
            ids[prefix] = id;
            return prefix + "-" + id;
        }
    }["useUniqueId.useMemo"], [
        prefix,
        value
    ]);
}
function createAdjustmentFn(modifier) {
    return function(object) {
        for(var _len = arguments.length, adjustments = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            adjustments[_key - 1] = arguments[_key];
        }
        return adjustments.reduce((accumulator, adjustment)=>{
            const entries = Object.entries(adjustment);
            for (const [key, valueAdjustment] of entries){
                const value = accumulator[key];
                if (value != null) {
                    accumulator[key] = value + modifier * valueAdjustment;
                }
            }
            return accumulator;
        }, {
            ...object
        });
    };
}
const add = /*#__PURE__*/ createAdjustmentFn(1);
const subtract = /*#__PURE__*/ createAdjustmentFn(-1);
function hasViewportRelativeCoordinates(event) {
    return 'clientX' in event && 'clientY' in event;
}
function isKeyboardEvent(event) {
    if (!event) {
        return false;
    }
    const { KeyboardEvent } = getWindow(event.target);
    return KeyboardEvent && event instanceof KeyboardEvent;
}
function isTouchEvent(event) {
    if (!event) {
        return false;
    }
    const { TouchEvent } = getWindow(event.target);
    return TouchEvent && event instanceof TouchEvent;
}
/**
 * Returns the normalized x and y coordinates for mouse and touch events.
 */ function getEventCoordinates(event) {
    if (isTouchEvent(event)) {
        if (event.touches && event.touches.length) {
            const { clientX: x, clientY: y } = event.touches[0];
            return {
                x,
                y
            };
        } else if (event.changedTouches && event.changedTouches.length) {
            const { clientX: x, clientY: y } = event.changedTouches[0];
            return {
                x,
                y
            };
        }
    }
    if (hasViewportRelativeCoordinates(event)) {
        return {
            x: event.clientX,
            y: event.clientY
        };
    }
    return null;
}
const CSS = /*#__PURE__*/ Object.freeze({
    Translate: {
        toString (transform) {
            if (!transform) {
                return;
            }
            const { x, y } = transform;
            return "translate3d(" + (x ? Math.round(x) : 0) + "px, " + (y ? Math.round(y) : 0) + "px, 0)";
        }
    },
    Scale: {
        toString (transform) {
            if (!transform) {
                return;
            }
            const { scaleX, scaleY } = transform;
            return "scaleX(" + scaleX + ") scaleY(" + scaleY + ")";
        }
    },
    Transform: {
        toString (transform) {
            if (!transform) {
                return;
            }
            return [
                CSS.Translate.toString(transform),
                CSS.Scale.toString(transform)
            ].join(' ');
        }
    },
    Transition: {
        toString (_ref) {
            let { property, duration, easing } = _ref;
            return property + " " + duration + "ms " + easing;
        }
    }
});
const SELECTOR = 'a,frame,iframe,input:not([type=hidden]):not(:disabled),select:not(:disabled),textarea:not(:disabled),button:not(:disabled),*[tabindex]';
function findFirstFocusableNode(element) {
    if (element.matches(SELECTOR)) {
        return element;
    }
    return element.querySelector(SELECTOR);
}
;
}),
"[project]/node_modules/@dnd-kit/accessibility/dist/accessibility.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HiddenText",
    ()=>HiddenText,
    "LiveRegion",
    ()=>LiveRegion,
    "useAnnouncement",
    ()=>useAnnouncement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
const hiddenStyles = {
    display: 'none'
};
function HiddenText(_ref) {
    let { id, value } = _ref;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        id: id,
        style: hiddenStyles
    }, value);
}
function LiveRegion(_ref) {
    let { id, announcement, ariaLiveType = "assertive" } = _ref;
    // Hide element visually but keep it readable by screen readers
    const visuallyHidden = {
        position: 'fixed',
        top: 0,
        left: 0,
        width: 1,
        height: 1,
        margin: -1,
        border: 0,
        padding: 0,
        overflow: 'hidden',
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(100%)',
        whiteSpace: 'nowrap'
    };
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
        id: id,
        style: visuallyHidden,
        role: "status",
        "aria-live": ariaLiveType,
        "aria-atomic": true
    }, announcement);
}
function useAnnouncement() {
    const [announcement, setAnnouncement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const announce = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useAnnouncement.useCallback[announce]": (value)=>{
            if (value != null) {
                setAnnouncement(value);
            }
        }
    }["useAnnouncement.useCallback[announce]"], []);
    return {
        announce,
        announcement
    };
}
;
}),
"[project]/node_modules/@dnd-kit/sortable/dist/sortable.esm.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SortableContext",
    ()=>SortableContext,
    "arrayMove",
    ()=>arrayMove,
    "arraySwap",
    ()=>arraySwap,
    "defaultAnimateLayoutChanges",
    ()=>defaultAnimateLayoutChanges,
    "defaultNewIndexGetter",
    ()=>defaultNewIndexGetter,
    "hasSortableData",
    ()=>hasSortableData,
    "horizontalListSortingStrategy",
    ()=>horizontalListSortingStrategy,
    "rectSortingStrategy",
    ()=>rectSortingStrategy,
    "rectSwappingStrategy",
    ()=>rectSwappingStrategy,
    "sortableKeyboardCoordinates",
    ()=>sortableKeyboardCoordinates,
    "useSortable",
    ()=>useSortable,
    "verticalListSortingStrategy",
    ()=>verticalListSortingStrategy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dnd-kit/core/dist/core.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dnd-kit/utilities/dist/utilities.esm.js [app-client] (ecmascript)");
;
;
;
/**
 * Move an array item to a different position. Returns a new array with the item moved to the new position.
 */ function arrayMove(array, from, to) {
    const newArray = array.slice();
    newArray.splice(to < 0 ? newArray.length + to : to, 0, newArray.splice(from, 1)[0]);
    return newArray;
}
/**
 * Swap an array item to a different position. Returns a new array with the item swapped to the new position.
 */ function arraySwap(array, from, to) {
    const newArray = array.slice();
    newArray[from] = array[to];
    newArray[to] = array[from];
    return newArray;
}
function getSortedRects(items, rects) {
    return items.reduce((accumulator, id, index)=>{
        const rect = rects.get(id);
        if (rect) {
            accumulator[index] = rect;
        }
        return accumulator;
    }, Array(items.length));
}
function isValidIndex(index) {
    return index !== null && index >= 0;
}
function itemsEqual(a, b) {
    if (a === b) {
        return true;
    }
    if (a.length !== b.length) {
        return false;
    }
    for(let i = 0; i < a.length; i++){
        if (a[i] !== b[i]) {
            return false;
        }
    }
    return true;
}
function normalizeDisabled(disabled) {
    if (typeof disabled === 'boolean') {
        return {
            draggable: disabled,
            droppable: disabled
        };
    }
    return disabled;
}
// To-do: We should be calculating scale transformation
const defaultScale = {
    scaleX: 1,
    scaleY: 1
};
const horizontalListSortingStrategy = (_ref)=>{
    var _rects$activeIndex;
    let { rects, activeNodeRect: fallbackActiveRect, activeIndex, overIndex, index } = _ref;
    const activeNodeRect = (_rects$activeIndex = rects[activeIndex]) != null ? _rects$activeIndex : fallbackActiveRect;
    if (!activeNodeRect) {
        return null;
    }
    const itemGap = getItemGap(rects, index, activeIndex);
    if (index === activeIndex) {
        const newIndexRect = rects[overIndex];
        if (!newIndexRect) {
            return null;
        }
        return {
            x: activeIndex < overIndex ? newIndexRect.left + newIndexRect.width - (activeNodeRect.left + activeNodeRect.width) : newIndexRect.left - activeNodeRect.left,
            y: 0,
            ...defaultScale
        };
    }
    if (index > activeIndex && index <= overIndex) {
        return {
            x: -activeNodeRect.width - itemGap,
            y: 0,
            ...defaultScale
        };
    }
    if (index < activeIndex && index >= overIndex) {
        return {
            x: activeNodeRect.width + itemGap,
            y: 0,
            ...defaultScale
        };
    }
    return {
        x: 0,
        y: 0,
        ...defaultScale
    };
};
function getItemGap(rects, index, activeIndex) {
    const currentRect = rects[index];
    const previousRect = rects[index - 1];
    const nextRect = rects[index + 1];
    if (!currentRect || !previousRect && !nextRect) {
        return 0;
    }
    if (activeIndex < index) {
        return previousRect ? currentRect.left - (previousRect.left + previousRect.width) : nextRect.left - (currentRect.left + currentRect.width);
    }
    return nextRect ? nextRect.left - (currentRect.left + currentRect.width) : currentRect.left - (previousRect.left + previousRect.width);
}
const rectSortingStrategy = (_ref)=>{
    let { rects, activeIndex, overIndex, index } = _ref;
    const newRects = arrayMove(rects, overIndex, activeIndex);
    const oldRect = rects[index];
    const newRect = newRects[index];
    if (!newRect || !oldRect) {
        return null;
    }
    return {
        x: newRect.left - oldRect.left,
        y: newRect.top - oldRect.top,
        scaleX: newRect.width / oldRect.width,
        scaleY: newRect.height / oldRect.height
    };
};
const rectSwappingStrategy = (_ref)=>{
    let { activeIndex, index, rects, overIndex } = _ref;
    let oldRect;
    let newRect;
    if (index === activeIndex) {
        oldRect = rects[index];
        newRect = rects[overIndex];
    }
    if (index === overIndex) {
        oldRect = rects[index];
        newRect = rects[activeIndex];
    }
    if (!newRect || !oldRect) {
        return null;
    }
    return {
        x: newRect.left - oldRect.left,
        y: newRect.top - oldRect.top,
        scaleX: newRect.width / oldRect.width,
        scaleY: newRect.height / oldRect.height
    };
};
// To-do: We should be calculating scale transformation
const defaultScale$1 = {
    scaleX: 1,
    scaleY: 1
};
const verticalListSortingStrategy = (_ref)=>{
    var _rects$activeIndex;
    let { activeIndex, activeNodeRect: fallbackActiveRect, index, rects, overIndex } = _ref;
    const activeNodeRect = (_rects$activeIndex = rects[activeIndex]) != null ? _rects$activeIndex : fallbackActiveRect;
    if (!activeNodeRect) {
        return null;
    }
    if (index === activeIndex) {
        const overIndexRect = rects[overIndex];
        if (!overIndexRect) {
            return null;
        }
        return {
            x: 0,
            y: activeIndex < overIndex ? overIndexRect.top + overIndexRect.height - (activeNodeRect.top + activeNodeRect.height) : overIndexRect.top - activeNodeRect.top,
            ...defaultScale$1
        };
    }
    const itemGap = getItemGap$1(rects, index, activeIndex);
    if (index > activeIndex && index <= overIndex) {
        return {
            x: 0,
            y: -activeNodeRect.height - itemGap,
            ...defaultScale$1
        };
    }
    if (index < activeIndex && index >= overIndex) {
        return {
            x: 0,
            y: activeNodeRect.height + itemGap,
            ...defaultScale$1
        };
    }
    return {
        x: 0,
        y: 0,
        ...defaultScale$1
    };
};
function getItemGap$1(clientRects, index, activeIndex) {
    const currentRect = clientRects[index];
    const previousRect = clientRects[index - 1];
    const nextRect = clientRects[index + 1];
    if (!currentRect) {
        return 0;
    }
    if (activeIndex < index) {
        return previousRect ? currentRect.top - (previousRect.top + previousRect.height) : nextRect ? nextRect.top - (currentRect.top + currentRect.height) : 0;
    }
    return nextRect ? nextRect.top - (currentRect.top + currentRect.height) : previousRect ? currentRect.top - (previousRect.top + previousRect.height) : 0;
}
const ID_PREFIX = 'Sortable';
const Context = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createContext({
    activeIndex: -1,
    containerId: ID_PREFIX,
    disableTransforms: false,
    items: [],
    overIndex: -1,
    useDragOverlay: false,
    sortedRects: [],
    strategy: rectSortingStrategy,
    disabled: {
        draggable: false,
        droppable: false
    }
});
function SortableContext(_ref) {
    let { children, id, items: userDefinedItems, strategy = rectSortingStrategy, disabled: disabledProp = false } = _ref;
    const { active, dragOverlay, droppableRects, over, measureDroppableContainers } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDndContext"])();
    const containerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUniqueId"])(ID_PREFIX, id);
    const useDragOverlay = Boolean(dragOverlay.rect !== null);
    const items = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SortableContext.useMemo[items]": ()=>userDefinedItems.map({
                "SortableContext.useMemo[items]": (item)=>typeof item === 'object' && 'id' in item ? item.id : item
            }["SortableContext.useMemo[items]"])
    }["SortableContext.useMemo[items]"], [
        userDefinedItems
    ]);
    const isDragging = active != null;
    const activeIndex = active ? items.indexOf(active.id) : -1;
    const overIndex = over ? items.indexOf(over.id) : -1;
    const previousItemsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(items);
    const itemsHaveChanged = !itemsEqual(items, previousItemsRef.current);
    const disableTransforms = overIndex !== -1 && activeIndex === -1 || itemsHaveChanged;
    const disabled = normalizeDisabled(disabledProp);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsomorphicLayoutEffect"])({
        "SortableContext.useIsomorphicLayoutEffect": ()=>{
            if (itemsHaveChanged && isDragging) {
                measureDroppableContainers(items);
            }
        }
    }["SortableContext.useIsomorphicLayoutEffect"], [
        itemsHaveChanged,
        items,
        isDragging,
        measureDroppableContainers
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SortableContext.useEffect": ()=>{
            previousItemsRef.current = items;
        }
    }["SortableContext.useEffect"], [
        items
    ]);
    const contextValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SortableContext.useMemo[contextValue]": ()=>({
                activeIndex,
                containerId,
                disabled,
                disableTransforms,
                items,
                overIndex,
                useDragOverlay,
                sortedRects: getSortedRects(items, droppableRects),
                strategy
            })
    }["SortableContext.useMemo[contextValue]"], [
        activeIndex,
        containerId,
        disabled.draggable,
        disabled.droppable,
        disableTransforms,
        items,
        overIndex,
        droppableRects,
        useDragOverlay,
        strategy
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(Context.Provider, {
        value: contextValue
    }, children);
}
const defaultNewIndexGetter = (_ref)=>{
    let { id, items, activeIndex, overIndex } = _ref;
    return arrayMove(items, activeIndex, overIndex).indexOf(id);
};
const defaultAnimateLayoutChanges = (_ref2)=>{
    let { containerId, isSorting, wasDragging, index, items, newIndex, previousItems, previousContainerId, transition } = _ref2;
    if (!transition || !wasDragging) {
        return false;
    }
    if (previousItems !== items && index === newIndex) {
        return false;
    }
    if (isSorting) {
        return true;
    }
    return newIndex !== index && containerId === previousContainerId;
};
const defaultTransition = {
    duration: 200,
    easing: 'ease'
};
const transitionProperty = 'transform';
const disabledTransition = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS"].Transition.toString({
    property: transitionProperty,
    duration: 0,
    easing: 'linear'
});
const defaultAttributes = {
    roleDescription: 'sortable'
};
/*
 * When the index of an item changes while sorting,
 * we need to temporarily disable the transforms
 */ function useDerivedTransform(_ref) {
    let { disabled, index, node, rect } = _ref;
    const [derivedTransform, setDerivedtransform] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const previousIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(index);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsomorphicLayoutEffect"])({
        "useDerivedTransform.useIsomorphicLayoutEffect": ()=>{
            if (!disabled && index !== previousIndex.current && node.current) {
                const initial = rect.current;
                if (initial) {
                    const current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientRect"])(node.current, {
                        ignoreTransform: true
                    });
                    const delta = {
                        x: initial.left - current.left,
                        y: initial.top - current.top,
                        scaleX: initial.width / current.width,
                        scaleY: initial.height / current.height
                    };
                    if (delta.x || delta.y) {
                        setDerivedtransform(delta);
                    }
                }
            }
            if (index !== previousIndex.current) {
                previousIndex.current = index;
            }
        }
    }["useDerivedTransform.useIsomorphicLayoutEffect"], [
        disabled,
        index,
        node,
        rect
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDerivedTransform.useEffect": ()=>{
            if (derivedTransform) {
                setDerivedtransform(null);
            }
        }
    }["useDerivedTransform.useEffect"], [
        derivedTransform
    ]);
    return derivedTransform;
}
function useSortable(_ref) {
    let { animateLayoutChanges = defaultAnimateLayoutChanges, attributes: userDefinedAttributes, disabled: localDisabled, data: customData, getNewIndex = defaultNewIndexGetter, id, strategy: localStrategy, resizeObserverConfig, transition = defaultTransition } = _ref;
    const { items, containerId, activeIndex, disabled: globalDisabled, disableTransforms, sortedRects, overIndex, useDragOverlay, strategy: globalStrategy } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Context);
    const disabled = normalizeLocalDisabled(localDisabled, globalDisabled);
    const index = items.indexOf(id);
    const data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useSortable.useMemo[data]": ()=>({
                sortable: {
                    containerId,
                    index,
                    items
                },
                ...customData
            })
    }["useSortable.useMemo[data]"], [
        containerId,
        customData,
        index,
        items
    ]);
    const itemsAfterCurrentSortable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useSortable.useMemo[itemsAfterCurrentSortable]": ()=>items.slice(items.indexOf(id))
    }["useSortable.useMemo[itemsAfterCurrentSortable]"], [
        items,
        id
    ]);
    const { rect, node, isOver, setNodeRef: setDroppableNodeRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDroppable"])({
        id,
        data,
        disabled: disabled.droppable,
        resizeObserverConfig: {
            updateMeasurementsFor: itemsAfterCurrentSortable,
            ...resizeObserverConfig
        }
    });
    const { active, activatorEvent, activeNodeRect, attributes, setNodeRef: setDraggableNodeRef, listeners, isDragging, over, setActivatorNodeRef, transform } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDraggable"])({
        id,
        data,
        attributes: {
            ...defaultAttributes,
            ...userDefinedAttributes
        },
        disabled: disabled.draggable
    });
    const setNodeRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCombinedRefs"])(setDroppableNodeRef, setDraggableNodeRef);
    const isSorting = Boolean(active);
    const displaceItem = isSorting && !disableTransforms && isValidIndex(activeIndex) && isValidIndex(overIndex);
    const shouldDisplaceDragSource = !useDragOverlay && isDragging;
    const dragSourceDisplacement = shouldDisplaceDragSource && displaceItem ? transform : null;
    const strategy = localStrategy != null ? localStrategy : globalStrategy;
    const finalTransform = displaceItem ? dragSourceDisplacement != null ? dragSourceDisplacement : strategy({
        rects: sortedRects,
        activeNodeRect,
        activeIndex,
        overIndex,
        index
    }) : null;
    const newIndex = isValidIndex(activeIndex) && isValidIndex(overIndex) ? getNewIndex({
        id,
        items,
        activeIndex,
        overIndex
    }) : index;
    const activeId = active == null ? void 0 : active.id;
    const previous = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        activeId,
        items,
        newIndex,
        containerId
    });
    const itemsHaveChanged = items !== previous.current.items;
    const shouldAnimateLayoutChanges = animateLayoutChanges({
        active,
        containerId,
        isDragging,
        isSorting,
        id,
        index,
        items,
        newIndex: previous.current.newIndex,
        previousItems: previous.current.items,
        previousContainerId: previous.current.containerId,
        transition,
        wasDragging: previous.current.activeId != null
    });
    const derivedTransform = useDerivedTransform({
        disabled: !shouldAnimateLayoutChanges,
        index,
        node,
        rect
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useSortable.useEffect": ()=>{
            if (isSorting && previous.current.newIndex !== newIndex) {
                previous.current.newIndex = newIndex;
            }
            if (containerId !== previous.current.containerId) {
                previous.current.containerId = containerId;
            }
            if (items !== previous.current.items) {
                previous.current.items = items;
            }
        }
    }["useSortable.useEffect"], [
        isSorting,
        newIndex,
        containerId,
        items
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useSortable.useEffect": ()=>{
            if (activeId === previous.current.activeId) {
                return;
            }
            if (activeId != null && previous.current.activeId == null) {
                previous.current.activeId = activeId;
                return;
            }
            const timeoutId = setTimeout({
                "useSortable.useEffect.timeoutId": ()=>{
                    previous.current.activeId = activeId;
                }
            }["useSortable.useEffect.timeoutId"], 50);
            return ({
                "useSortable.useEffect": ()=>clearTimeout(timeoutId)
            })["useSortable.useEffect"];
        }
    }["useSortable.useEffect"], [
        activeId
    ]);
    return {
        active,
        activeIndex,
        attributes,
        data,
        rect,
        index,
        newIndex,
        items,
        isOver,
        isSorting,
        isDragging,
        listeners,
        node,
        overIndex,
        over,
        setNodeRef,
        setActivatorNodeRef,
        setDroppableNodeRef,
        setDraggableNodeRef,
        transform: derivedTransform != null ? derivedTransform : finalTransform,
        transition: getTransition()
    };
    //TURBOPACK unreachable
    ;
    function getTransition() {
        if (derivedTransform || // Or to prevent items jumping to back to their "new" position when items change
        itemsHaveChanged && previous.current.newIndex === index) {
            return disabledTransition;
        }
        if (shouldDisplaceDragSource && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isKeyboardEvent"])(activatorEvent) || !transition) {
            return undefined;
        }
        if (isSorting || shouldAnimateLayoutChanges) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS"].Transition.toString({
                ...transition,
                property: transitionProperty
            });
        }
        return undefined;
    }
}
function normalizeLocalDisabled(localDisabled, globalDisabled) {
    var _localDisabled$dragga, _localDisabled$droppa;
    if (typeof localDisabled === 'boolean') {
        return {
            draggable: localDisabled,
            // Backwards compatibility
            droppable: false
        };
    }
    return {
        draggable: (_localDisabled$dragga = localDisabled == null ? void 0 : localDisabled.draggable) != null ? _localDisabled$dragga : globalDisabled.draggable,
        droppable: (_localDisabled$droppa = localDisabled == null ? void 0 : localDisabled.droppable) != null ? _localDisabled$droppa : globalDisabled.droppable
    };
}
function hasSortableData(entry) {
    if (!entry) {
        return false;
    }
    const data = entry.data.current;
    if (data && 'sortable' in data && typeof data.sortable === 'object' && 'containerId' in data.sortable && 'items' in data.sortable && 'index' in data.sortable) {
        return true;
    }
    return false;
}
const directions = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardCode"].Down,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardCode"].Right,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardCode"].Up,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardCode"].Left
];
const sortableKeyboardCoordinates = (event, _ref)=>{
    let { context: { active, collisionRect, droppableRects, droppableContainers, over, scrollableAncestors } } = _ref;
    if (directions.includes(event.code)) {
        event.preventDefault();
        if (!active || !collisionRect) {
            return;
        }
        const filteredContainers = [];
        droppableContainers.getEnabled().forEach((entry)=>{
            if (!entry || entry != null && entry.disabled) {
                return;
            }
            const rect = droppableRects.get(entry.id);
            if (!rect) {
                return;
            }
            switch(event.code){
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardCode"].Down:
                    if (collisionRect.top < rect.top) {
                        filteredContainers.push(entry);
                    }
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardCode"].Up:
                    if (collisionRect.top > rect.top) {
                        filteredContainers.push(entry);
                    }
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardCode"].Left:
                    if (collisionRect.left > rect.left) {
                        filteredContainers.push(entry);
                    }
                    break;
                case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardCode"].Right:
                    if (collisionRect.left < rect.left) {
                        filteredContainers.push(entry);
                    }
                    break;
            }
        });
        const collisions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["closestCorners"])({
            active,
            collisionRect: collisionRect,
            droppableRects,
            droppableContainers: filteredContainers,
            pointerCoordinates: null
        });
        let closestId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFirstCollision"])(collisions, 'id');
        if (closestId === (over == null ? void 0 : over.id) && collisions.length > 1) {
            closestId = collisions[1].id;
        }
        if (closestId != null) {
            const activeDroppable = droppableContainers.get(active.id);
            const newDroppable = droppableContainers.get(closestId);
            const newRect = newDroppable ? droppableRects.get(newDroppable.id) : null;
            const newNode = newDroppable == null ? void 0 : newDroppable.node.current;
            if (newNode && newRect && activeDroppable && newDroppable) {
                const newScrollAncestors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getScrollableAncestors"])(newNode);
                const hasDifferentScrollAncestors = newScrollAncestors.some((element, index)=>scrollableAncestors[index] !== element);
                const hasSameContainer = isSameContainer(activeDroppable, newDroppable);
                const isAfterActive = isAfter(activeDroppable, newDroppable);
                const offset = hasDifferentScrollAncestors || !hasSameContainer ? {
                    x: 0,
                    y: 0
                } : {
                    x: isAfterActive ? collisionRect.width - newRect.width : 0,
                    y: isAfterActive ? collisionRect.height - newRect.height : 0
                };
                const rectCoordinates = {
                    x: newRect.left,
                    y: newRect.top
                };
                const newCoordinates = offset.x && offset.y ? rectCoordinates : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subtract"])(rectCoordinates, offset);
                return newCoordinates;
            }
        }
    }
    return undefined;
};
function isSameContainer(a, b) {
    if (!hasSortableData(a) || !hasSortableData(b)) {
        return false;
    }
    return a.data.current.sortable.containerId === b.data.current.sortable.containerId;
}
function isAfter(a, b) {
    if (!hasSortableData(a) || !hasSortableData(b)) {
        return false;
    }
    if (!isSameContainer(a, b)) {
        return false;
    }
    return a.data.current.sortable.index < b.data.current.sortable.index;
}
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/funnel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Funnel
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",
            key: "sc7q7i"
        }
    ]
];
const Funnel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("funnel", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/funnel.js [app-client] (ecmascript) <export default as Filter>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Filter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/funnel.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/settings-2.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Settings2
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M14 17H5",
            key: "gfn3mx"
        }
    ],
    [
        "path",
        {
            d: "M19 7h-9",
            key: "6i9tg"
        }
    ],
    [
        "circle",
        {
            cx: "17",
            cy: "17",
            r: "3",
            key: "18b49y"
        }
    ],
    [
        "circle",
        {
            cx: "7",
            cy: "7",
            r: "3",
            key: "dfmy0x"
        }
    ]
];
const Settings2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("settings-2", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/settings-2.js [app-client] (ecmascript) <export default as Settings2>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Settings2",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/settings-2.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Trash2
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M10 11v6",
            key: "nco0om"
        }
    ],
    [
        "path",
        {
            d: "M14 11v6",
            key: "outv1u"
        }
    ],
    [
        "path",
        {
            d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
            key: "miytrc"
        }
    ],
    [
        "path",
        {
            d: "M3 6h18",
            key: "d0wm0j"
        }
    ],
    [
        "path",
        {
            d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
            key: "e791ji"
        }
    ]
];
const Trash2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("trash-2", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript) <export default as Trash2>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Trash2",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>TriangleAlert
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
            key: "wmoenq"
        }
    ],
    [
        "path",
        {
            d: "M12 9v4",
            key: "juzpu7"
        }
    ],
    [
        "path",
        {
            d: "M12 17h.01",
            key: "p32p05"
        }
    ]
];
const TriangleAlert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("triangle-alert", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-client] (ecmascript) <export default as AlertTriangle>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AlertTriangle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/house.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>House
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",
            key: "5wwlr5"
        }
    ],
    [
        "path",
        {
            d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
            key: "r6nss1"
        }
    ]
];
const House = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("house", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/house.js [app-client] (ecmascript) <export default as Home>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Home",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/house.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/store.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Store
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M15 21v-5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5",
            key: "slp6dd"
        }
    ],
    [
        "path",
        {
            d: "M17.774 10.31a1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.451 0 1.12 1.12 0 0 0-1.548 0 2.5 2.5 0 0 1-3.452 0 1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.77-3.248l2.889-4.184A2 2 0 0 1 7 2h10a2 2 0 0 1 1.653.873l2.895 4.192a2.5 2.5 0 0 1-3.774 3.244",
            key: "o0xfot"
        }
    ],
    [
        "path",
        {
            d: "M4 10.95V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8.05",
            key: "wn3emo"
        }
    ]
];
const Store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("store", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/store.js [app-client] (ecmascript) <export default as Store>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Store",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/store.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/warehouse.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Warehouse
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M18 21V10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v11",
            key: "pb2vm6"
        }
    ],
    [
        "path",
        {
            d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 1.132-1.803l7.95-3.974a2 2 0 0 1 1.837 0l7.948 3.974A2 2 0 0 1 22 8z",
            key: "doq5xv"
        }
    ],
    [
        "path",
        {
            d: "M6 13h12",
            key: "yf64js"
        }
    ],
    [
        "path",
        {
            d: "M6 17h12",
            key: "1jwigz"
        }
    ]
];
const Warehouse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("warehouse", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/warehouse.js [app-client] (ecmascript) <export default as Warehouse>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Warehouse",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$warehouse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$warehouse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/warehouse.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/briefcase.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Briefcase
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",
            key: "jecpp"
        }
    ],
    [
        "rect",
        {
            width: "20",
            height: "14",
            x: "2",
            y: "6",
            rx: "2",
            key: "i6l2r4"
        }
    ]
];
const Briefcase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("briefcase", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/briefcase.js [app-client] (ecmascript) <export default as Briefcase>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Briefcase",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$briefcase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/briefcase.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/code.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Code
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m16 18 6-6-6-6",
            key: "eg8j8"
        }
    ],
    [
        "path",
        {
            d: "m8 6-6 6 6 6",
            key: "ppft3o"
        }
    ]
];
const Code = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("code", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/code.js [app-client] (ecmascript) <export default as Code>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Code",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$code$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$code$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/code.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/server.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Server
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "rect",
        {
            width: "20",
            height: "8",
            x: "2",
            y: "2",
            rx: "2",
            ry: "2",
            key: "ngkwjq"
        }
    ],
    [
        "rect",
        {
            width: "20",
            height: "8",
            x: "2",
            y: "14",
            rx: "2",
            ry: "2",
            key: "iecqi9"
        }
    ],
    [
        "line",
        {
            x1: "6",
            x2: "6.01",
            y1: "6",
            y2: "6",
            key: "16zg32"
        }
    ],
    [
        "line",
        {
            x1: "6",
            x2: "6.01",
            y1: "18",
            y2: "18",
            key: "nzw8ys"
        }
    ]
];
const Server = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("server", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/server.js [app-client] (ecmascript) <export default as Server>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Server",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$server$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$server$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/server.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/database.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Database
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "ellipse",
        {
            cx: "12",
            cy: "5",
            rx: "9",
            ry: "3",
            key: "msslwz"
        }
    ],
    [
        "path",
        {
            d: "M3 5V19A9 3 0 0 0 21 19V5",
            key: "1wlel7"
        }
    ],
    [
        "path",
        {
            d: "M3 12A9 3 0 0 0 21 12",
            key: "mv7ke4"
        }
    ]
];
const Database = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("database", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/database.js [app-client] (ecmascript) <export default as Database>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Database",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$database$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$database$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/database.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/globe.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Globe
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "path",
        {
            d: "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",
            key: "13o1zl"
        }
    ],
    [
        "path",
        {
            d: "M2 12h20",
            key: "9i4pu4"
        }
    ]
];
const Globe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("globe", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/globe.js [app-client] (ecmascript) <export default as Globe>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Globe",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$globe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/globe.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/shopping-cart.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ShoppingCart
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "8",
            cy: "21",
            r: "1",
            key: "jimo8o"
        }
    ],
    [
        "circle",
        {
            cx: "19",
            cy: "21",
            r: "1",
            key: "13723u"
        }
    ],
    [
        "path",
        {
            d: "M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",
            key: "9zh506"
        }
    ]
];
const ShoppingCart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("shopping-cart", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/shopping-cart.js [app-client] (ecmascript) <export default as ShoppingCart>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ShoppingCart",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shopping-cart.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/package.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Package
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",
            key: "1a0edw"
        }
    ],
    [
        "path",
        {
            d: "M12 22V12",
            key: "d0xqtd"
        }
    ],
    [
        "polyline",
        {
            points: "3.29 7 12 12 20.71 7",
            key: "ousv84"
        }
    ],
    [
        "path",
        {
            d: "m7.5 4.27 9 5.15",
            key: "1c824w"
        }
    ]
];
const Package = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("package", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/package.js [app-client] (ecmascript) <export default as Package>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Package",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/package.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/truck.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Truck
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",
            key: "wrbu53"
        }
    ],
    [
        "path",
        {
            d: "M15 18H9",
            key: "1lyqi6"
        }
    ],
    [
        "path",
        {
            d: "M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",
            key: "lysw3i"
        }
    ],
    [
        "circle",
        {
            cx: "17",
            cy: "18",
            r: "2",
            key: "332jqn"
        }
    ],
    [
        "circle",
        {
            cx: "7",
            cy: "18",
            r: "2",
            key: "19iecd"
        }
    ]
];
const Truck = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("truck", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/truck.js [app-client] (ecmascript) <export default as Truck>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Truck",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$truck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$truck$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/truck.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/graduation-cap.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>GraduationCap
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",
            key: "j76jl0"
        }
    ],
    [
        "path",
        {
            d: "M22 10v6",
            key: "1lu8f3"
        }
    ],
    [
        "path",
        {
            d: "M6 12.5V16a6 3 0 0 0 12 0v-3.5",
            key: "1r8lef"
        }
    ]
];
const GraduationCap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("graduation-cap", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/graduation-cap.js [app-client] (ecmascript) <export default as GraduationCap>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GraduationCap",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/graduation-cap.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/book-open.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>BookOpen
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M12 7v14",
            key: "1akyts"
        }
    ],
    [
        "path",
        {
            d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
            key: "ruj8y"
        }
    ]
];
const BookOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("book-open", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/book-open.js [app-client] (ecmascript) <export default as BookOpen>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BookOpen",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/book-open.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/stethoscope.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Stethoscope
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M11 2v2",
            key: "1539x4"
        }
    ],
    [
        "path",
        {
            d: "M5 2v2",
            key: "1yf1q8"
        }
    ],
    [
        "path",
        {
            d: "M5 3H4a2 2 0 0 0-2 2v4a6 6 0 0 0 12 0V5a2 2 0 0 0-2-2h-1",
            key: "rb5t3r"
        }
    ],
    [
        "path",
        {
            d: "M8 15a6 6 0 0 0 12 0v-3",
            key: "x18d4x"
        }
    ],
    [
        "circle",
        {
            cx: "20",
            cy: "10",
            r: "2",
            key: "ts1r5v"
        }
    ]
];
const Stethoscope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("stethoscope", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/stethoscope.js [app-client] (ecmascript) <export default as Stethoscope>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Stethoscope",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$stethoscope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$stethoscope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/stethoscope.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/chef-hat.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ChefHat
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M17 21a1 1 0 0 0 1-1v-5.35c0-.457.316-.844.727-1.041a4 4 0 0 0-2.134-7.589 5 5 0 0 0-9.186 0 4 4 0 0 0-2.134 7.588c.411.198.727.585.727 1.041V20a1 1 0 0 0 1 1Z",
            key: "1qvrer"
        }
    ],
    [
        "path",
        {
            d: "M6 17h12",
            key: "1jwigz"
        }
    ]
];
const ChefHat = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("chef-hat", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/chef-hat.js [app-client] (ecmascript) <export default as ChefHat>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChefHat",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chef$2d$hat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chef$2d$hat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chef-hat.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/coffee.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Coffee
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M10 2v2",
            key: "7u0qdc"
        }
    ],
    [
        "path",
        {
            d: "M14 2v2",
            key: "6buw04"
        }
    ],
    [
        "path",
        {
            d: "M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1",
            key: "pwadti"
        }
    ],
    [
        "path",
        {
            d: "M6 2v2",
            key: "colzsn"
        }
    ]
];
const Coffee = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("coffee", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/coffee.js [app-client] (ecmascript) <export default as Coffee>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Coffee",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$coffee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$coffee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/coffee.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/hammer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Hammer
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m15 12-9.373 9.373a1 1 0 0 1-3.001-3L12 9",
            key: "1hayfq"
        }
    ],
    [
        "path",
        {
            d: "m18 15 4-4",
            key: "16gjal"
        }
    ],
    [
        "path",
        {
            d: "m21.5 11.5-1.914-1.914A2 2 0 0 1 19 8.172v-.344a2 2 0 0 0-.586-1.414l-1.657-1.657A6 6 0 0 0 12.516 3H9l1.243 1.243A6 6 0 0 1 12 8.485V10l2 2h1.172a2 2 0 0 1 1.414.586L18.5 14.5",
            key: "15ts47"
        }
    ]
];
const Hammer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("hammer", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/hammer.js [app-client] (ecmascript) <export default as Hammer>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Hammer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hammer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hammer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/hammer.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/wrench.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Wrench
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",
            key: "1ngwbx"
        }
    ]
];
const Wrench = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("wrench", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/wrench.js [app-client] (ecmascript) <export default as Wrench>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Wrench",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wrench$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wrench$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wrench.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/dollar-sign.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>DollarSign
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "line",
        {
            x1: "12",
            x2: "12",
            y1: "2",
            y2: "22",
            key: "7eqyqh"
        }
    ],
    [
        "path",
        {
            d: "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
            key: "1b0p4s"
        }
    ]
];
const DollarSign = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("dollar-sign", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/dollar-sign.js [app-client] (ecmascript) <export default as DollarSign>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DollarSign",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$dollar$2d$sign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$dollar$2d$sign$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/dollar-sign.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/megaphone.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Megaphone
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z",
            key: "q8bfy3"
        }
    ],
    [
        "path",
        {
            d: "M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14",
            key: "1853fq"
        }
    ],
    [
        "path",
        {
            d: "M8 6v8",
            key: "15ugcq"
        }
    ]
];
const Megaphone = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("megaphone", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/megaphone.js [app-client] (ecmascript) <export default as Megaphone>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Megaphone",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$megaphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$megaphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/megaphone.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Mail
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",
            key: "132q7q"
        }
    ],
    [
        "rect",
        {
            x: "2",
            y: "4",
            width: "20",
            height: "16",
            rx: "2",
            key: "izxlao"
        }
    ]
];
const Mail = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("mail", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript) <export default as Mail>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Mail",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/scissors.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Scissors
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "6",
            cy: "6",
            r: "3",
            key: "1lh9wr"
        }
    ],
    [
        "path",
        {
            d: "M8.12 8.12 12 12",
            key: "1alkpv"
        }
    ],
    [
        "path",
        {
            d: "M20 4 8.12 15.88",
            key: "xgtan2"
        }
    ],
    [
        "circle",
        {
            cx: "6",
            cy: "18",
            r: "3",
            key: "fqmcym"
        }
    ],
    [
        "path",
        {
            d: "M14.8 14.8 20 20",
            key: "ptml3r"
        }
    ]
];
const Scissors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("scissors", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/scissors.js [app-client] (ecmascript) <export default as Scissors>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Scissors",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scissors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scissors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/scissors.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/palette.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Palette
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z",
            key: "e79jfc"
        }
    ],
    [
        "circle",
        {
            cx: "13.5",
            cy: "6.5",
            r: ".5",
            fill: "currentColor",
            key: "1okk4w"
        }
    ],
    [
        "circle",
        {
            cx: "17.5",
            cy: "10.5",
            r: ".5",
            fill: "currentColor",
            key: "f64h9f"
        }
    ],
    [
        "circle",
        {
            cx: "6.5",
            cy: "12.5",
            r: ".5",
            fill: "currentColor",
            key: "qy21gx"
        }
    ],
    [
        "circle",
        {
            cx: "8.5",
            cy: "7.5",
            r: ".5",
            fill: "currentColor",
            key: "fotxhn"
        }
    ]
];
const Palette = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("palette", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/palette.js [app-client] (ecmascript) <export default as Palette>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Palette",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$palette$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$palette$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/palette.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/car.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Car
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2",
            key: "5owen"
        }
    ],
    [
        "circle",
        {
            cx: "7",
            cy: "17",
            r: "2",
            key: "u2ysq9"
        }
    ],
    [
        "path",
        {
            d: "M9 17h6",
            key: "r8uit2"
        }
    ],
    [
        "circle",
        {
            cx: "17",
            cy: "17",
            r: "2",
            key: "axvx0g"
        }
    ]
];
const Car = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("car", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/car.js [app-client] (ecmascript) <export default as Car>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Car",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$car$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$car$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/car.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/music.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Music
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M9 18V5l12-2v13",
            key: "1jmyc2"
        }
    ],
    [
        "circle",
        {
            cx: "6",
            cy: "18",
            r: "3",
            key: "fqmcym"
        }
    ],
    [
        "circle",
        {
            cx: "18",
            cy: "16",
            r: "3",
            key: "1hluhg"
        }
    ]
];
const Music = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("music", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/music.js [app-client] (ecmascript) <export default as Music>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Music",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$music$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$music$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/music.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/dumbbell.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Dumbbell
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M17.596 12.768a2 2 0 1 0 2.829-2.829l-1.768-1.767a2 2 0 0 0 2.828-2.829l-2.828-2.828a2 2 0 0 0-2.829 2.828l-1.767-1.768a2 2 0 1 0-2.829 2.829z",
            key: "9m4mmf"
        }
    ],
    [
        "path",
        {
            d: "m2.5 21.5 1.4-1.4",
            key: "17g3f0"
        }
    ],
    [
        "path",
        {
            d: "m20.1 3.9 1.4-1.4",
            key: "1qn309"
        }
    ],
    [
        "path",
        {
            d: "M5.343 21.485a2 2 0 1 0 2.829-2.828l1.767 1.768a2 2 0 1 0 2.829-2.829l-6.364-6.364a2 2 0 1 0-2.829 2.829l1.768 1.767a2 2 0 0 0-2.828 2.829z",
            key: "1t2c92"
        }
    ],
    [
        "path",
        {
            d: "m9.6 14.4 4.8-4.8",
            key: "6umqxw"
        }
    ]
];
const Dumbbell = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("dumbbell", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/dumbbell.js [app-client] (ecmascript) <export default as Dumbbell>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Dumbbell",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$dumbbell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$dumbbell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/dumbbell.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/paperclip.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Paperclip
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m16 6-8.414 8.586a2 2 0 0 0 2.829 2.829l8.414-8.586a4 4 0 1 0-5.657-5.657l-8.379 8.551a6 6 0 1 0 8.485 8.485l8.379-8.551",
            key: "1miecu"
        }
    ]
];
const Paperclip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("paperclip", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/paperclip.js [app-client] (ecmascript) <export default as Paperclip>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Paperclip",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$paperclip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$paperclip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/paperclip.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Clock
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "path",
        {
            d: "M12 6v6l4 2",
            key: "mmk7yg"
        }
    ]
];
const Clock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("clock", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Clock",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/ellipsis-vertical.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>EllipsisVertical
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "1",
            key: "41hilf"
        }
    ],
    [
        "circle",
        {
            cx: "12",
            cy: "5",
            r: "1",
            key: "gxeob9"
        }
    ],
    [
        "circle",
        {
            cx: "12",
            cy: "19",
            r: "1",
            key: "lyex9k"
        }
    ]
];
const EllipsisVertical = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("ellipsis-vertical", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/ellipsis-vertical.js [app-client] (ecmascript) <export default as MoreVertical>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MoreVertical",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2d$vertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2d$vertical$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/ellipsis-vertical.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ChevronUp
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m18 15-6-6-6 6",
            key: "153udz"
        }
    ]
];
const ChevronUp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("chevron-up", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChevronUp",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Minus
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M5 12h14",
            key: "1ays0h"
        }
    ]
];
const Minus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("minus", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as Minus>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Minus",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/info.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Info
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "path",
        {
            d: "M12 16v-4",
            key: "1dtifu"
        }
    ],
    [
        "path",
        {
            d: "M12 8h.01",
            key: "e9boi3"
        }
    ]
];
const Info = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("info", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/info.js [app-client] (ecmascript) <export default as Info>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Info",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/info.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/trash.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Trash
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
            key: "miytrc"
        }
    ],
    [
        "path",
        {
            d: "M3 6h18",
            key: "d0wm0j"
        }
    ],
    [
        "path",
        {
            d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
            key: "e791ji"
        }
    ]
];
const Trash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("trash", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/trash.js [app-client] (ecmascript) <export default as Trash>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Trash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/save.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Save
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
            key: "1c8476"
        }
    ],
    [
        "path",
        {
            d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",
            key: "1ydtos"
        }
    ],
    [
        "path",
        {
            d: "M7 3v4a1 1 0 0 0 1 1h7",
            key: "t51u73"
        }
    ]
];
const Save = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("save", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/save.js [app-client] (ecmascript) <export default as Save>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Save",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/save.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/upload.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Upload
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M12 3v12",
            key: "1x0j5s"
        }
    ],
    [
        "path",
        {
            d: "m17 8-5-5-5 5",
            key: "7q97r8"
        }
    ],
    [
        "path",
        {
            d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
            key: "ih7n3h"
        }
    ]
];
const Upload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("upload", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/upload.js [app-client] (ecmascript) <export default as Upload>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Upload",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$upload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/upload.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/file-text.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>FileText
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
            key: "1oefj6"
        }
    ],
    [
        "path",
        {
            d: "M14 2v5a1 1 0 0 0 1 1h5",
            key: "wfsgrz"
        }
    ],
    [
        "path",
        {
            d: "M10 9H8",
            key: "b1mrlr"
        }
    ],
    [
        "path",
        {
            d: "M16 13H8",
            key: "t4e002"
        }
    ],
    [
        "path",
        {
            d: "M16 17H8",
            key: "z1uh3a"
        }
    ]
];
const FileText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("file-text", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/file-text.js [app-client] (ecmascript) <export default as FileText>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FileText",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/file-text.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/image.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Image
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "rect",
        {
            width: "18",
            height: "18",
            x: "3",
            y: "3",
            rx: "2",
            ry: "2",
            key: "1m3agn"
        }
    ],
    [
        "circle",
        {
            cx: "9",
            cy: "9",
            r: "2",
            key: "af1f0g"
        }
    ],
    [
        "path",
        {
            d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",
            key: "1xmnt7"
        }
    ]
];
const Image = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("image", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/image.js [app-client] (ecmascript) <export default as Image>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Image",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/image.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/file.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>File
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
            key: "1oefj6"
        }
    ],
    [
        "path",
        {
            d: "M14 2v5a1 1 0 0 0 1 1h5",
            key: "wfsgrz"
        }
    ]
];
const File = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("file", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/file.js [app-client] (ecmascript) <export default as File>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "File",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/file.js [app-client] (ecmascript)");
}),
"[project]/node_modules/lucide-react/dist/esm/icons/list-tree.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ListTree
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M8 5h13",
            key: "1pao27"
        }
    ],
    [
        "path",
        {
            d: "M13 12h8",
            key: "h98zly"
        }
    ],
    [
        "path",
        {
            d: "M13 19h8",
            key: "c3s6r1"
        }
    ],
    [
        "path",
        {
            d: "M3 10a2 2 0 0 0 2 2h3",
            key: "1npucw"
        }
    ],
    [
        "path",
        {
            d: "M3 5v12a2 2 0 0 0 2 2h3",
            key: "x1gjn2"
        }
    ]
];
const ListTree = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("list-tree", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/list-tree.js [app-client] (ecmascript) <export default as ListTree>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ListTree",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$tree$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$tree$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/list-tree.js [app-client] (ecmascript)");
}),
"[project]/node_modules/next/dist/compiled/client-only/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/node_modules/styled-jsx/dist/index/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
__turbopack_context__.r("[project]/node_modules/next/dist/compiled/client-only/index.js [app-client] (ecmascript)");
var React = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
function _interopDefaultLegacy(e) {
    return e && typeof e === 'object' && 'default' in e ? e : {
        'default': e
    };
}
var React__default = /*#__PURE__*/ _interopDefaultLegacy(React);
/*
Based on Glamor's sheet
https://github.com/threepointone/glamor/blob/667b480d31b3721a905021b26e1290ce92ca2879/src/sheet.js
*/ function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
}
var isProd = typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] !== "undefined" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env && ("TURBOPACK compile-time value", "development") === "production";
var isString = function(o) {
    return Object.prototype.toString.call(o) === "[object String]";
};
var StyleSheet = /*#__PURE__*/ function() {
    function StyleSheet(param) {
        var ref = param === void 0 ? {} : param, _name = ref.name, name = _name === void 0 ? "stylesheet" : _name, _optimizeForSpeed = ref.optimizeForSpeed, optimizeForSpeed = _optimizeForSpeed === void 0 ? isProd : _optimizeForSpeed;
        invariant$1(isString(name), "`name` must be a string");
        this._name = name;
        this._deletedRulePlaceholder = "#" + name + "-deleted-rule____{}";
        invariant$1(typeof optimizeForSpeed === "boolean", "`optimizeForSpeed` must be a boolean");
        this._optimizeForSpeed = optimizeForSpeed;
        this._serverSheet = undefined;
        this._tags = [];
        this._injected = false;
        this._rulesCount = 0;
        var node = typeof window !== "undefined" && document.querySelector('meta[property="csp-nonce"]');
        this._nonce = node ? node.getAttribute("content") : null;
    }
    var _proto = StyleSheet.prototype;
    _proto.setOptimizeForSpeed = function setOptimizeForSpeed(bool) {
        invariant$1(typeof bool === "boolean", "`setOptimizeForSpeed` accepts a boolean");
        invariant$1(this._rulesCount === 0, "optimizeForSpeed cannot be when rules have already been inserted");
        this.flush();
        this._optimizeForSpeed = bool;
        this.inject();
    };
    _proto.isOptimizeForSpeed = function isOptimizeForSpeed() {
        return this._optimizeForSpeed;
    };
    _proto.inject = function inject() {
        var _this = this;
        invariant$1(!this._injected, "sheet already injected");
        this._injected = true;
        if (typeof window !== "undefined" && this._optimizeForSpeed) {
            this._tags[0] = this.makeStyleTag(this._name);
            this._optimizeForSpeed = "insertRule" in this.getSheet();
            if (!this._optimizeForSpeed) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode.");
                }
                this.flush();
                this._injected = true;
            }
            return;
        }
        this._serverSheet = {
            cssRules: [],
            insertRule: function(rule, index) {
                if (typeof index === "number") {
                    _this._serverSheet.cssRules[index] = {
                        cssText: rule
                    };
                } else {
                    _this._serverSheet.cssRules.push({
                        cssText: rule
                    });
                }
                return index;
            },
            deleteRule: function(index) {
                _this._serverSheet.cssRules[index] = null;
            }
        };
    };
    _proto.getSheetForTag = function getSheetForTag(tag) {
        if (tag.sheet) {
            return tag.sheet;
        }
        // this weirdness brought to you by firefox
        for(var i = 0; i < document.styleSheets.length; i++){
            if (document.styleSheets[i].ownerNode === tag) {
                return document.styleSheets[i];
            }
        }
    };
    _proto.getSheet = function getSheet() {
        return this.getSheetForTag(this._tags[this._tags.length - 1]);
    };
    _proto.insertRule = function insertRule(rule, index) {
        invariant$1(isString(rule), "`insertRule` accepts only strings");
        if (typeof window === "undefined") {
            if (typeof index !== "number") {
                index = this._serverSheet.cssRules.length;
            }
            this._serverSheet.insertRule(rule, index);
            return this._rulesCount++;
        }
        if (this._optimizeForSpeed) {
            var sheet = this.getSheet();
            if (typeof index !== "number") {
                index = sheet.cssRules.length;
            }
            // this weirdness for perf, and chrome's weird bug
            // https://stackoverflow.com/questions/20007992/chrome-suddenly-stopped-accepting-insertrule
            try {
                sheet.insertRule(rule, index);
            } catch (error) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.warn("StyleSheet: illegal rule: \n\n" + rule + "\n\nSee https://stackoverflow.com/q/20007992 for more info");
                }
                return -1;
            }
        } else {
            var insertionPoint = this._tags[index];
            this._tags.push(this.makeStyleTag(this._name, rule, insertionPoint));
        }
        return this._rulesCount++;
    };
    _proto.replaceRule = function replaceRule(index, rule) {
        if (this._optimizeForSpeed || typeof window === "undefined") {
            var sheet = typeof window !== "undefined" ? this.getSheet() : this._serverSheet;
            if (!rule.trim()) {
                rule = this._deletedRulePlaceholder;
            }
            if (!sheet.cssRules[index]) {
                // @TBD Should we throw an error?
                return index;
            }
            sheet.deleteRule(index);
            try {
                sheet.insertRule(rule, index);
            } catch (error) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.warn("StyleSheet: illegal rule: \n\n" + rule + "\n\nSee https://stackoverflow.com/q/20007992 for more info");
                }
                // In order to preserve the indices we insert a deleteRulePlaceholder
                sheet.insertRule(this._deletedRulePlaceholder, index);
            }
        } else {
            var tag = this._tags[index];
            invariant$1(tag, "old rule at index `" + index + "` not found");
            tag.textContent = rule;
        }
        return index;
    };
    _proto.deleteRule = function deleteRule(index) {
        if (typeof window === "undefined") {
            this._serverSheet.deleteRule(index);
            return;
        }
        if (this._optimizeForSpeed) {
            this.replaceRule(index, "");
        } else {
            var tag = this._tags[index];
            invariant$1(tag, "rule at index `" + index + "` not found");
            tag.parentNode.removeChild(tag);
            this._tags[index] = null;
        }
    };
    _proto.flush = function flush() {
        this._injected = false;
        this._rulesCount = 0;
        if (typeof window !== "undefined") {
            this._tags.forEach(function(tag) {
                return tag && tag.parentNode.removeChild(tag);
            });
            this._tags = [];
        } else {
            // simpler on server
            this._serverSheet.cssRules = [];
        }
    };
    _proto.cssRules = function cssRules() {
        var _this = this;
        if (typeof window === "undefined") {
            return this._serverSheet.cssRules;
        }
        return this._tags.reduce(function(rules, tag) {
            if (tag) {
                rules = rules.concat(Array.prototype.map.call(_this.getSheetForTag(tag).cssRules, function(rule) {
                    return rule.cssText === _this._deletedRulePlaceholder ? null : rule;
                }));
            } else {
                rules.push(null);
            }
            return rules;
        }, []);
    };
    _proto.makeStyleTag = function makeStyleTag(name, cssString, relativeToTag) {
        if (cssString) {
            invariant$1(isString(cssString), "makeStyleTag accepts only strings as second parameter");
        }
        var tag = document.createElement("style");
        if (this._nonce) tag.setAttribute("nonce", this._nonce);
        tag.type = "text/css";
        tag.setAttribute("data-" + name, "");
        if (cssString) {
            tag.appendChild(document.createTextNode(cssString));
        }
        var head = document.head || document.getElementsByTagName("head")[0];
        if (relativeToTag) {
            head.insertBefore(tag, relativeToTag);
        } else {
            head.appendChild(tag);
        }
        return tag;
    };
    _createClass(StyleSheet, [
        {
            key: "length",
            get: function get() {
                return this._rulesCount;
            }
        }
    ]);
    return StyleSheet;
}();
function invariant$1(condition, message) {
    if (!condition) {
        throw new Error("StyleSheet: " + message + ".");
    }
}
function hash(str) {
    var _$hash = 5381, i = str.length;
    while(i){
        _$hash = _$hash * 33 ^ str.charCodeAt(--i);
    }
    /* JavaScript does bitwise operations (like XOR, above) on 32-bit signed
   * integers. Since we want the results to be always positive, convert the
   * signed int to an unsigned by doing an unsigned bitshift. */ return _$hash >>> 0;
}
var stringHash = hash;
var sanitize = function(rule) {
    return rule.replace(/\/style/gi, "\\/style");
};
var cache = {};
/**
 * computeId
 *
 * Compute and memoize a jsx id from a basedId and optionally props.
 */ function computeId(baseId, props) {
    if (!props) {
        return "jsx-" + baseId;
    }
    var propsToString = String(props);
    var key = baseId + propsToString;
    if (!cache[key]) {
        cache[key] = "jsx-" + stringHash(baseId + "-" + propsToString);
    }
    return cache[key];
}
/**
 * computeSelector
 *
 * Compute and memoize dynamic selectors.
 */ function computeSelector(id, css) {
    var selectoPlaceholderRegexp = /__jsx-style-dynamic-selector/g;
    // Sanitize SSR-ed CSS.
    // Client side code doesn't need to be sanitized since we use
    // document.createTextNode (dev) and the CSSOM api sheet.insertRule (prod).
    if (typeof window === "undefined") {
        css = sanitize(css);
    }
    var idcss = id + css;
    if (!cache[idcss]) {
        cache[idcss] = css.replace(selectoPlaceholderRegexp, id);
    }
    return cache[idcss];
}
function mapRulesToStyle(cssRules, options) {
    if (options === void 0) options = {};
    return cssRules.map(function(args) {
        var id = args[0];
        var css = args[1];
        return /*#__PURE__*/ React__default["default"].createElement("style", {
            id: "__" + id,
            // Avoid warnings upon render with a key
            key: "__" + id,
            nonce: options.nonce ? options.nonce : undefined,
            dangerouslySetInnerHTML: {
                __html: css
            }
        });
    });
}
var StyleSheetRegistry = /*#__PURE__*/ function() {
    function StyleSheetRegistry(param) {
        var ref = param === void 0 ? {} : param, _styleSheet = ref.styleSheet, styleSheet = _styleSheet === void 0 ? null : _styleSheet, _optimizeForSpeed = ref.optimizeForSpeed, optimizeForSpeed = _optimizeForSpeed === void 0 ? false : _optimizeForSpeed;
        this._sheet = styleSheet || new StyleSheet({
            name: "styled-jsx",
            optimizeForSpeed: optimizeForSpeed
        });
        this._sheet.inject();
        if (styleSheet && typeof optimizeForSpeed === "boolean") {
            this._sheet.setOptimizeForSpeed(optimizeForSpeed);
            this._optimizeForSpeed = this._sheet.isOptimizeForSpeed();
        }
        this._fromServer = undefined;
        this._indices = {};
        this._instancesCounts = {};
    }
    var _proto = StyleSheetRegistry.prototype;
    _proto.add = function add(props) {
        var _this = this;
        if (undefined === this._optimizeForSpeed) {
            this._optimizeForSpeed = Array.isArray(props.children);
            this._sheet.setOptimizeForSpeed(this._optimizeForSpeed);
            this._optimizeForSpeed = this._sheet.isOptimizeForSpeed();
        }
        if (typeof window !== "undefined" && !this._fromServer) {
            this._fromServer = this.selectFromServer();
            this._instancesCounts = Object.keys(this._fromServer).reduce(function(acc, tagName) {
                acc[tagName] = 0;
                return acc;
            }, {});
        }
        var ref = this.getIdAndRules(props), styleId = ref.styleId, rules = ref.rules;
        // Deduping: just increase the instances count.
        if (styleId in this._instancesCounts) {
            this._instancesCounts[styleId] += 1;
            return;
        }
        var indices = rules.map(function(rule) {
            return _this._sheet.insertRule(rule);
        }) // Filter out invalid rules
        .filter(function(index) {
            return index !== -1;
        });
        this._indices[styleId] = indices;
        this._instancesCounts[styleId] = 1;
    };
    _proto.remove = function remove(props) {
        var _this = this;
        var styleId = this.getIdAndRules(props).styleId;
        invariant(styleId in this._instancesCounts, "styleId: `" + styleId + "` not found");
        this._instancesCounts[styleId] -= 1;
        if (this._instancesCounts[styleId] < 1) {
            var tagFromServer = this._fromServer && this._fromServer[styleId];
            if (tagFromServer) {
                tagFromServer.parentNode.removeChild(tagFromServer);
                delete this._fromServer[styleId];
            } else {
                this._indices[styleId].forEach(function(index) {
                    return _this._sheet.deleteRule(index);
                });
                delete this._indices[styleId];
            }
            delete this._instancesCounts[styleId];
        }
    };
    _proto.update = function update(props, nextProps) {
        this.add(nextProps);
        this.remove(props);
    };
    _proto.flush = function flush() {
        this._sheet.flush();
        this._sheet.inject();
        this._fromServer = undefined;
        this._indices = {};
        this._instancesCounts = {};
    };
    _proto.cssRules = function cssRules() {
        var _this = this;
        var fromServer = this._fromServer ? Object.keys(this._fromServer).map(function(styleId) {
            return [
                styleId,
                _this._fromServer[styleId]
            ];
        }) : [];
        var cssRules = this._sheet.cssRules();
        return fromServer.concat(Object.keys(this._indices).map(function(styleId) {
            return [
                styleId,
                _this._indices[styleId].map(function(index) {
                    return cssRules[index].cssText;
                }).join(_this._optimizeForSpeed ? "" : "\n")
            ];
        }) // filter out empty rules
        .filter(function(rule) {
            return Boolean(rule[1]);
        }));
    };
    _proto.styles = function styles(options) {
        return mapRulesToStyle(this.cssRules(), options);
    };
    _proto.getIdAndRules = function getIdAndRules(props) {
        var css = props.children, dynamic = props.dynamic, id = props.id;
        if (dynamic) {
            var styleId = computeId(id, dynamic);
            return {
                styleId: styleId,
                rules: Array.isArray(css) ? css.map(function(rule) {
                    return computeSelector(styleId, rule);
                }) : [
                    computeSelector(styleId, css)
                ]
            };
        }
        return {
            styleId: computeId(id),
            rules: Array.isArray(css) ? css : [
                css
            ]
        };
    };
    /**
   * selectFromServer
   *
   * Collects style tags from the document with id __jsx-XXX
   */ _proto.selectFromServer = function selectFromServer() {
        var elements = Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]'));
        return elements.reduce(function(acc, element) {
            var id = element.id.slice(2);
            acc[id] = element;
            return acc;
        }, {});
    };
    return StyleSheetRegistry;
}();
function invariant(condition, message) {
    if (!condition) {
        throw new Error("StyleSheetRegistry: " + message + ".");
    }
}
var StyleSheetContext = /*#__PURE__*/ React.createContext(null);
StyleSheetContext.displayName = "StyleSheetContext";
function createStyleRegistry() {
    return new StyleSheetRegistry();
}
function StyleRegistry(param) {
    var configuredRegistry = param.registry, children = param.children;
    var rootRegistry = React.useContext(StyleSheetContext);
    var ref = React.useState({
        "StyleRegistry.useState[ref]": function() {
            return rootRegistry || configuredRegistry || createStyleRegistry();
        }
    }["StyleRegistry.useState[ref]"]), registry = ref[0];
    return /*#__PURE__*/ React__default["default"].createElement(StyleSheetContext.Provider, {
        value: registry
    }, children);
}
function useStyleRegistry() {
    return React.useContext(StyleSheetContext);
}
// Opt-into the new `useInsertionEffect` API in React 18, fallback to `useLayoutEffect`.
// https://github.com/reactwg/react-18/discussions/110
var useInsertionEffect = React__default["default"].useInsertionEffect || React__default["default"].useLayoutEffect;
var defaultRegistry = typeof window !== "undefined" ? createStyleRegistry() : undefined;
function JSXStyle(props) {
    var registry = defaultRegistry ? defaultRegistry : useStyleRegistry();
    // If `registry` does not exist, we do nothing here.
    if (!registry) {
        return null;
    }
    if (typeof window === "undefined") {
        registry.add(props);
        return null;
    }
    useInsertionEffect({
        "JSXStyle.useInsertionEffect": function() {
            registry.add(props);
            return ({
                "JSXStyle.useInsertionEffect": function() {
                    registry.remove(props);
                }
            })["JSXStyle.useInsertionEffect"];
        // props.children can be string[], will be striped since id is identical
        }
    }["JSXStyle.useInsertionEffect"], [
        props.id,
        String(props.dynamic)
    ]);
    return null;
}
JSXStyle.dynamic = function(info) {
    return info.map(function(tagInfo) {
        var baseId = tagInfo[0];
        var props = tagInfo[1];
        return computeId(baseId, props);
    }).join(" ");
};
exports.StyleRegistry = StyleRegistry;
exports.createStyleRegistry = createStyleRegistry;
exports.style = JSXStyle;
exports.useStyleRegistry = useStyleRegistry;
}),
"[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/styled-jsx/dist/index/index.js [app-client] (ecmascript)").style;
}),
"[project]/node_modules/preact/dist/preact.module.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Component",
    ()=>x,
    "Fragment",
    ()=>_,
    "cloneElement",
    ()=>F,
    "createContext",
    ()=>G,
    "createElement",
    ()=>y,
    "createRef",
    ()=>d,
    "h",
    ()=>y,
    "hydrate",
    ()=>E,
    "isValidElement",
    ()=>i,
    "options",
    ()=>l,
    "render",
    ()=>D,
    "toChildArray",
    ()=>j
]);
var n, l, u, i, t, r, o, f, e, c = {}, s = [], a = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
function h(n, l) {
    for(var u in l)n[u] = l[u];
    return n;
}
function v(n) {
    var l = n.parentNode;
    l && l.removeChild(n);
}
function y(l, u, i) {
    var t, r, o, f = {};
    for(o in u)"key" == o ? t = u[o] : "ref" == o ? r = u[o] : f[o] = u[o];
    if (arguments.length > 2 && (f.children = arguments.length > 3 ? n.call(arguments, 2) : i), "function" == typeof l && null != l.defaultProps) for(o in l.defaultProps)void 0 === f[o] && (f[o] = l.defaultProps[o]);
    return p(l, f, t, r, null);
}
function p(n, i, t, r, o) {
    var f = {
        type: n,
        props: i,
        key: t,
        ref: r,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __d: void 0,
        __c: null,
        __h: null,
        constructor: void 0,
        __v: null == o ? ++u : o
    };
    return null == o && null != l.vnode && l.vnode(f), f;
}
function d() {
    return {
        current: null
    };
}
function _(n) {
    return n.children;
}
function k(n, l, u, i, t) {
    var r;
    for(r in u)"children" === r || "key" === r || r in l || g(n, r, null, u[r], i);
    for(r in l)t && "function" != typeof l[r] || "children" === r || "key" === r || "value" === r || "checked" === r || u[r] === l[r] || g(n, r, l[r], u[r], i);
}
function b(n, l, u) {
    "-" === l[0] ? n.setProperty(l, null == u ? "" : u) : n[l] = null == u ? "" : "number" != typeof u || a.test(l) ? u : u + "px";
}
function g(n, l, u, i, t) {
    var r;
    n: if ("style" === l) if ("string" == typeof u) n.style.cssText = u;
    else {
        if ("string" == typeof i && (n.style.cssText = i = ""), i) for(l in i)u && l in u || b(n.style, l, "");
        if (u) for(l in u)i && u[l] === i[l] || b(n.style, l, u[l]);
    }
    else if ("o" === l[0] && "n" === l[1]) r = l !== (l = l.replace(/Capture$/, "")), l = l.toLowerCase() in n ? l.toLowerCase().slice(2) : l.slice(2), n.l || (n.l = {}), n.l[l + r] = u, u ? i || n.addEventListener(l, r ? w : m, r) : n.removeEventListener(l, r ? w : m, r);
    else if ("dangerouslySetInnerHTML" !== l) {
        if (t) l = l.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("width" !== l && "height" !== l && "href" !== l && "list" !== l && "form" !== l && "tabIndex" !== l && "download" !== l && l in n) try {
            n[l] = null == u ? "" : u;
            break n;
        } catch (n) {}
        "function" == typeof u || (null == u || !1 === u && -1 == l.indexOf("-") ? n.removeAttribute(l) : n.setAttribute(l, u));
    }
}
function m(n) {
    t = !0;
    try {
        return this.l[n.type + !1](l.event ? l.event(n) : n);
    } finally{
        t = !1;
    }
}
function w(n) {
    t = !0;
    try {
        return this.l[n.type + !0](l.event ? l.event(n) : n);
    } finally{
        t = !1;
    }
}
function x(n, l) {
    this.props = n, this.context = l;
}
function A(n, l) {
    if (null == l) return n.__ ? A(n.__, n.__.__k.indexOf(n) + 1) : null;
    for(var u; l < n.__k.length; l++)if (null != (u = n.__k[l]) && null != u.__e) return u.__e;
    return "function" == typeof n.type ? A(n) : null;
}
function P(n) {
    var l, u;
    if (null != (n = n.__) && null != n.__c) {
        for(n.__e = n.__c.base = null, l = 0; l < n.__k.length; l++)if (null != (u = n.__k[l]) && null != u.__e) {
            n.__e = n.__c.base = u.__e;
            break;
        }
        return P(n);
    }
}
function C(n) {
    t ? setTimeout(n) : f(n);
}
function T(n) {
    (!n.__d && (n.__d = !0) && r.push(n) && !$.__r++ || o !== l.debounceRendering) && ((o = l.debounceRendering) || C)($);
}
function $() {
    var n, l, u, i, t, o, f, e;
    for(r.sort(function(n, l) {
        return n.__v.__b - l.__v.__b;
    }); n = r.shift();)n.__d && (l = r.length, i = void 0, t = void 0, f = (o = (u = n).__v).__e, (e = u.__P) && (i = [], (t = h({}, o)).__v = o.__v + 1, M(e, o, t, u.__n, void 0 !== e.ownerSVGElement, null != o.__h ? [
        f
    ] : null, i, null == f ? A(o) : f, o.__h), N(i, o), o.__e != f && P(o)), r.length > l && r.sort(function(n, l) {
        return n.__v.__b - l.__v.__b;
    }));
    $.__r = 0;
}
function H(n, l, u, i, t, r, o, f, e, a) {
    var h, v, y, d, k, b, g, m = i && i.__k || s, w = m.length;
    for(u.__k = [], h = 0; h < l.length; h++)if (null != (d = u.__k[h] = null == (d = l[h]) || "boolean" == typeof d ? null : "string" == typeof d || "number" == typeof d || "bigint" == typeof d ? p(null, d, null, null, d) : Array.isArray(d) ? p(_, {
        children: d
    }, null, null, null) : d.__b > 0 ? p(d.type, d.props, d.key, d.ref ? d.ref : null, d.__v) : d)) {
        if (d.__ = u, d.__b = u.__b + 1, null === (y = m[h]) || y && d.key == y.key && d.type === y.type) m[h] = void 0;
        else for(v = 0; v < w; v++){
            if ((y = m[v]) && d.key == y.key && d.type === y.type) {
                m[v] = void 0;
                break;
            }
            y = null;
        }
        M(n, d, y = y || c, t, r, o, f, e, a), k = d.__e, (v = d.ref) && y.ref != v && (g || (g = []), y.ref && g.push(y.ref, null, d), g.push(v, d.__c || k, d)), null != k ? (null == b && (b = k), "function" == typeof d.type && d.__k === y.__k ? d.__d = e = I(d, e, n) : e = z(n, d, y, m, k, e), "function" == typeof u.type && (u.__d = e)) : e && y.__e == e && e.parentNode != n && (e = A(y));
    }
    for(u.__e = b, h = w; h--;)null != m[h] && ("function" == typeof u.type && null != m[h].__e && m[h].__e == u.__d && (u.__d = L(i).nextSibling), q(m[h], m[h]));
    if (g) for(h = 0; h < g.length; h++)S(g[h], g[++h], g[++h]);
}
function I(n, l, u) {
    for(var i, t = n.__k, r = 0; t && r < t.length; r++)(i = t[r]) && (i.__ = n, l = "function" == typeof i.type ? I(i, l, u) : z(u, i, i, t, i.__e, l));
    return l;
}
function j(n, l) {
    return l = l || [], null == n || "boolean" == typeof n || (Array.isArray(n) ? n.some(function(n) {
        j(n, l);
    }) : l.push(n)), l;
}
function z(n, l, u, i, t, r) {
    var o, f, e;
    if (void 0 !== l.__d) o = l.__d, l.__d = void 0;
    else if (null == u || t != r || null == t.parentNode) n: if (null == r || r.parentNode !== n) n.appendChild(t), o = null;
    else {
        for(f = r, e = 0; (f = f.nextSibling) && e < i.length; e += 1)if (f == t) break n;
        n.insertBefore(t, r), o = r;
    }
    return void 0 !== o ? o : t.nextSibling;
}
function L(n) {
    var l, u, i;
    if (null == n.type || "string" == typeof n.type) return n.__e;
    if (n.__k) {
        for(l = n.__k.length - 1; l >= 0; l--)if ((u = n.__k[l]) && (i = L(u))) return i;
    }
    return null;
}
function M(n, u, i, t, r, o, f, e, c) {
    var s, a, v, y, p, d, k, b, g, m, w, A, P, C, T, $ = u.type;
    if (void 0 !== u.constructor) return null;
    null != i.__h && (c = i.__h, e = u.__e = i.__e, u.__h = null, o = [
        e
    ]), (s = l.__b) && s(u);
    try {
        n: if ("function" == typeof $) {
            if (b = u.props, g = (s = $.contextType) && t[s.__c], m = s ? g ? g.props.value : s.__ : t, i.__c ? k = (a = u.__c = i.__c).__ = a.__E : ("prototype" in $ && $.prototype.render ? u.__c = a = new $(b, m) : (u.__c = a = new x(b, m), a.constructor = $, a.render = B), g && g.sub(a), a.props = b, a.state || (a.state = {}), a.context = m, a.__n = t, v = a.__d = !0, a.__h = [], a._sb = []), null == a.__s && (a.__s = a.state), null != $.getDerivedStateFromProps && (a.__s == a.state && (a.__s = h({}, a.__s)), h(a.__s, $.getDerivedStateFromProps(b, a.__s))), y = a.props, p = a.state, a.__v = u, v) null == $.getDerivedStateFromProps && null != a.componentWillMount && a.componentWillMount(), null != a.componentDidMount && a.__h.push(a.componentDidMount);
            else {
                if (null == $.getDerivedStateFromProps && b !== y && null != a.componentWillReceiveProps && a.componentWillReceiveProps(b, m), !a.__e && null != a.shouldComponentUpdate && !1 === a.shouldComponentUpdate(b, a.__s, m) || u.__v === i.__v) {
                    for(u.__v !== i.__v && (a.props = b, a.state = a.__s, a.__d = !1), u.__e = i.__e, u.__k = i.__k, u.__k.forEach(function(n) {
                        n && (n.__ = u);
                    }), w = 0; w < a._sb.length; w++)a.__h.push(a._sb[w]);
                    a._sb = [], a.__h.length && f.push(a);
                    break n;
                }
                null != a.componentWillUpdate && a.componentWillUpdate(b, a.__s, m), null != a.componentDidUpdate && a.__h.push(function() {
                    a.componentDidUpdate(y, p, d);
                });
            }
            if (a.context = m, a.props = b, a.__P = n, A = l.__r, P = 0, "prototype" in $ && $.prototype.render) {
                for(a.state = a.__s, a.__d = !1, A && A(u), s = a.render(a.props, a.state, a.context), C = 0; C < a._sb.length; C++)a.__h.push(a._sb[C]);
                a._sb = [];
            } else do {
                a.__d = !1, A && A(u), s = a.render(a.props, a.state, a.context), a.state = a.__s;
            }while (a.__d && ++P < 25)
            a.state = a.__s, null != a.getChildContext && (t = h(h({}, t), a.getChildContext())), v || null == a.getSnapshotBeforeUpdate || (d = a.getSnapshotBeforeUpdate(y, p)), T = null != s && s.type === _ && null == s.key ? s.props.children : s, H(n, Array.isArray(T) ? T : [
                T
            ], u, i, t, r, o, f, e, c), a.base = u.__e, u.__h = null, a.__h.length && f.push(a), k && (a.__E = a.__ = null), a.__e = !1;
        } else null == o && u.__v === i.__v ? (u.__k = i.__k, u.__e = i.__e) : u.__e = O(i.__e, u, i, t, r, o, f, c);
        (s = l.diffed) && s(u);
    } catch (n) {
        u.__v = null, (c || null != o) && (u.__e = e, u.__h = !!c, o[o.indexOf(e)] = null), l.__e(n, u, i);
    }
}
function N(n, u) {
    l.__c && l.__c(u, n), n.some(function(u) {
        try {
            n = u.__h, u.__h = [], n.some(function(n) {
                n.call(u);
            });
        } catch (n) {
            l.__e(n, u.__v);
        }
    });
}
function O(l, u, i, t, r, o, f, e) {
    var s, a, h, y = i.props, p = u.props, d = u.type, _ = 0;
    if ("svg" === d && (r = !0), null != o) {
        for(; _ < o.length; _++)if ((s = o[_]) && "setAttribute" in s == !!d && (d ? s.localName === d : 3 === s.nodeType)) {
            l = s, o[_] = null;
            break;
        }
    }
    if (null == l) {
        if (null === d) return document.createTextNode(p);
        l = r ? document.createElementNS("http://www.w3.org/2000/svg", d) : document.createElement(d, p.is && p), o = null, e = !1;
    }
    if (null === d) y === p || e && l.data === p || (l.data = p);
    else {
        if (o = o && n.call(l.childNodes), a = (y = i.props || c).dangerouslySetInnerHTML, h = p.dangerouslySetInnerHTML, !e) {
            if (null != o) for(y = {}, _ = 0; _ < l.attributes.length; _++)y[l.attributes[_].name] = l.attributes[_].value;
            (h || a) && (h && (a && h.__html == a.__html || h.__html === l.innerHTML) || (l.innerHTML = h && h.__html || ""));
        }
        if (k(l, p, y, r, e), h) u.__k = [];
        else if (_ = u.props.children, H(l, Array.isArray(_) ? _ : [
            _
        ], u, i, t, r && "foreignObject" !== d, o, f, o ? o[0] : i.__k && A(i, 0), e), null != o) for(_ = o.length; _--;)null != o[_] && v(o[_]);
        e || ("value" in p && void 0 !== (_ = p.value) && (_ !== l.value || "progress" === d && !_ || "option" === d && _ !== y.value) && g(l, "value", _, y.value, !1), "checked" in p && void 0 !== (_ = p.checked) && _ !== l.checked && g(l, "checked", _, y.checked, !1));
    }
    return l;
}
function S(n, u, i) {
    try {
        "function" == typeof n ? n(u) : n.current = u;
    } catch (n) {
        l.__e(n, i);
    }
}
function q(n, u, i) {
    var t, r;
    if (l.unmount && l.unmount(n), (t = n.ref) && (t.current && t.current !== n.__e || S(t, null, u)), null != (t = n.__c)) {
        if (t.componentWillUnmount) try {
            t.componentWillUnmount();
        } catch (n) {
            l.__e(n, u);
        }
        t.base = t.__P = null, n.__c = void 0;
    }
    if (t = n.__k) for(r = 0; r < t.length; r++)t[r] && q(t[r], u, i || "function" != typeof n.type);
    i || null == n.__e || v(n.__e), n.__ = n.__e = n.__d = void 0;
}
function B(n, l, u) {
    return this.constructor(n, u);
}
function D(u, i, t) {
    var r, o, f;
    l.__ && l.__(u, i), o = (r = "function" == typeof t) ? null : t && t.__k || i.__k, f = [], M(i, u = (!r && t || i).__k = y(_, null, [
        u
    ]), o || c, c, void 0 !== i.ownerSVGElement, !r && t ? [
        t
    ] : o ? null : i.firstChild ? n.call(i.childNodes) : null, f, !r && t ? t : o ? o.__e : i.firstChild, r), N(f, u);
}
function E(n, l) {
    D(n, l, E);
}
function F(l, u, i) {
    var t, r, o, f = h({}, l.props);
    for(o in u)"key" == o ? t = u[o] : "ref" == o ? r = u[o] : f[o] = u[o];
    return arguments.length > 2 && (f.children = arguments.length > 3 ? n.call(arguments, 2) : i), p(l.type, f, t || l.key, r || l.ref, null);
}
function G(n, l) {
    var u = {
        __c: l = "__cC" + e++,
        __: n,
        Consumer: function(n, l) {
            return n.children(l);
        },
        Provider: function(n) {
            var u, i;
            return this.getChildContext || (u = [], (i = {})[l] = this, this.getChildContext = function() {
                return i;
            }, this.shouldComponentUpdate = function(n) {
                this.props.value !== n.value && u.some(function(n) {
                    n.__e = !0, T(n);
                });
            }, this.sub = function(n) {
                u.push(n);
                var l = n.componentWillUnmount;
                n.componentWillUnmount = function() {
                    u.splice(u.indexOf(n), 1), l && l.call(n);
                };
            }), n.children;
        }
    };
    return u.Provider.__ = u.Consumer.contextType = u;
}
n = s.slice, l = {
    __e: function(n, l, u, i) {
        for(var t, r, o; l = l.__;)if ((t = l.__c) && !t.__) try {
            if ((r = t.constructor) && null != r.getDerivedStateFromError && (t.setState(r.getDerivedStateFromError(n)), o = t.__d), null != t.componentDidCatch && (t.componentDidCatch(n, i || {}), o = t.__d), o) return t.__E = t;
        } catch (l) {
            n = l;
        }
        throw n;
    }
}, u = 0, i = function(n) {
    return null != n && void 0 === n.constructor;
}, t = !1, x.prototype.setState = function(n, l) {
    var u;
    u = null != this.__s && this.__s !== this.state ? this.__s : this.__s = h({}, this.state), "function" == typeof n && (n = n(h({}, u), this.props)), n && h(u, n), null != n && this.__v && (l && this._sb.push(l), T(this));
}, x.prototype.forceUpdate = function(n) {
    this.__v && (this.__e = !0, n && this.__h.push(n), T(this));
}, x.prototype.render = _, r = [], f = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, $.__r = 0, e = 0;
;
}),
"[project]/node_modules/preact/hooks/dist/hooks.module.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCallback",
    ()=>T,
    "useContext",
    ()=>q,
    "useDebugValue",
    ()=>x,
    "useEffect",
    ()=>h,
    "useErrorBoundary",
    ()=>P,
    "useId",
    ()=>V,
    "useImperativeHandle",
    ()=>A,
    "useLayoutEffect",
    ()=>s,
    "useMemo",
    ()=>F,
    "useReducer",
    ()=>y,
    "useRef",
    ()=>_,
    "useState",
    ()=>p
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/preact/dist/preact.module.js [app-client] (ecmascript)");
;
var t, r, u, i, o = 0, f = [], c = [], e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__b, a = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__r, v = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].diffed, l = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__c, m = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].unmount;
function d(t, u) {
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__h && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__h(r, t, o || u), o = 0;
    var i = r.__H || (r.__H = {
        __: [],
        __h: []
    });
    return t >= i.__.length && i.__.push({
        __V: c
    }), i.__[t];
}
function p(n) {
    return o = 1, y(B, n);
}
function y(n, u, i) {
    var o = d(t++, 2);
    if (o.t = n, !o.__c && (o.__ = [
        i ? i(u) : B(void 0, u),
        function(n) {
            var t = o.__N ? o.__N[0] : o.__[0], r = o.t(t, n);
            t !== r && (o.__N = [
                r,
                o.__[1]
            ], o.__c.setState({}));
        }
    ], o.__c = r, !r.u)) {
        r.u = !0;
        var f = r.shouldComponentUpdate;
        r.shouldComponentUpdate = function(n, t, r) {
            if (!o.__c.__H) return !0;
            var u = o.__c.__H.__.filter(function(n) {
                return n.__c;
            });
            if (u.every(function(n) {
                return !n.__N;
            })) return !f || f.call(this, n, t, r);
            var i = !1;
            return u.forEach(function(n) {
                if (n.__N) {
                    var t = n.__[0];
                    n.__ = n.__N, n.__N = void 0, t !== n.__[0] && (i = !0);
                }
            }), !(!i && o.__c.props === n) && (!f || f.call(this, n, t, r));
        };
    }
    return o.__N || o.__;
}
function h(u, i) {
    var o = d(t++, 3);
    !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__s && z(o.__H, i) && (o.__ = u, o.i = i, r.__H.__h.push(o));
}
function s(u, i) {
    var o = d(t++, 4);
    !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__s && z(o.__H, i) && (o.__ = u, o.i = i, r.__h.push(o));
}
function _(n) {
    return o = 5, F(function() {
        return {
            current: n
        };
    }, []);
}
function A(n, t, r) {
    o = 6, s(function() {
        return "function" == typeof n ? (n(t()), function() {
            return n(null);
        }) : n ? (n.current = t(), function() {
            return n.current = null;
        }) : void 0;
    }, null == r ? r : r.concat(n));
}
function F(n, r) {
    var u = d(t++, 7);
    return z(u.__H, r) ? (u.__V = n(), u.i = r, u.__h = n, u.__V) : u.__;
}
function T(n, t) {
    return o = 8, F(function() {
        return n;
    }, t);
}
function q(n) {
    var u = r.context[n.__c], i = d(t++, 9);
    return i.c = n, u ? (null == i.__ && (i.__ = !0, u.sub(r)), u.props.value) : n.__;
}
function x(t, r) {
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].useDebugValue && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].useDebugValue(r ? r(t) : t);
}
function P(n) {
    var u = d(t++, 10), i = p();
    return u.__ = n, r.componentDidCatch || (r.componentDidCatch = function(n, t) {
        u.__ && u.__(n, t), i[1](n);
    }), [
        i[0],
        function() {
            i[1](void 0);
        }
    ];
}
function V() {
    var n = d(t++, 11);
    if (!n.__) {
        for(var u = r.__v; null !== u && !u.__m && null !== u.__;)u = u.__;
        var i = u.__m || (u.__m = [
            0,
            0
        ]);
        n.__ = "P" + i[0] + "-" + i[1]++;
    }
    return n.__;
}
function b() {
    for(var t; t = f.shift();)if (t.__P && t.__H) try {
        t.__H.__h.forEach(k), t.__H.__h.forEach(w), t.__H.__h = [];
    } catch (r) {
        t.__H.__h = [], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__e(r, t.__v);
    }
}
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__b = function(n) {
    r = null, e && e(n);
}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__r = function(n) {
    a && a(n), t = 0;
    var i = (r = n.__c).__H;
    i && (u === r ? (i.__h = [], r.__h = [], i.__.forEach(function(n) {
        n.__N && (n.__ = n.__N), n.__V = c, n.__N = n.i = void 0;
    })) : (i.__h.forEach(k), i.__h.forEach(w), i.__h = [])), u = r;
}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].diffed = function(t) {
    v && v(t);
    var o = t.__c;
    o && o.__H && (o.__H.__h.length && (1 !== f.push(o) && i === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].requestAnimationFrame || ((i = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].requestAnimationFrame) || j)(b)), o.__H.__.forEach(function(n) {
        n.i && (n.__H = n.i), n.__V !== c && (n.__ = n.__V), n.i = void 0, n.__V = c;
    })), u = r = null;
}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__c = function(t, r) {
    r.some(function(t) {
        try {
            t.__h.forEach(k), t.__h = t.__h.filter(function(n) {
                return !n.__ || w(n);
            });
        } catch (u) {
            r.some(function(n) {
                n.__h && (n.__h = []);
            }), r = [], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__e(u, t.__v);
        }
    }), l && l(t, r);
}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].unmount = function(t) {
    m && m(t);
    var r, u = t.__c;
    u && u.__H && (u.__H.__.forEach(function(n) {
        try {
            k(n);
        } catch (n) {
            r = n;
        }
    }), u.__H = void 0, r && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__e(r, u.__v));
};
var g = "function" == typeof requestAnimationFrame;
function j(n) {
    var t, r = function() {
        clearTimeout(u), g && cancelAnimationFrame(t), setTimeout(n);
    }, u = setTimeout(r, 100);
    g && (t = requestAnimationFrame(r));
}
function k(n) {
    var t = r, u = n.__c;
    "function" == typeof u && (n.__c = void 0, u()), r = t;
}
function w(n) {
    var t = r;
    n.__c = n.__(), r = t;
}
function z(n, t) {
    return !n || n.length !== t.length || t.some(function(t, r) {
        return t !== n[r];
    });
}
function B(n, t) {
    return "function" == typeof t ? t(n) : t;
}
;
}),
"[project]/node_modules/preact/compat/dist/compat.module.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Children",
    ()=>O,
    "PureComponent",
    ()=>w,
    "StrictMode",
    ()=>vn,
    "Suspense",
    ()=>D,
    "SuspenseList",
    ()=>V,
    "__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED",
    ()=>rn,
    "cloneElement",
    ()=>cn,
    "createFactory",
    ()=>on,
    "createPortal",
    ()=>j,
    "default",
    ()=>bn,
    "findDOMNode",
    ()=>an,
    "flushSync",
    ()=>hn,
    "forwardRef",
    ()=>k,
    "hydrate",
    ()=>q,
    "isValidElement",
    ()=>ln,
    "lazy",
    ()=>M,
    "memo",
    ()=>R,
    "render",
    ()=>Y,
    "startTransition",
    ()=>dn,
    "unmountComponentAtNode",
    ()=>fn,
    "unstable_batchedUpdates",
    ()=>sn,
    "useDeferredValue",
    ()=>pn,
    "useInsertionEffect",
    ()=>yn,
    "useSyncExternalStore",
    ()=>_n,
    "useTransition",
    ()=>mn,
    "version",
    ()=>un
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/preact/dist/preact.module.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/preact/hooks/dist/hooks.module.js [app-client] (ecmascript)");
;
;
;
;
function g(n, t) {
    for(var e in t)n[e] = t[e];
    return n;
}
function C(n, t) {
    for(var e in n)if ("__source" !== e && !(e in t)) return !0;
    for(var r in t)if ("__source" !== r && n[r] !== t[r]) return !0;
    return !1;
}
function E(n, t) {
    return n === t && (0 !== n || 1 / n == 1 / t) || n != n && t != t;
}
function w(n) {
    this.props = n;
}
function R(n, e) {
    function r(n) {
        var t = this.props.ref, r = t == n.ref;
        return !r && t && (t.call ? t(null) : t.current = null), e ? !e(this.props, n) || !r : C(this.props, n);
    }
    function u(e) {
        return this.shouldComponentUpdate = r, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(n, e);
    }
    return u.displayName = "Memo(" + (n.displayName || n.name) + ")", u.prototype.isReactComponent = !0, u.__f = !0, u;
}
(w.prototype = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"]).isPureReactComponent = !0, w.prototype.shouldComponentUpdate = function(n, t) {
    return C(this.props, n) || C(this.state, t);
};
var x = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__b;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__b = function(n) {
    n.type && n.type.__f && n.ref && (n.props.ref = n.ref, n.ref = null), x && x(n);
};
var N = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;
function k(n) {
    function t(t) {
        var e = g({}, t);
        return delete e.ref, n(e, t.ref || null);
    }
    return t.$$typeof = N, t.render = t, t.prototype.isReactComponent = t.__f = !0, t.displayName = "ForwardRef(" + (n.displayName || n.name) + ")", t;
}
var A = function(n, t) {
    return null == n ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toChildArray"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toChildArray"])(n).map(t));
}, O = {
    map: A,
    forEach: A,
    count: function(n) {
        return n ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toChildArray"])(n).length : 0;
    },
    only: function(n) {
        var t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toChildArray"])(n);
        if (1 !== t.length) throw "Children.only";
        return t[0];
    },
    toArray: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toChildArray"]
}, T = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__e;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__e = function(n, t, e, r) {
    if (n.then) {
        for(var u, o = t; o = o.__;)if ((u = o.__c) && u.__c) return null == t.__e && (t.__e = e.__e, t.__k = e.__k), u.__c(n, t);
    }
    T(n, t, e, r);
};
var I = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].unmount;
function L(n, t, e) {
    return n && (n.__c && n.__c.__H && (n.__c.__H.__.forEach(function(n) {
        "function" == typeof n.__c && n.__c();
    }), n.__c.__H = null), null != (n = g({}, n)).__c && (n.__c.__P === e && (n.__c.__P = t), n.__c = null), n.__k = n.__k && n.__k.map(function(n) {
        return L(n, t, e);
    })), n;
}
function U(n, t, e) {
    return n && (n.__v = null, n.__k = n.__k && n.__k.map(function(n) {
        return U(n, t, e);
    }), n.__c && n.__c.__P === t && (n.__e && e.insertBefore(n.__e, n.__d), n.__c.__e = !0, n.__c.__P = e)), n;
}
function D() {
    this.__u = 0, this.t = null, this.__b = null;
}
function F(n) {
    var t = n.__.__c;
    return t && t.__a && t.__a(n);
}
function M(n) {
    var e, r, u;
    function o(o) {
        if (e || (e = n()).then(function(n) {
            r = n.default || n;
        }, function(n) {
            u = n;
        }), u) throw u;
        if (!r) throw e;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(r, o);
    }
    return o.displayName = "Lazy", o.__f = !0, o;
}
function V() {
    this.u = null, this.o = null;
}
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].unmount = function(n) {
    var t = n.__c;
    t && t.__R && t.__R(), t && !0 === n.__h && (n.type = null), I && I(n);
}, (D.prototype = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"]).__c = function(n, t) {
    var e = t.__c, r = this;
    null == r.t && (r.t = []), r.t.push(e);
    var u = F(r.__v), o = !1, i = function() {
        o || (o = !0, e.__R = null, u ? u(l) : l());
    };
    e.__R = i;
    var l = function() {
        if (!--r.__u) {
            if (r.state.__a) {
                var n = r.state.__a;
                r.__v.__k[0] = U(n, n.__c.__P, n.__c.__O);
            }
            var t;
            for(r.setState({
                __a: r.__b = null
            }); t = r.t.pop();)t.forceUpdate();
        }
    }, c = !0 === t.__h;
    r.__u++ || c || r.setState({
        __a: r.__b = r.__v.__k[0]
    }), n.then(i, i);
}, D.prototype.componentWillUnmount = function() {
    this.t = [];
}, D.prototype.render = function(n, e) {
    if (this.__b) {
        if (this.__v.__k) {
            var r = document.createElement("div"), o = this.__v.__k[0].__c;
            this.__v.__k[0] = L(this.__b, r, o.__O = o.__P);
        }
        this.__b = null;
    }
    var i = e.__a && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, n.fallback);
    return i && (i.__h = null), [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, e.__a ? null : n.children),
        i
    ];
};
var W = function(n, t, e) {
    if (++e[1] === e[0] && n.o.delete(t), n.props.revealOrder && ("t" !== n.props.revealOrder[0] || !n.o.size)) for(e = n.u; e;){
        for(; e.length > 3;)e.pop()();
        if (e[1] < e[0]) break;
        n.u = e = e[2];
    }
};
function P(n) {
    return this.getChildContext = function() {
        return n.context;
    }, n.children;
}
function $(n) {
    var e = this, r = n.i;
    e.componentWillUnmount = function() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["render"])(null, e.l), e.l = null, e.i = null;
    }, e.i && e.i !== r && e.componentWillUnmount(), n.__v ? (e.l || (e.i = r, e.l = {
        nodeType: 1,
        parentNode: r,
        childNodes: [],
        appendChild: function(n) {
            this.childNodes.push(n), e.i.appendChild(n);
        },
        insertBefore: function(n, t) {
            this.childNodes.push(n), e.i.appendChild(n);
        },
        removeChild: function(n) {
            this.childNodes.splice(this.childNodes.indexOf(n) >>> 1, 1), e.i.removeChild(n);
        }
    }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["render"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(P, {
        context: e.context
    }, n.__v), e.l)) : e.l && e.componentWillUnmount();
}
function j(n, e) {
    var r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])($, {
        __v: n,
        i: e
    });
    return r.containerInfo = e, r;
}
(V.prototype = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"]).__a = function(n) {
    var t = this, e = F(t.__v), r = t.o.get(n);
    return r[0]++, function(u) {
        var o = function() {
            t.props.revealOrder ? (r.push(u), W(t, n, r)) : u();
        };
        e ? e(o) : o();
    };
}, V.prototype.render = function(n) {
    this.u = null, this.o = new Map;
    var t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toChildArray"])(n.children);
    n.revealOrder && "b" === n.revealOrder[0] && t.reverse();
    for(var e = t.length; e--;)this.o.set(t[e], this.u = [
        1,
        0,
        this.u
    ]);
    return n.children;
}, V.prototype.componentDidUpdate = V.prototype.componentDidMount = function() {
    var n = this;
    this.o.forEach(function(t, e) {
        W(n, e, t);
    });
};
var z = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103, B = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/, H = "undefined" != typeof document, Z = function(n) {
    return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/i : /fil|che|ra/i).test(n);
};
function Y(n, t, e) {
    return null == t.__k && (t.textContent = ""), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["render"])(n, t), "function" == typeof e && e(), n ? n.__c : null;
}
function q(n, t, e) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hydrate"])(n, t), "function" == typeof e && e(), n ? n.__c : null;
}
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"].prototype.isReactComponent = {}, [
    "componentWillMount",
    "componentWillReceiveProps",
    "componentWillUpdate"
].forEach(function(t) {
    Object.defineProperty(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"].prototype, t, {
        configurable: !0,
        get: function() {
            return this["UNSAFE_" + t];
        },
        set: function(n) {
            Object.defineProperty(this, t, {
                configurable: !0,
                writable: !0,
                value: n
            });
        }
    });
});
var G = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].event;
function J() {}
function K() {
    return this.cancelBubble;
}
function Q() {
    return this.defaultPrevented;
}
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].event = function(n) {
    return G && (n = G(n)), n.persist = J, n.isPropagationStopped = K, n.isDefaultPrevented = Q, n.nativeEvent = n;
};
var X, nn = {
    configurable: !0,
    get: function() {
        return this.class;
    }
}, tn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].vnode;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].vnode = function(n) {
    var t = n.type, e = n.props, u = e;
    if ("string" == typeof t) {
        var o = -1 === t.indexOf("-");
        for(var i in u = {}, e){
            var l = e[i];
            H && "children" === i && "noscript" === t || "value" === i && "defaultValue" in e && null == l || ("defaultValue" === i && "value" in e && null == e.value ? i = "value" : "download" === i && !0 === l ? l = "" : /ondoubleclick/i.test(i) ? i = "ondblclick" : /^onchange(textarea|input)/i.test(i + t) && !Z(e.type) ? i = "oninput" : /^onfocus$/i.test(i) ? i = "onfocusin" : /^onblur$/i.test(i) ? i = "onfocusout" : /^on(Ani|Tra|Tou|BeforeInp|Compo)/.test(i) ? i = i.toLowerCase() : o && B.test(i) ? i = i.replace(/[A-Z0-9]/g, "-$&").toLowerCase() : null === l && (l = void 0), /^oninput$/i.test(i) && (i = i.toLowerCase(), u[i] && (i = "oninputCapture")), u[i] = l);
        }
        "select" == t && u.multiple && Array.isArray(u.value) && (u.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toChildArray"])(e.children).forEach(function(n) {
            n.props.selected = -1 != u.value.indexOf(n.props.value);
        })), "select" == t && null != u.defaultValue && (u.value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toChildArray"])(e.children).forEach(function(n) {
            n.props.selected = u.multiple ? -1 != u.defaultValue.indexOf(n.props.value) : u.defaultValue == n.props.value;
        })), n.props = u, e.class != e.className && (nn.enumerable = "className" in e, null != e.className && (u.class = e.className), Object.defineProperty(u, "className", nn));
    }
    n.$$typeof = z, tn && tn(n);
};
var en = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__r;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["options"].__r = function(n) {
    en && en(n), X = n.__c;
};
var rn = {
    ReactCurrentDispatcher: {
        current: {
            readContext: function(n) {
                return X.__n[n.__c].props.value;
            }
        }
    }
}, un = "17.0.2";
function on(n) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"].bind(null, n);
}
function ln(n) {
    return !!n && n.$$typeof === z;
}
function cn(n) {
    return ln(n) ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cloneElement"].apply(null, arguments) : n;
}
function fn(n) {
    return !!n.__k && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["render"])(null, n), !0);
}
function an(n) {
    return n && (n.base || 1 === n.nodeType && n) || null;
}
var sn = function(n, t) {
    return n(t);
}, hn = function(n, t) {
    return n(t);
}, vn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"];
function dn(n) {
    n();
}
function pn(n) {
    return n;
}
function mn() {
    return [
        !1,
        dn
    ];
}
var yn = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"];
function _n(n, t) {
    var e = t(), r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        h: {
            __: e,
            v: t
        }
    }), u = r[0].h, o = r[1];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"])(function() {
        u.__ = e, u.v = t, E(u.__, t()) || o({
            h: u
        });
    }, [
        n,
        e,
        t
    ]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(function() {
        return E(u.__, u.v()) || o({
            h: u
        }), n(function() {
            E(u.__, u.v()) || o({
                h: u
            });
        });
    }, [
        n
    ]), e;
}
var bn = {
    useState: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"],
    useId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"],
    useReducer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"],
    useEffect: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"],
    useLayoutEffect: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLayoutEffect"],
    useInsertionEffect: yn,
    useTransition: mn,
    useDeferredValue: pn,
    useSyncExternalStore: _n,
    startTransition: dn,
    useRef: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"],
    useImperativeHandle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"],
    useMemo: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"],
    useCallback: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"],
    useContext: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"],
    useDebugValue: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$hooks$2f$dist$2f$hooks$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebugValue"],
    version: "17.0.2",
    Children: O,
    render: Y,
    hydrate: q,
    unmountComponentAtNode: fn,
    createPortal: j,
    createElement: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"],
    createContext: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"],
    createFactory: on,
    cloneElement: cn,
    createRef: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"],
    Fragment: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"],
    isValidElement: ln,
    findDOMNode: an,
    Component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"],
    PureComponent: w,
    memo: R,
    forwardRef: k,
    flushSync: hn,
    unstable_batchedUpdates: sn,
    StrictMode: vn,
    Suspense: D,
    SuspenseList: V,
    lazy: M,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: rn
};
;
}),
"[project]/node_modules/@fullcalendar/react/dist/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FullCalendar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cv__as__CustomRenderingStore$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cv as CustomRenderingStore>");
;
;
;
;
const reactMajorVersion = parseInt(String(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].version).split('.')[0]);
const syncRenderingByDefault = reactMajorVersion < 18;
class FullCalendar extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Component"] {
    constructor(){
        super(...arguments);
        this.elRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.isUpdating = false;
        this.isUnmounting = false;
        this.state = {
            customRenderingMap: new Map()
        };
        this.requestResize = ()=>{
            if (!this.isUnmounting) {
                this.cancelResize();
                this.resizeId = requestAnimationFrame(()=>{
                    this.doResize();
                });
            }
        };
    }
    render() {
        const customRenderingNodes = [];
        for (const customRendering of this.state.customRenderingMap.values()){
            customRenderingNodes.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(CustomRenderingComponent, {
                key: customRendering.id,
                customRendering: customRendering
            }));
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("div", {
            ref: this.elRef
        }, customRenderingNodes);
    }
    componentDidMount() {
        // reset b/c react strict-mode calls componentWillUnmount/componentDidMount
        this.isUnmounting = false;
        const customRenderingStore = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cv__as__CustomRenderingStore$3e$__["CustomRenderingStore"]();
        this.handleCustomRendering = customRenderingStore.handle.bind(customRenderingStore);
        this.calendar = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Calendar"](this.elRef.current, Object.assign(Object.assign({}, this.props), {
            handleCustomRendering: this.handleCustomRendering
        }));
        this.calendar.render();
        // attaching with .on() will cause this to fire AFTER internal preact rendering did flushSync
        this.calendar.on('_beforeprint', ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"])(()=>{
            // our `customRenderingMap` state will be flushed at this point
            });
        });
        let lastRequestTimestamp;
        customRenderingStore.subscribe((customRenderingMap)=>{
            const requestTimestamp = Date.now();
            const isMounting = !lastRequestTimestamp;
            const runFunc = // don't call flushSync if React version already does sync rendering by default
            // guards against fatal errors:
            // https://github.com/fullcalendar/fullcalendar/issues/7448
            syncRenderingByDefault || //
            isMounting || this.isUpdating || this.isUnmounting || requestTimestamp - lastRequestTimestamp < 100 // rerendering frequently
             ? runNow // either sync rendering (first-time or React 16/17) or async (React 18)
             : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["flushSync"]; // guaranteed sync rendering
            runFunc(()=>{
                this.setState({
                    customRenderingMap
                }, ()=>{
                    lastRequestTimestamp = requestTimestamp;
                    if (isMounting) {
                        this.doResize();
                    } else {
                        this.requestResize();
                    }
                });
            });
        });
    }
    componentDidUpdate() {
        this.isUpdating = true;
        this.calendar.resetOptions(Object.assign(Object.assign({}, this.props), {
            handleCustomRendering: this.handleCustomRendering
        }));
        this.isUpdating = false;
    }
    componentWillUnmount() {
        this.isUnmounting = true;
        this.cancelResize();
        this.calendar.destroy();
    }
    doResize() {
        this.calendar.updateSize();
    }
    cancelResize() {
        if (this.resizeId !== undefined) {
            cancelAnimationFrame(this.resizeId);
            this.resizeId = undefined;
        }
    }
    getApi() {
        return this.calendar;
    }
}
FullCalendar.act = runNow; // DEPRECATED. Not leveraged anymore
class CustomRenderingComponent extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PureComponent"] {
    render() {
        const { customRendering } = this.props;
        const { generatorMeta } = customRendering;
        const vnode = typeof generatorMeta === 'function' ? generatorMeta(customRendering.renderProps) : generatorMeta;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(vnode, customRendering.containerEl);
    }
}
// Util
// -------------------------------------------------------------------------------------------------
function runNow(f) {
    f();
}
}),
"[project]/node_modules/@fullcalendar/daygrid/internal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DayGridView",
    ()=>DayTableView,
    "DayTable",
    ()=>DayTable,
    "DayTableSlicer",
    ()=>DayTableSlicer,
    "Table",
    ()=>Table,
    "TableDateProfileGenerator",
    ()=>TableDateProfileGenerator,
    "TableRows",
    ()=>TableRows,
    "TableView",
    ()=>TableView,
    "buildDayTableModel",
    ()=>buildDayTableModel,
    "buildDayTableRenderRange",
    ()=>buildDayTableRenderRange
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bc as DateComponent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ca__as__getStickyHeaderDates$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ca as getStickyHeaderDates>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cq__as__ViewContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cq as ViewContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bZ__as__SimpleScrollGrid$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bZ as SimpleScrollGrid>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c9__as__getStickyFooterScrollbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export c9 as getStickyFooterScrollbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c8__as__renderScrollShim$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export c8 as renderScrollShim>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export x as createFormatter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export B as BaseComponent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cg__as__StandardEvent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cg as StandardEvent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bO__as__buildSegTimeText$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bO as buildSegTimeText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ck__as__EventContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ck as EventContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bS__as__getSegAnchorAttrs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bS as getSegAnchorAttrs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export z as memoize>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__co__as__MoreLinkContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export co as MoreLinkContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bQ as getSegMeta>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a3__as__getUniqueDomId$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export a3 as getUniqueDomId>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__W__as__setRef$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export W as setRef>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ci__as__DayCellContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ci as DayCellContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cn__as__WeekNumberContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cn as WeekNumberContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a___as__buildNavLinkAttrs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export a_ as buildNavLinkAttrs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cj__as__hasCustomDayCellContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cj as hasCustomDayCellContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__be__as__addMs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export be as addMs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__o__as__intersectRanges$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export o as intersectRanges>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__t__as__addDays$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export t as addDays>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__by__as__SegHierarchy$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export by as SegHierarchy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bz__as__buildEntryKey$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bz as buildEntryKey>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bD__as__intersectSpans$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bD as intersectSpans>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cd__as__RefMap$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cd as RefMap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bP__as__sortEventSegs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bP as sortEventSegs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__E__as__isPropsEqual$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export E as isPropsEqual>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bR__as__buildEventRangeKey$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bR as buildEventRangeKey>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cm__as__BgEvent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cm as BgEvent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cl__as__renderFill$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cl as renderFill>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b8__as__PositionCache$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export b8 as PositionCache>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a6__as__NowTimer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export a6 as NowTimer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bv__as__formatIsoMonthStr$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bv as formatIsoMonthStr>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bt__as__formatDayString$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bt as formatDayString>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bU__as__Slicer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bU as Slicer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bI__as__DayHeader$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bI as DayHeader>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bM__as__DaySeriesModel$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bM as DaySeriesModel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bT__as__DayTableModel$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bT as DayTableModel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__R__as__DateProfileGenerator$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export R as DateProfileGenerator>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bf__as__addWeeks$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bf as addWeeks>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bg__as__diffWeeks$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bg as diffWeeks>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ct__as__injectStyles$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ct as injectStyles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/preact/dist/preact.module.js [app-client] (ecmascript)");
;
;
/* An abstract class for the daygrid views, as well as month view. Renders one or more rows of day cells.
----------------------------------------------------------------------------------------------------------------------*/ // It is a manager for a Table subcomponent, which does most of the heavy lifting.
// It is responsible for managing width/height.
class TableView extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.headerElRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
    }
    renderSimpleLayout(headerRowContent, bodyContent) {
        let { props, context } = this;
        let sections = [];
        let stickyHeaderDates = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ca__as__getStickyHeaderDates$3e$__["getStickyHeaderDates"])(context.options);
        if (headerRowContent) {
            sections.push({
                type: 'header',
                key: 'header',
                isSticky: stickyHeaderDates,
                chunk: {
                    elRef: this.headerElRef,
                    tableClassName: 'fc-col-header',
                    rowContent: headerRowContent
                }
            });
        }
        sections.push({
            type: 'body',
            key: 'body',
            liquid: true,
            chunk: {
                content: bodyContent
            }
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cq__as__ViewContainer$3e$__["ViewContainer"], {
            elClasses: [
                'fc-daygrid'
            ],
            viewSpec: context.viewSpec
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bZ__as__SimpleScrollGrid$3e$__["SimpleScrollGrid"], {
            liquid: !props.isHeightAuto && !props.forPrint,
            collapsibleWidth: props.forPrint,
            cols: [],
            sections: sections
        }));
    }
    renderHScrollLayout(headerRowContent, bodyContent, colCnt, dayMinWidth) {
        let ScrollGrid = this.context.pluginHooks.scrollGridImpl;
        if (!ScrollGrid) {
            throw new Error('No ScrollGrid implementation');
        }
        let { props, context } = this;
        let stickyHeaderDates = !props.forPrint && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ca__as__getStickyHeaderDates$3e$__["getStickyHeaderDates"])(context.options);
        let stickyFooterScrollbar = !props.forPrint && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c9__as__getStickyFooterScrollbar$3e$__["getStickyFooterScrollbar"])(context.options);
        let sections = [];
        if (headerRowContent) {
            sections.push({
                type: 'header',
                key: 'header',
                isSticky: stickyHeaderDates,
                chunks: [
                    {
                        key: 'main',
                        elRef: this.headerElRef,
                        tableClassName: 'fc-col-header',
                        rowContent: headerRowContent
                    }
                ]
            });
        }
        sections.push({
            type: 'body',
            key: 'body',
            liquid: true,
            chunks: [
                {
                    key: 'main',
                    content: bodyContent
                }
            ]
        });
        if (stickyFooterScrollbar) {
            sections.push({
                type: 'footer',
                key: 'footer',
                isSticky: true,
                chunks: [
                    {
                        key: 'main',
                        content: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c8__as__renderScrollShim$3e$__["renderScrollShim"]
                    }
                ]
            });
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cq__as__ViewContainer$3e$__["ViewContainer"], {
            elClasses: [
                'fc-daygrid'
            ],
            viewSpec: context.viewSpec
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(ScrollGrid, {
            liquid: !props.isHeightAuto && !props.forPrint,
            forPrint: props.forPrint,
            collapsibleWidth: props.forPrint,
            colGroups: [
                {
                    cols: [
                        {
                            span: colCnt,
                            minWidth: dayMinWidth
                        }
                    ]
                }
            ],
            sections: sections
        }));
    }
}
function splitSegsByRow(segs, rowCnt) {
    let byRow = [];
    for(let i = 0; i < rowCnt; i += 1){
        byRow[i] = [];
    }
    for (let seg of segs){
        byRow[seg.row].push(seg);
    }
    return byRow;
}
function splitSegsByFirstCol(segs, colCnt) {
    let byCol = [];
    for(let i = 0; i < colCnt; i += 1){
        byCol[i] = [];
    }
    for (let seg of segs){
        byCol[seg.firstCol].push(seg);
    }
    return byCol;
}
function splitInteractionByRow(ui, rowCnt) {
    let byRow = [];
    if (!ui) {
        for(let i = 0; i < rowCnt; i += 1){
            byRow[i] = null;
        }
    } else {
        for(let i = 0; i < rowCnt; i += 1){
            byRow[i] = {
                affectedInstances: ui.affectedInstances,
                isEvent: ui.isEvent,
                segs: []
            };
        }
        for (let seg of ui.segs){
            byRow[seg.row].segs.push(seg);
        }
    }
    return byRow;
}
const DEFAULT_TABLE_EVENT_TIME_FORMAT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__["createFormatter"])({
    hour: 'numeric',
    minute: '2-digit',
    omitZeroMinute: true,
    meridiem: 'narrow'
});
function hasListItemDisplay(seg) {
    let { display } = seg.eventRange.ui;
    return display === 'list-item' || display === 'auto' && !seg.eventRange.def.allDay && seg.firstCol === seg.lastCol && // can't be multi-day
    seg.isStart && // "
    seg.isEnd // "
    ;
}
class TableBlockEvent extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    render() {
        let { props } = this;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cg__as__StandardEvent$3e$__["StandardEvent"], Object.assign({}, props, {
            elClasses: [
                'fc-daygrid-event',
                'fc-daygrid-block-event',
                'fc-h-event'
            ],
            defaultTimeFormat: DEFAULT_TABLE_EVENT_TIME_FORMAT,
            defaultDisplayEventEnd: props.defaultDisplayEventEnd,
            disableResizing: !props.seg.eventRange.def.allDay
        }));
    }
}
class TableListItemEvent extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    render() {
        let { props, context } = this;
        let { options } = context;
        let { seg } = props;
        let timeFormat = options.eventTimeFormat || DEFAULT_TABLE_EVENT_TIME_FORMAT;
        let timeText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bO__as__buildSegTimeText$3e$__["buildSegTimeText"])(seg, timeFormat, context, true, props.defaultDisplayEventEnd);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ck__as__EventContainer$3e$__["EventContainer"], Object.assign({}, props, {
            elTag: "a",
            elClasses: [
                'fc-daygrid-event',
                'fc-daygrid-dot-event'
            ],
            elAttrs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bS__as__getSegAnchorAttrs$3e$__["getSegAnchorAttrs"])(props.seg, context),
            defaultGenerator: renderInnerContent,
            timeText: timeText,
            isResizing: false,
            isDateSelecting: false
        }));
    }
}
function renderInnerContent(renderProps) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
        className: "fc-daygrid-event-dot",
        style: {
            borderColor: renderProps.borderColor || renderProps.backgroundColor
        }
    }), renderProps.timeText && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
        className: "fc-event-time"
    }, renderProps.timeText), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
        className: "fc-event-title"
    }, renderProps.event.title || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, "\u00A0")));
}
class TableCellMoreLink extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    constructor(){
        super(...arguments);
        this.compileSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(compileSegs);
    }
    render() {
        let { props } = this;
        let { allSegs, invisibleSegs } = this.compileSegs(props.singlePlacements);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__co__as__MoreLinkContainer$3e$__["MoreLinkContainer"], {
            elClasses: [
                'fc-daygrid-more-link'
            ],
            dateProfile: props.dateProfile,
            todayRange: props.todayRange,
            allDayDate: props.allDayDate,
            moreCnt: props.moreCnt,
            allSegs: allSegs,
            hiddenSegs: invisibleSegs,
            alignmentElRef: props.alignmentElRef,
            alignGridTop: props.alignGridTop,
            extraDateSpan: props.extraDateSpan,
            popoverContent: ()=>{
                let isForcedInvisible = (props.eventDrag ? props.eventDrag.affectedInstances : null) || (props.eventResize ? props.eventResize.affectedInstances : null) || {};
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, allSegs.map((seg)=>{
                    let instanceId = seg.eventRange.instance.instanceId;
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                        className: "fc-daygrid-event-harness",
                        key: instanceId,
                        style: {
                            visibility: isForcedInvisible[instanceId] ? 'hidden' : ''
                        }
                    }, hasListItemDisplay(seg) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TableListItemEvent, Object.assign({
                        seg: seg,
                        isDragging: false,
                        isSelected: instanceId === props.eventSelection,
                        defaultDisplayEventEnd: false
                    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__["getSegMeta"])(seg, props.todayRange))) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TableBlockEvent, Object.assign({
                        seg: seg,
                        isDragging: false,
                        isResizing: false,
                        isDateSelecting: false,
                        isSelected: instanceId === props.eventSelection,
                        defaultDisplayEventEnd: false
                    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__["getSegMeta"])(seg, props.todayRange))));
                }));
            }
        });
    }
}
function compileSegs(singlePlacements) {
    let allSegs = [];
    let invisibleSegs = [];
    for (let placement of singlePlacements){
        allSegs.push(placement.seg);
        if (!placement.isVisible) {
            invisibleSegs.push(placement.seg);
        }
    }
    return {
        allSegs,
        invisibleSegs
    };
}
const DEFAULT_WEEK_NUM_FORMAT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__["createFormatter"])({
    week: 'narrow'
});
class TableCell extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.rootElRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.state = {
            dayNumberId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a3__as__getUniqueDomId$3e$__["getUniqueDomId"])()
        };
        this.handleRootEl = (el)=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__W__as__setRef$3e$__["setRef"])(this.rootElRef, el);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__W__as__setRef$3e$__["setRef"])(this.props.elRef, el);
        };
    }
    render() {
        let { context, props, state, rootElRef } = this;
        let { options, dateEnv } = context;
        let { date, dateProfile } = props;
        // TODO: memoize this?
        const isMonthStart = props.showDayNumber && shouldDisplayMonthStart(date, dateProfile.currentRange, dateEnv);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ci__as__DayCellContainer$3e$__["DayCellContainer"], {
            elTag: "td",
            elRef: this.handleRootEl,
            elClasses: [
                'fc-daygrid-day',
                ...props.extraClassNames || []
            ],
            elAttrs: Object.assign(Object.assign(Object.assign({}, props.extraDataAttrs), props.showDayNumber ? {
                'aria-labelledby': state.dayNumberId
            } : {}), {
                role: 'gridcell'
            }),
            defaultGenerator: renderTopInner,
            date: date,
            dateProfile: dateProfile,
            todayRange: props.todayRange,
            showDayNumber: props.showDayNumber,
            isMonthStart: isMonthStart,
            extraRenderProps: props.extraRenderProps
        }, (InnerContent, renderProps)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                ref: props.innerElRef,
                className: "fc-daygrid-day-frame fc-scrollgrid-sync-inner",
                style: {
                    minHeight: props.minHeight
                }
            }, props.showWeekNumber && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cn__as__WeekNumberContainer$3e$__["WeekNumberContainer"], {
                elTag: "a",
                elClasses: [
                    'fc-daygrid-week-number'
                ],
                elAttrs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a___as__buildNavLinkAttrs$3e$__["buildNavLinkAttrs"])(context, date, 'week'),
                date: date,
                defaultFormat: DEFAULT_WEEK_NUM_FORMAT
            }), !renderProps.isDisabled && (props.showDayNumber || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cj__as__hasCustomDayCellContent$3e$__["hasCustomDayCellContent"])(options) || props.forceDayTop) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-daygrid-day-top"
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(InnerContent, {
                elTag: "a",
                elClasses: [
                    'fc-daygrid-day-number',
                    isMonthStart && 'fc-daygrid-month-start'
                ],
                elAttrs: Object.assign(Object.assign({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a___as__buildNavLinkAttrs$3e$__["buildNavLinkAttrs"])(context, date)), {
                    id: state.dayNumberId
                })
            })) : props.showDayNumber ? // for creating correct amount of space (see issue #7162)
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-daygrid-day-top",
                style: {
                    visibility: 'hidden'
                }
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("a", {
                className: "fc-daygrid-day-number"
            }, "\u00A0")) : undefined, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-daygrid-day-events",
                ref: props.fgContentElRef
            }, props.fgContent, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-daygrid-day-bottom",
                style: {
                    marginTop: props.moreMarginTop
                }
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TableCellMoreLink, {
                allDayDate: date,
                singlePlacements: props.singlePlacements,
                moreCnt: props.moreCnt,
                alignmentElRef: rootElRef,
                alignGridTop: !props.showDayNumber,
                extraDateSpan: props.extraDateSpan,
                dateProfile: props.dateProfile,
                eventSelection: props.eventSelection,
                eventDrag: props.eventDrag,
                eventResize: props.eventResize,
                todayRange: props.todayRange
            }))), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-daygrid-day-bg"
            }, props.bgContent)));
    }
}
function renderTopInner(props) {
    return props.dayNumberText || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, "\u00A0");
}
function shouldDisplayMonthStart(date, currentRange, dateEnv) {
    const { start: currentStart, end: currentEnd } = currentRange;
    const currentEndIncl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__be__as__addMs$3e$__["addMs"])(currentEnd, -1);
    const currentFirstYear = dateEnv.getYear(currentStart);
    const currentFirstMonth = dateEnv.getMonth(currentStart);
    const currentLastYear = dateEnv.getYear(currentEndIncl);
    const currentLastMonth = dateEnv.getMonth(currentEndIncl);
    // spans more than one month?
    return !(currentFirstYear === currentLastYear && currentFirstMonth === currentLastMonth) && Boolean(// first date in current view?
    date.valueOf() === currentStart.valueOf() || dateEnv.getDay(date) === 1 && date.valueOf() < currentEnd.valueOf());
}
function generateSegKey(seg) {
    return seg.eventRange.instance.instanceId + ':' + seg.firstCol;
}
function generateSegUid(seg) {
    return generateSegKey(seg) + ':' + seg.lastCol;
}
function computeFgSegPlacement(segs, dayMaxEvents, dayMaxEventRows, strictOrder, segHeights, maxContentHeight, cells) {
    let hierarchy = new DayGridSegHierarchy((segEntry)=>{
        // TODO: more DRY with generateSegUid
        let segUid = segs[segEntry.index].eventRange.instance.instanceId + ':' + segEntry.span.start + ':' + (segEntry.span.end - 1);
        // if no thickness known, assume 1 (if 0, so small it always fits)
        return segHeights[segUid] || 1;
    });
    hierarchy.allowReslicing = true;
    hierarchy.strictOrder = strictOrder;
    if (dayMaxEvents === true || dayMaxEventRows === true) {
        hierarchy.maxCoord = maxContentHeight;
        hierarchy.hiddenConsumes = true;
    } else if (typeof dayMaxEvents === 'number') {
        hierarchy.maxStackCnt = dayMaxEvents;
    } else if (typeof dayMaxEventRows === 'number') {
        hierarchy.maxStackCnt = dayMaxEventRows;
        hierarchy.hiddenConsumes = true;
    }
    // create segInputs only for segs with known heights
    let segInputs = [];
    let unknownHeightSegs = [];
    for(let i = 0; i < segs.length; i += 1){
        let seg = segs[i];
        let segUid = generateSegUid(seg);
        let eventHeight = segHeights[segUid];
        if (eventHeight != null) {
            segInputs.push({
                index: i,
                span: {
                    start: seg.firstCol,
                    end: seg.lastCol + 1
                }
            });
        } else {
            unknownHeightSegs.push(seg);
        }
    }
    let hiddenEntries = hierarchy.addSegs(segInputs);
    let segRects = hierarchy.toRects();
    let { singleColPlacements, multiColPlacements, leftoverMargins } = placeRects(segRects, segs, cells);
    let moreCnts = [];
    let moreMarginTops = [];
    // add segs with unknown heights
    for (let seg of unknownHeightSegs){
        multiColPlacements[seg.firstCol].push({
            seg,
            isVisible: false,
            isAbsolute: true,
            absoluteTop: 0,
            marginTop: 0
        });
        for(let col = seg.firstCol; col <= seg.lastCol; col += 1){
            singleColPlacements[col].push({
                seg: resliceSeg(seg, col, col + 1, cells),
                isVisible: false,
                isAbsolute: false,
                absoluteTop: 0,
                marginTop: 0
            });
        }
    }
    // add the hidden entries
    for(let col = 0; col < cells.length; col += 1){
        moreCnts.push(0);
    }
    for (let hiddenEntry of hiddenEntries){
        let seg = segs[hiddenEntry.index];
        let hiddenSpan = hiddenEntry.span;
        multiColPlacements[hiddenSpan.start].push({
            seg: resliceSeg(seg, hiddenSpan.start, hiddenSpan.end, cells),
            isVisible: false,
            isAbsolute: true,
            absoluteTop: 0,
            marginTop: 0
        });
        for(let col = hiddenSpan.start; col < hiddenSpan.end; col += 1){
            moreCnts[col] += 1;
            singleColPlacements[col].push({
                seg: resliceSeg(seg, col, col + 1, cells),
                isVisible: false,
                isAbsolute: false,
                absoluteTop: 0,
                marginTop: 0
            });
        }
    }
    // deal with leftover margins
    for(let col = 0; col < cells.length; col += 1){
        moreMarginTops.push(leftoverMargins[col]);
    }
    return {
        singleColPlacements,
        multiColPlacements,
        moreCnts,
        moreMarginTops
    };
}
// rects ordered by top coord, then left
function placeRects(allRects, segs, cells) {
    let rectsByEachCol = groupRectsByEachCol(allRects, cells.length);
    let singleColPlacements = [];
    let multiColPlacements = [];
    let leftoverMargins = [];
    for(let col = 0; col < cells.length; col += 1){
        let rects = rectsByEachCol[col];
        // compute all static segs in singlePlacements
        let singlePlacements = [];
        let currentHeight = 0;
        let currentMarginTop = 0;
        for (let rect of rects){
            let seg = segs[rect.index];
            singlePlacements.push({
                seg: resliceSeg(seg, col, col + 1, cells),
                isVisible: true,
                isAbsolute: false,
                absoluteTop: rect.levelCoord,
                marginTop: rect.levelCoord - currentHeight
            });
            currentHeight = rect.levelCoord + rect.thickness;
        }
        // compute mixed static/absolute segs in multiPlacements
        let multiPlacements = [];
        currentHeight = 0;
        currentMarginTop = 0;
        for (let rect of rects){
            let seg = segs[rect.index];
            let isAbsolute = rect.span.end - rect.span.start > 1; // multi-column?
            let isFirstCol = rect.span.start === col;
            currentMarginTop += rect.levelCoord - currentHeight; // amount of space since bottom of previous seg
            currentHeight = rect.levelCoord + rect.thickness; // height will now be bottom of current seg
            if (isAbsolute) {
                currentMarginTop += rect.thickness;
                if (isFirstCol) {
                    multiPlacements.push({
                        seg: resliceSeg(seg, rect.span.start, rect.span.end, cells),
                        isVisible: true,
                        isAbsolute: true,
                        absoluteTop: rect.levelCoord,
                        marginTop: 0
                    });
                }
            } else if (isFirstCol) {
                multiPlacements.push({
                    seg: resliceSeg(seg, rect.span.start, rect.span.end, cells),
                    isVisible: true,
                    isAbsolute: false,
                    absoluteTop: rect.levelCoord,
                    marginTop: currentMarginTop
                });
                currentMarginTop = 0;
            }
        }
        singleColPlacements.push(singlePlacements);
        multiColPlacements.push(multiPlacements);
        leftoverMargins.push(currentMarginTop);
    }
    return {
        singleColPlacements,
        multiColPlacements,
        leftoverMargins
    };
}
function groupRectsByEachCol(rects, colCnt) {
    let rectsByEachCol = [];
    for(let col = 0; col < colCnt; col += 1){
        rectsByEachCol.push([]);
    }
    for (let rect of rects){
        for(let col = rect.span.start; col < rect.span.end; col += 1){
            rectsByEachCol[col].push(rect);
        }
    }
    return rectsByEachCol;
}
function resliceSeg(seg, spanStart, spanEnd, cells) {
    if (seg.firstCol === spanStart && seg.lastCol === spanEnd - 1) {
        return seg;
    }
    let eventRange = seg.eventRange;
    let origRange = eventRange.range;
    let slicedRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__o__as__intersectRanges$3e$__["intersectRanges"])(origRange, {
        start: cells[spanStart].date,
        end: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__t__as__addDays$3e$__["addDays"])(cells[spanEnd - 1].date, 1)
    });
    return Object.assign(Object.assign({}, seg), {
        firstCol: spanStart,
        lastCol: spanEnd - 1,
        eventRange: {
            def: eventRange.def,
            ui: Object.assign(Object.assign({}, eventRange.ui), {
                durationEditable: false
            }),
            instance: eventRange.instance,
            range: slicedRange
        },
        isStart: seg.isStart && slicedRange.start.valueOf() === origRange.start.valueOf(),
        isEnd: seg.isEnd && slicedRange.end.valueOf() === origRange.end.valueOf()
    });
}
class DayGridSegHierarchy extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__by__as__SegHierarchy$3e$__["SegHierarchy"] {
    constructor(){
        super(...arguments);
        // config
        this.hiddenConsumes = false;
        // allows us to keep hidden entries in the hierarchy so they take up space
        this.forceHidden = {};
    }
    addSegs(segInputs) {
        const hiddenSegs = super.addSegs(segInputs);
        const { entriesByLevel } = this;
        const excludeHidden = (entry)=>!this.forceHidden[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bz__as__buildEntryKey$3e$__["buildEntryKey"])(entry)];
        // remove the forced-hidden segs
        for(let level = 0; level < entriesByLevel.length; level += 1){
            entriesByLevel[level] = entriesByLevel[level].filter(excludeHidden);
        }
        return hiddenSegs;
    }
    handleInvalidInsertion(insertion, entry, hiddenEntries) {
        const { entriesByLevel, forceHidden } = this;
        const { touchingEntry, touchingLevel, touchingLateral } = insertion;
        // the entry that the new insertion is touching must be hidden
        if (this.hiddenConsumes && touchingEntry) {
            const touchingEntryId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bz__as__buildEntryKey$3e$__["buildEntryKey"])(touchingEntry);
            if (!forceHidden[touchingEntryId]) {
                if (this.allowReslicing) {
                    // split up the touchingEntry, reinsert it
                    const hiddenEntry = Object.assign(Object.assign({}, touchingEntry), {
                        span: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bD__as__intersectSpans$3e$__["intersectSpans"])(touchingEntry.span, entry.span)
                    });
                    // reinsert the area that turned into a "more" link (so no other entries try to
                    // occupy the space) but mark it forced-hidden
                    const hiddenEntryId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bz__as__buildEntryKey$3e$__["buildEntryKey"])(hiddenEntry);
                    forceHidden[hiddenEntryId] = true;
                    entriesByLevel[touchingLevel][touchingLateral] = hiddenEntry;
                    hiddenEntries.push(hiddenEntry);
                    this.splitEntry(touchingEntry, entry, hiddenEntries);
                } else {
                    forceHidden[touchingEntryId] = true;
                    hiddenEntries.push(touchingEntry);
                }
            }
        }
        // will try to reslice...
        super.handleInvalidInsertion(insertion, entry, hiddenEntries);
    }
}
class TableRow extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.cellElRefs = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cd__as__RefMap$3e$__["RefMap"](); // the <td>
        this.frameElRefs = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cd__as__RefMap$3e$__["RefMap"](); // the fc-daygrid-day-frame
        this.fgElRefs = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cd__as__RefMap$3e$__["RefMap"](); // the fc-daygrid-day-events
        this.segHarnessRefs = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cd__as__RefMap$3e$__["RefMap"](); // indexed by "instanceId:firstCol"
        this.rootElRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.state = {
            framePositions: null,
            maxContentHeight: null,
            segHeights: {}
        };
        this.handleResize = (isForced)=>{
            if (isForced) {
                this.updateSizing(true); // isExternal=true
            }
        };
    }
    render() {
        let { props, state, context } = this;
        let { options } = context;
        let colCnt = props.cells.length;
        let businessHoursByCol = splitSegsByFirstCol(props.businessHourSegs, colCnt);
        let bgEventSegsByCol = splitSegsByFirstCol(props.bgEventSegs, colCnt);
        let highlightSegsByCol = splitSegsByFirstCol(this.getHighlightSegs(), colCnt);
        let mirrorSegsByCol = splitSegsByFirstCol(this.getMirrorSegs(), colCnt);
        let { singleColPlacements, multiColPlacements, moreCnts, moreMarginTops } = computeFgSegPlacement((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bP__as__sortEventSegs$3e$__["sortEventSegs"])(props.fgEventSegs, options.eventOrder), props.dayMaxEvents, props.dayMaxEventRows, options.eventOrderStrict, state.segHeights, state.maxContentHeight, props.cells);
        let isForcedInvisible = props.eventDrag && props.eventDrag.affectedInstances || props.eventResize && props.eventResize.affectedInstances || {};
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tr", {
            ref: this.rootElRef,
            role: "row"
        }, props.renderIntro && props.renderIntro(), props.cells.map((cell, col)=>{
            let normalFgNodes = this.renderFgSegs(col, props.forPrint ? singleColPlacements[col] : multiColPlacements[col], props.todayRange, isForcedInvisible);
            let mirrorFgNodes = this.renderFgSegs(col, buildMirrorPlacements(mirrorSegsByCol[col], multiColPlacements), props.todayRange, {}, Boolean(props.eventDrag), Boolean(props.eventResize), false);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TableCell, {
                key: cell.key,
                elRef: this.cellElRefs.createRef(cell.key),
                innerElRef: this.frameElRefs.createRef(cell.key),
                dateProfile: props.dateProfile,
                date: cell.date,
                showDayNumber: props.showDayNumbers,
                showWeekNumber: props.showWeekNumbers && col === 0,
                forceDayTop: props.showWeekNumbers /* even displaying weeknum for row, not necessarily day */ ,
                todayRange: props.todayRange,
                eventSelection: props.eventSelection,
                eventDrag: props.eventDrag,
                eventResize: props.eventResize,
                extraRenderProps: cell.extraRenderProps,
                extraDataAttrs: cell.extraDataAttrs,
                extraClassNames: cell.extraClassNames,
                extraDateSpan: cell.extraDateSpan,
                moreCnt: moreCnts[col],
                moreMarginTop: moreMarginTops[col],
                singlePlacements: singleColPlacements[col],
                fgContentElRef: this.fgElRefs.createRef(cell.key),
                fgContent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, normalFgNodes), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, mirrorFgNodes)),
                bgContent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, this.renderFillSegs(highlightSegsByCol[col], 'highlight'), this.renderFillSegs(businessHoursByCol[col], 'non-business'), this.renderFillSegs(bgEventSegsByCol[col], 'bg-event')),
                minHeight: props.cellMinHeight
            });
        }));
    }
    componentDidMount() {
        this.updateSizing(true);
        this.context.addResizeHandler(this.handleResize);
    }
    componentDidUpdate(prevProps, prevState) {
        let currentProps = this.props;
        this.updateSizing(!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__E__as__isPropsEqual$3e$__["isPropsEqual"])(prevProps, currentProps));
    }
    componentWillUnmount() {
        this.context.removeResizeHandler(this.handleResize);
    }
    getHighlightSegs() {
        let { props } = this;
        if (props.eventDrag && props.eventDrag.segs.length) {
            return props.eventDrag.segs;
        }
        if (props.eventResize && props.eventResize.segs.length) {
            return props.eventResize.segs;
        }
        return props.dateSelectionSegs;
    }
    getMirrorSegs() {
        let { props } = this;
        if (props.eventResize && props.eventResize.segs.length) {
            return props.eventResize.segs;
        }
        return [];
    }
    renderFgSegs(col, segPlacements, todayRange, isForcedInvisible, isDragging, isResizing, isDateSelecting) {
        let { context } = this;
        let { eventSelection } = this.props;
        let { framePositions } = this.state;
        let defaultDisplayEventEnd = this.props.cells.length === 1; // colCnt === 1
        let isMirror = isDragging || isResizing || isDateSelecting;
        let nodes = [];
        if (framePositions) {
            for (let placement of segPlacements){
                let { seg } = placement;
                let { instanceId } = seg.eventRange.instance;
                let isVisible = placement.isVisible && !isForcedInvisible[instanceId];
                let isAbsolute = placement.isAbsolute;
                let left = '';
                let right = '';
                if (isAbsolute) {
                    if (context.isRtl) {
                        right = 0;
                        left = framePositions.lefts[seg.lastCol] - framePositions.lefts[seg.firstCol];
                    } else {
                        left = 0;
                        right = framePositions.rights[seg.firstCol] - framePositions.rights[seg.lastCol];
                    }
                }
                /*
                known bug: events that are force to be list-item but span multiple days still take up space in later columns
                todo: in print view, for multi-day events, don't display title within non-start/end segs
                */ nodes.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                    className: 'fc-daygrid-event-harness' + (isAbsolute ? ' fc-daygrid-event-harness-abs' : ''),
                    key: generateSegKey(seg),
                    ref: isMirror ? null : this.segHarnessRefs.createRef(generateSegUid(seg)),
                    style: {
                        visibility: isVisible ? '' : 'hidden',
                        marginTop: isAbsolute ? '' : placement.marginTop,
                        top: isAbsolute ? placement.absoluteTop : '',
                        left,
                        right
                    }
                }, hasListItemDisplay(seg) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TableListItemEvent, Object.assign({
                    seg: seg,
                    isDragging: isDragging,
                    isSelected: instanceId === eventSelection,
                    defaultDisplayEventEnd: defaultDisplayEventEnd
                }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__["getSegMeta"])(seg, todayRange))) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TableBlockEvent, Object.assign({
                    seg: seg,
                    isDragging: isDragging,
                    isResizing: isResizing,
                    isDateSelecting: isDateSelecting,
                    isSelected: instanceId === eventSelection,
                    defaultDisplayEventEnd: defaultDisplayEventEnd
                }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__["getSegMeta"])(seg, todayRange)))));
            }
        }
        return nodes;
    }
    renderFillSegs(segs, fillType) {
        let { isRtl } = this.context;
        let { todayRange } = this.props;
        let { framePositions } = this.state;
        let nodes = [];
        if (framePositions) {
            for (let seg of segs){
                let leftRightCss = isRtl ? {
                    right: 0,
                    left: framePositions.lefts[seg.lastCol] - framePositions.lefts[seg.firstCol]
                } : {
                    left: 0,
                    right: framePositions.rights[seg.firstCol] - framePositions.rights[seg.lastCol]
                };
                nodes.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                    key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bR__as__buildEventRangeKey$3e$__["buildEventRangeKey"])(seg.eventRange),
                    className: "fc-daygrid-bg-harness",
                    style: leftRightCss
                }, fillType === 'bg-event' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cm__as__BgEvent$3e$__["BgEvent"], Object.assign({
                    seg: seg
                }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__["getSegMeta"])(seg, todayRange))) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cl__as__renderFill$3e$__["renderFill"])(fillType)));
            }
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {}, ...nodes);
    }
    updateSizing(isExternalSizingChange) {
        let { props, state, frameElRefs } = this;
        if (!props.forPrint && props.clientWidth !== null // positioning ready?
        ) {
            if (isExternalSizingChange) {
                let frameEls = props.cells.map((cell)=>frameElRefs.currentMap[cell.key]);
                if (frameEls.length) {
                    let originEl = this.rootElRef.current;
                    let newPositionCache = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b8__as__PositionCache$3e$__["PositionCache"](originEl, frameEls, true, false);
                    if (!state.framePositions || !state.framePositions.similarTo(newPositionCache)) {
                        this.setState({
                            framePositions: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b8__as__PositionCache$3e$__["PositionCache"](originEl, frameEls, true, false)
                        });
                    }
                }
            }
            const oldSegHeights = this.state.segHeights;
            const newSegHeights = this.querySegHeights();
            const limitByContentHeight = props.dayMaxEvents === true || props.dayMaxEventRows === true;
            this.safeSetState({
                // HACK to prevent oscillations of events being shown/hidden from max-event-rows
                // Essentially, once you compute an element's height, never null-out.
                // TODO: always display all events, as visibility:hidden?
                segHeights: Object.assign(Object.assign({}, oldSegHeights), newSegHeights),
                maxContentHeight: limitByContentHeight ? this.computeMaxContentHeight() : null
            });
        }
    }
    querySegHeights() {
        let segElMap = this.segHarnessRefs.currentMap;
        let segHeights = {};
        // get the max height amongst instance segs
        for(let segUid in segElMap){
            let height = Math.round(segElMap[segUid].getBoundingClientRect().height);
            segHeights[segUid] = Math.max(segHeights[segUid] || 0, height);
        }
        return segHeights;
    }
    computeMaxContentHeight() {
        let firstKey = this.props.cells[0].key;
        let cellEl = this.cellElRefs.currentMap[firstKey];
        let fcContainerEl = this.fgElRefs.currentMap[firstKey];
        return cellEl.getBoundingClientRect().bottom - fcContainerEl.getBoundingClientRect().top;
    }
    getCellEls() {
        let elMap = this.cellElRefs.currentMap;
        return this.props.cells.map((cell)=>elMap[cell.key]);
    }
}
TableRow.addStateEquality({
    segHeights: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__E__as__isPropsEqual$3e$__["isPropsEqual"]
});
function buildMirrorPlacements(mirrorSegs, colPlacements) {
    if (!mirrorSegs.length) {
        return [];
    }
    let topsByInstanceId = buildAbsoluteTopHash(colPlacements); // TODO: cache this at first render?
    return mirrorSegs.map((seg)=>({
            seg,
            isVisible: true,
            isAbsolute: true,
            absoluteTop: topsByInstanceId[seg.eventRange.instance.instanceId],
            marginTop: 0
        }));
}
function buildAbsoluteTopHash(colPlacements) {
    let topsByInstanceId = {};
    for (let placements of colPlacements){
        for (let placement of placements){
            topsByInstanceId[placement.seg.eventRange.instance.instanceId] = placement.absoluteTop;
        }
    }
    return topsByInstanceId;
}
class TableRows extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.splitBusinessHourSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitSegsByRow);
        this.splitBgEventSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitAllDaySegsByRow);
        this.splitFgEventSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitSegsByRow);
        this.splitDateSelectionSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitSegsByRow);
        this.splitEventDrag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitInteractionByRow);
        this.splitEventResize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitInteractionByRow);
        this.rowRefs = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cd__as__RefMap$3e$__["RefMap"]();
    }
    render() {
        let { props, context } = this;
        let rowCnt = props.cells.length;
        let businessHourSegsByRow = this.splitBusinessHourSegs(props.businessHourSegs, rowCnt);
        let bgEventSegsByRow = this.splitBgEventSegs(props.bgEventSegs, rowCnt);
        let fgEventSegsByRow = this.splitFgEventSegs(props.fgEventSegs, rowCnt);
        let dateSelectionSegsByRow = this.splitDateSelectionSegs(props.dateSelectionSegs, rowCnt);
        let eventDragByRow = this.splitEventDrag(props.eventDrag, rowCnt);
        let eventResizeByRow = this.splitEventResize(props.eventResize, rowCnt);
        // for DayGrid view with many rows, force a min-height on cells so doesn't appear squished
        // choose 7 because a month view will have max 6 rows
        let cellMinHeight = rowCnt >= 7 && props.clientWidth ? props.clientWidth / context.options.aspectRatio / 6 : null;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a6__as__NowTimer$3e$__["NowTimer"], {
            unit: "day"
        }, (nowDate, todayRange)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, props.cells.map((cells, row)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TableRow, {
                    ref: this.rowRefs.createRef(row),
                    key: cells.length ? cells[0].date.toISOString() : row // in case there are no cells (like when resource view is loading)
                    ,
                    showDayNumbers: rowCnt > 1,
                    showWeekNumbers: props.showWeekNumbers,
                    todayRange: todayRange,
                    dateProfile: props.dateProfile,
                    cells: cells,
                    renderIntro: props.renderRowIntro,
                    businessHourSegs: businessHourSegsByRow[row],
                    eventSelection: props.eventSelection,
                    bgEventSegs: bgEventSegsByRow[row],
                    fgEventSegs: fgEventSegsByRow[row],
                    dateSelectionSegs: dateSelectionSegsByRow[row],
                    eventDrag: eventDragByRow[row],
                    eventResize: eventResizeByRow[row],
                    dayMaxEvents: props.dayMaxEvents,
                    dayMaxEventRows: props.dayMaxEventRows,
                    clientWidth: props.clientWidth,
                    clientHeight: props.clientHeight,
                    cellMinHeight: cellMinHeight,
                    forPrint: props.forPrint
                }))));
    }
    componentDidMount() {
        this.registerInteractiveComponent();
    }
    componentDidUpdate() {
        // for if started with zero cells
        this.registerInteractiveComponent();
    }
    registerInteractiveComponent() {
        if (!this.rootEl) {
            // HACK: need a daygrid wrapper parent to do positioning
            // NOTE: a daygrid resource view w/o resources can have zero cells
            const firstCellEl = this.rowRefs.currentMap[0].getCellEls()[0];
            const rootEl = firstCellEl ? firstCellEl.closest('.fc-daygrid-body') : null;
            if (rootEl) {
                this.rootEl = rootEl;
                this.context.registerInteractiveComponent(this, {
                    el: rootEl,
                    isHitComboAllowed: this.props.isHitComboAllowed
                });
            }
        }
    }
    componentWillUnmount() {
        if (this.rootEl) {
            this.context.unregisterInteractiveComponent(this);
            this.rootEl = null;
        }
    }
    // Hit System
    // ----------------------------------------------------------------------------------------------------
    prepareHits() {
        this.rowPositions = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b8__as__PositionCache$3e$__["PositionCache"](this.rootEl, this.rowRefs.collect().map((rowObj)=>rowObj.getCellEls()[0]), false, true);
        this.colPositions = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b8__as__PositionCache$3e$__["PositionCache"](this.rootEl, this.rowRefs.currentMap[0].getCellEls(), true, false);
    }
    queryHit(positionLeft, positionTop) {
        let { colPositions, rowPositions } = this;
        let col = colPositions.leftToIndex(positionLeft);
        let row = rowPositions.topToIndex(positionTop);
        if (row != null && col != null) {
            let cell = this.props.cells[row][col];
            return {
                dateProfile: this.props.dateProfile,
                dateSpan: Object.assign({
                    range: this.getCellRange(row, col),
                    allDay: true
                }, cell.extraDateSpan),
                dayEl: this.getCellEl(row, col),
                rect: {
                    left: colPositions.lefts[col],
                    right: colPositions.rights[col],
                    top: rowPositions.tops[row],
                    bottom: rowPositions.bottoms[row]
                },
                layer: 0
            };
        }
        return null;
    }
    getCellEl(row, col) {
        return this.rowRefs.currentMap[row].getCellEls()[col]; // TODO: not optimal
    }
    getCellRange(row, col) {
        let start = this.props.cells[row][col].date;
        let end = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__t__as__addDays$3e$__["addDays"])(start, 1);
        return {
            start,
            end
        };
    }
}
function splitAllDaySegsByRow(segs, rowCnt) {
    return splitSegsByRow(segs.filter(isSegAllDay), rowCnt);
}
function isSegAllDay(seg) {
    return seg.eventRange.def.allDay;
}
class Table extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.elRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.needsScrollReset = false;
    }
    render() {
        let { props } = this;
        let { dayMaxEventRows, dayMaxEvents, expandRows } = props;
        let limitViaBalanced = dayMaxEvents === true || dayMaxEventRows === true;
        // if rows can't expand to fill fixed height, can't do balanced-height event limit
        // TODO: best place to normalize these options?
        if (limitViaBalanced && !expandRows) {
            limitViaBalanced = false;
            dayMaxEventRows = null;
            dayMaxEvents = null;
        }
        let classNames = [
            'fc-daygrid-body',
            limitViaBalanced ? 'fc-daygrid-body-balanced' : 'fc-daygrid-body-unbalanced',
            expandRows ? '' : 'fc-daygrid-body-natural'
        ];
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
            ref: this.elRef,
            className: classNames.join(' '),
            style: {
                // these props are important to give this wrapper correct dimensions for interactions
                // TODO: if we set it here, can we avoid giving to inner tables?
                width: props.clientWidth,
                minWidth: props.tableMinWidth
            }
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("table", {
            role: "presentation",
            className: "fc-scrollgrid-sync-table",
            style: {
                width: props.clientWidth,
                minWidth: props.tableMinWidth,
                height: expandRows ? props.clientHeight : ''
            }
        }, props.colGroupNode, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tbody", {
            role: "presentation"
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TableRows, {
            dateProfile: props.dateProfile,
            cells: props.cells,
            renderRowIntro: props.renderRowIntro,
            showWeekNumbers: props.showWeekNumbers,
            clientWidth: props.clientWidth,
            clientHeight: props.clientHeight,
            businessHourSegs: props.businessHourSegs,
            bgEventSegs: props.bgEventSegs,
            fgEventSegs: props.fgEventSegs,
            dateSelectionSegs: props.dateSelectionSegs,
            eventSelection: props.eventSelection,
            eventDrag: props.eventDrag,
            eventResize: props.eventResize,
            dayMaxEvents: dayMaxEvents,
            dayMaxEventRows: dayMaxEventRows,
            forPrint: props.forPrint,
            isHitComboAllowed: props.isHitComboAllowed
        }))));
    }
    componentDidMount() {
        this.requestScrollReset();
    }
    componentDidUpdate(prevProps) {
        if (prevProps.dateProfile !== this.props.dateProfile) {
            this.requestScrollReset();
        } else {
            this.flushScrollReset();
        }
    }
    requestScrollReset() {
        this.needsScrollReset = true;
        this.flushScrollReset();
    }
    flushScrollReset() {
        if (this.needsScrollReset && this.props.clientWidth // sizes computed?
        ) {
            const subjectEl = getScrollSubjectEl(this.elRef.current, this.props.dateProfile);
            if (subjectEl) {
                const originEl = subjectEl.closest('.fc-daygrid-body');
                const scrollEl = originEl.closest('.fc-scroller');
                const scrollTop = subjectEl.getBoundingClientRect().top - originEl.getBoundingClientRect().top;
                scrollEl.scrollTop = scrollTop ? scrollTop + 1 : 0; // overcome border
            }
            this.needsScrollReset = false;
        }
    }
}
function getScrollSubjectEl(containerEl, dateProfile) {
    let el;
    if (dateProfile.currentRangeUnit.match(/year|month/)) {
        el = containerEl.querySelector(`[data-date="${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bv__as__formatIsoMonthStr$3e$__["formatIsoMonthStr"])(dateProfile.currentDate)}-01"]`);
    // even if view is month-based, first-of-month might be hidden...
    }
    if (!el) {
        el = containerEl.querySelector(`[data-date="${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bt__as__formatDayString$3e$__["formatDayString"])(dateProfile.currentDate)}"]`);
    // could still be hidden if an interior-view hidden day
    }
    return el;
}
class DayTableSlicer extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bU__as__Slicer$3e$__["Slicer"] {
    constructor(){
        super(...arguments);
        this.forceDayIfListItem = true;
    }
    sliceRange(dateRange, dayTableModel) {
        return dayTableModel.sliceRange(dateRange);
    }
}
class DayTable extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.slicer = new DayTableSlicer();
        this.tableRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
    }
    render() {
        let { props, context } = this;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(Table, Object.assign({
            ref: this.tableRef
        }, this.slicer.sliceProps(props, props.dateProfile, props.nextDayThreshold, context, props.dayTableModel), {
            dateProfile: props.dateProfile,
            cells: props.dayTableModel.cells,
            colGroupNode: props.colGroupNode,
            tableMinWidth: props.tableMinWidth,
            renderRowIntro: props.renderRowIntro,
            dayMaxEvents: props.dayMaxEvents,
            dayMaxEventRows: props.dayMaxEventRows,
            showWeekNumbers: props.showWeekNumbers,
            expandRows: props.expandRows,
            headerAlignElRef: props.headerAlignElRef,
            clientWidth: props.clientWidth,
            clientHeight: props.clientHeight,
            forPrint: props.forPrint
        }));
    }
}
class DayTableView extends TableView {
    constructor(){
        super(...arguments);
        this.buildDayTableModel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(buildDayTableModel);
        this.headerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.tableRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
    // can't override any lifecycle methods from parent
    }
    render() {
        let { options, dateProfileGenerator } = this.context;
        let { props } = this;
        let dayTableModel = this.buildDayTableModel(props.dateProfile, dateProfileGenerator);
        let headerContent = options.dayHeaders && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bI__as__DayHeader$3e$__["DayHeader"], {
            ref: this.headerRef,
            dateProfile: props.dateProfile,
            dates: dayTableModel.headerDates,
            datesRepDistinctDays: dayTableModel.rowCnt === 1
        });
        let bodyContent = (contentArg)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(DayTable, {
                ref: this.tableRef,
                dateProfile: props.dateProfile,
                dayTableModel: dayTableModel,
                businessHours: props.businessHours,
                dateSelection: props.dateSelection,
                eventStore: props.eventStore,
                eventUiBases: props.eventUiBases,
                eventSelection: props.eventSelection,
                eventDrag: props.eventDrag,
                eventResize: props.eventResize,
                nextDayThreshold: options.nextDayThreshold,
                colGroupNode: contentArg.tableColGroupNode,
                tableMinWidth: contentArg.tableMinWidth,
                dayMaxEvents: options.dayMaxEvents,
                dayMaxEventRows: options.dayMaxEventRows,
                showWeekNumbers: options.weekNumbers,
                expandRows: !props.isHeightAuto,
                headerAlignElRef: this.headerElRef,
                clientWidth: contentArg.clientWidth,
                clientHeight: contentArg.clientHeight,
                forPrint: props.forPrint
            });
        return options.dayMinWidth ? this.renderHScrollLayout(headerContent, bodyContent, dayTableModel.colCnt, options.dayMinWidth) : this.renderSimpleLayout(headerContent, bodyContent);
    }
}
function buildDayTableModel(dateProfile, dateProfileGenerator) {
    let daySeries = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bM__as__DaySeriesModel$3e$__["DaySeriesModel"](dateProfile.renderRange, dateProfileGenerator);
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bT__as__DayTableModel$3e$__["DayTableModel"](daySeries, /year|month|week/.test(dateProfile.currentRangeUnit));
}
class TableDateProfileGenerator extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__R__as__DateProfileGenerator$3e$__["DateProfileGenerator"] {
    // Computes the date range that will be rendered
    buildRenderRange(currentRange, currentRangeUnit, isRangeAllDay) {
        let renderRange = super.buildRenderRange(currentRange, currentRangeUnit, isRangeAllDay);
        let { props } = this;
        return buildDayTableRenderRange({
            currentRange: renderRange,
            snapToWeek: /^(year|month)$/.test(currentRangeUnit),
            fixedWeekCount: props.fixedWeekCount,
            dateEnv: props.dateEnv
        });
    }
}
function buildDayTableRenderRange(props) {
    let { dateEnv, currentRange } = props;
    let { start, end } = currentRange;
    let endOfWeek;
    // year and month views should be aligned with weeks. this is already done for week
    if (props.snapToWeek) {
        start = dateEnv.startOfWeek(start);
        // make end-of-week if not already
        endOfWeek = dateEnv.startOfWeek(end);
        if (endOfWeek.valueOf() !== end.valueOf()) {
            end = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bf__as__addWeeks$3e$__["addWeeks"])(endOfWeek, 1);
        }
    }
    // ensure 6 weeks
    if (props.fixedWeekCount) {
        // TODO: instead of these date-math gymnastics (for multimonth view),
        // compute dateprofiles of all months, then use start of first and end of last.
        let lastMonthRenderStart = dateEnv.startOfWeek(dateEnv.startOfMonth((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__t__as__addDays$3e$__["addDays"])(currentRange.end, -1)));
        let rowCnt = Math.ceil((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bg__as__diffWeeks$3e$__["diffWeeks"])(lastMonthRenderStart, end));
        end = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bf__as__addWeeks$3e$__["addWeeks"])(end, 6 - rowCnt);
    }
    return {
        start,
        end
    };
}
var css_248z = ":root{--fc-daygrid-event-dot-width:8px}.fc-daygrid-day-events:after,.fc-daygrid-day-events:before,.fc-daygrid-day-frame:after,.fc-daygrid-day-frame:before,.fc-daygrid-event-harness:after,.fc-daygrid-event-harness:before{clear:both;content:\"\";display:table}.fc .fc-daygrid-body{position:relative;z-index:1}.fc .fc-daygrid-day.fc-day-today{background-color:var(--fc-today-bg-color)}.fc .fc-daygrid-day-frame{min-height:100%;position:relative}.fc .fc-daygrid-day-top{display:flex;flex-direction:row-reverse}.fc .fc-day-other .fc-daygrid-day-top{opacity:.3}.fc .fc-daygrid-day-number{padding:4px;position:relative;z-index:4}.fc .fc-daygrid-month-start{font-size:1.1em;font-weight:700}.fc .fc-daygrid-day-events{margin-top:1px}.fc .fc-daygrid-body-balanced .fc-daygrid-day-events{left:0;position:absolute;right:0}.fc .fc-daygrid-body-unbalanced .fc-daygrid-day-events{min-height:2em;position:relative}.fc .fc-daygrid-body-natural .fc-daygrid-day-events{margin-bottom:1em}.fc .fc-daygrid-event-harness{position:relative}.fc .fc-daygrid-event-harness-abs{left:0;position:absolute;right:0;top:0}.fc .fc-daygrid-bg-harness{bottom:0;position:absolute;top:0}.fc .fc-daygrid-day-bg .fc-non-business{z-index:1}.fc .fc-daygrid-day-bg .fc-bg-event{z-index:2}.fc .fc-daygrid-day-bg .fc-highlight{z-index:3}.fc .fc-daygrid-event{margin-top:1px;z-index:6}.fc .fc-daygrid-event.fc-event-mirror{z-index:7}.fc .fc-daygrid-day-bottom{font-size:.85em;margin:0 2px}.fc .fc-daygrid-day-bottom:after,.fc .fc-daygrid-day-bottom:before{clear:both;content:\"\";display:table}.fc .fc-daygrid-more-link{border-radius:3px;cursor:pointer;line-height:1;margin-top:1px;max-width:100%;overflow:hidden;padding:2px;position:relative;white-space:nowrap;z-index:4}.fc .fc-daygrid-more-link:hover{background-color:rgba(0,0,0,.1)}.fc .fc-daygrid-week-number{background-color:var(--fc-neutral-bg-color);color:var(--fc-neutral-text-color);min-width:1.5em;padding:2px;position:absolute;text-align:center;top:0;z-index:5}.fc .fc-more-popover .fc-popover-body{min-width:220px;padding:10px}.fc-direction-ltr .fc-daygrid-event.fc-event-start,.fc-direction-rtl .fc-daygrid-event.fc-event-end{margin-left:2px}.fc-direction-ltr .fc-daygrid-event.fc-event-end,.fc-direction-rtl .fc-daygrid-event.fc-event-start{margin-right:2px}.fc-direction-ltr .fc-daygrid-more-link{float:left}.fc-direction-ltr .fc-daygrid-week-number{border-radius:0 0 3px 0;left:0}.fc-direction-rtl .fc-daygrid-more-link{float:right}.fc-direction-rtl .fc-daygrid-week-number{border-radius:0 0 0 3px;right:0}.fc-liquid-hack .fc-daygrid-day-frame{position:static}.fc-daygrid-event{border-radius:3px;font-size:var(--fc-small-font-size);position:relative;white-space:nowrap}.fc-daygrid-block-event .fc-event-time{font-weight:700}.fc-daygrid-block-event .fc-event-time,.fc-daygrid-block-event .fc-event-title{padding:1px}.fc-daygrid-dot-event{align-items:center;display:flex;padding:2px 0}.fc-daygrid-dot-event .fc-event-title{flex-grow:1;flex-shrink:1;font-weight:700;min-width:0;overflow:hidden}.fc-daygrid-dot-event.fc-event-mirror,.fc-daygrid-dot-event:hover{background:rgba(0,0,0,.1)}.fc-daygrid-dot-event.fc-event-selected:before{bottom:-10px;top:-10px}.fc-daygrid-event-dot{border:calc(var(--fc-daygrid-event-dot-width)/2) solid var(--fc-event-border-color);border-radius:calc(var(--fc-daygrid-event-dot-width)/2);box-sizing:content-box;height:0;margin:0 4px;width:0}.fc-direction-ltr .fc-daygrid-event .fc-event-time{margin-right:3px}.fc-direction-rtl .fc-daygrid-event .fc-event-time{margin-left:3px}";
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ct__as__injectStyles$3e$__["injectStyles"])(css_248z);
;
}),
"[project]/node_modules/@fullcalendar/daygrid/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>index
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$daygrid$2f$internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/daygrid/internal.js [app-client] (ecmascript)");
;
;
;
;
var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createPlugin"])({
    name: '@fullcalendar/daygrid',
    initialView: 'dayGridMonth',
    views: {
        dayGrid: {
            component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$daygrid$2f$internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DayGridView"],
            dateProfileGeneratorClass: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$daygrid$2f$internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TableDateProfileGenerator"]
        },
        dayGridDay: {
            type: 'dayGrid',
            duration: {
                days: 1
            }
        },
        dayGridWeek: {
            type: 'dayGrid',
            duration: {
                weeks: 1
            }
        },
        dayGridMonth: {
            type: 'dayGrid',
            duration: {
                months: 1
            },
            fixedWeekCount: true
        },
        dayGridYear: {
            type: 'dayGrid',
            duration: {
                years: 1
            }
        }
    }
});
;
}),
"[project]/node_modules/@fullcalendar/timegrid/internal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DayTimeCols",
    ()=>DayTimeCols,
    "DayTimeColsSlicer",
    ()=>DayTimeColsSlicer,
    "DayTimeColsView",
    ()=>DayTimeColsView,
    "TimeCols",
    ()=>TimeCols,
    "TimeColsSlatsCoords",
    ()=>TimeColsSlatsCoords,
    "TimeColsView",
    ()=>TimeColsView,
    "buildDayRanges",
    ()=>buildDayRanges,
    "buildSlatMetas",
    ()=>buildSlatMetas,
    "buildTimeColsModel",
    ()=>buildTimeColsModel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__aW__as__Splitter$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export aW as Splitter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bN__as__hasBgRendering$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bN as hasBgRendering>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export x as createFormatter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__V__as__ViewContextType$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export V as ViewContextType>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__C__as__ContentContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export C as ContentContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export B as BaseComponent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bc as DateComponent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bj__as__diffDays$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bj as diffDays>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a___as__buildNavLinkAttrs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export a_ as buildNavLinkAttrs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cn__as__WeekNumberContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cn as WeekNumberContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ca__as__getStickyHeaderDates$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ca as getStickyHeaderDates>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cq__as__ViewContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cq as ViewContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bZ__as__SimpleScrollGrid$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bZ as SimpleScrollGrid>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c9__as__getStickyFooterScrollbar$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export c9 as getStickyFooterScrollbar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a6__as__NowTimer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export a6 as NowTimer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ch__as__NowIndicatorContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ch as NowIndicatorContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c8__as__renderScrollShim$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export c8 as renderScrollShim>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__G__as__rangeContainsMarker$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export G as rangeContainsMarker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__q__as__startOfDay$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export q as startOfDay>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bq__as__asRoughMs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bq as asRoughMs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__createDuration$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export d as createDuration>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cd__as__RefMap$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cd as RefMap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b8__as__PositionCache$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export b8 as PositionCache>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__co__as__MoreLinkContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export co as MoreLinkContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__by__as__SegHierarchy$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export by as SegHierarchy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bC__as__groupIntersectingEntries$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bC as groupIntersectingEntries>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bB__as__binarySearch$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bB as binarySearch>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bA__as__getEntrySpanEnd$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bA as getEntrySpanEnd>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bz__as__buildEntryKey$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bz as buildEntryKey>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cg__as__StandardEvent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cg as StandardEvent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export z as memoize>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bP__as__sortEventSegs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bP as sortEventSegs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ci__as__DayCellContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ci as DayCellContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cj__as__hasCustomDayCellContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cj as hasCustomDayCellContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bQ as getSegMeta>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bu__as__buildIsoString$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bu as buildIsoString>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cp__as__computeEarliestSegStart$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cp as computeEarliestSegStart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bR__as__buildEventRangeKey$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bR as buildEventRangeKey>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cm__as__BgEvent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cm as BgEvent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cl__as__renderFill$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cl as renderFill>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bn__as__addDurations$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bn as addDurations>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bm__as__multiplyDuration$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bm as multiplyDuration>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__br__as__wholeDivideDurations$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export br as wholeDivideDurations>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bU__as__Slicer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bU as Slicer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__o__as__intersectRanges$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export o as intersectRanges>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bs__as__formatIsoTimeString$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bs as formatIsoTimeString>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bI__as__DayHeader$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bI as DayHeader>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bM__as__DaySeriesModel$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bM as DaySeriesModel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bT__as__DayTableModel$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bT as DayTableModel>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ct__as__injectStyles$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ct as injectStyles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/preact/dist/preact.module.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$daygrid$2f$internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/daygrid/internal.js [app-client] (ecmascript)");
;
;
;
class AllDaySplitter extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__aW__as__Splitter$3e$__["Splitter"] {
    getKeyInfo() {
        return {
            allDay: {},
            timed: {}
        };
    }
    getKeysForDateSpan(dateSpan) {
        if (dateSpan.allDay) {
            return [
                'allDay'
            ];
        }
        return [
            'timed'
        ];
    }
    getKeysForEventDef(eventDef) {
        if (!eventDef.allDay) {
            return [
                'timed'
            ];
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bN__as__hasBgRendering$3e$__["hasBgRendering"])(eventDef)) {
            return [
                'timed',
                'allDay'
            ];
        }
        return [
            'allDay'
        ];
    }
}
const DEFAULT_SLAT_LABEL_FORMAT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__["createFormatter"])({
    hour: 'numeric',
    minute: '2-digit',
    omitZeroMinute: true,
    meridiem: 'short'
});
function TimeColsAxisCell(props) {
    let classNames = [
        'fc-timegrid-slot',
        'fc-timegrid-slot-label',
        props.isLabeled ? 'fc-scrollgrid-shrink' : 'fc-timegrid-slot-minor'
    ];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__V__as__ViewContextType$3e$__["ViewContextType"].Consumer, null, (context)=>{
        if (!props.isLabeled) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("td", {
                className: classNames.join(' '),
                "data-time": props.isoTimeStr
            });
        }
        let { dateEnv, options, viewApi } = context;
        let labelFormat = options.slotLabelFormat == null ? DEFAULT_SLAT_LABEL_FORMAT : Array.isArray(options.slotLabelFormat) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__["createFormatter"])(options.slotLabelFormat[0]) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__["createFormatter"])(options.slotLabelFormat);
        let renderProps = {
            level: 0,
            time: props.time,
            date: dateEnv.toDate(props.date),
            view: viewApi,
            text: dateEnv.format(props.date, labelFormat)
        };
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__C__as__ContentContainer$3e$__["ContentContainer"], {
            elTag: "td",
            elClasses: classNames,
            elAttrs: {
                'data-time': props.isoTimeStr
            },
            renderProps: renderProps,
            generatorName: "slotLabelContent",
            customGenerator: options.slotLabelContent,
            defaultGenerator: renderInnerContent,
            classNameGenerator: options.slotLabelClassNames,
            didMount: options.slotLabelDidMount,
            willUnmount: options.slotLabelWillUnmount
        }, (InnerContent)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame"
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(InnerContent, {
                elTag: "div",
                elClasses: [
                    'fc-timegrid-slot-label-cushion',
                    'fc-scrollgrid-shrink-cushion'
                ]
            })));
    });
}
function renderInnerContent(props) {
    return props.text;
}
class TimeBodyAxis extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    render() {
        return this.props.slatMetas.map((slatMeta)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tr", {
                key: slatMeta.key
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeColsAxisCell, Object.assign({}, slatMeta))));
    }
}
const DEFAULT_WEEK_NUM_FORMAT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__["createFormatter"])({
    week: 'short'
});
const AUTO_ALL_DAY_MAX_EVENT_ROWS = 5;
class TimeColsView extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.allDaySplitter = new AllDaySplitter(); // for use by subclasses
        this.headerElRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.rootElRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.scrollerElRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.state = {
            slatCoords: null
        };
        this.handleScrollTopRequest = (scrollTop)=>{
            let scrollerEl = this.scrollerElRef.current;
            if (scrollerEl) {
                scrollerEl.scrollTop = scrollTop;
            }
        };
        /* Header Render Methods
        ------------------------------------------------------------------------------------------------------------------*/ this.renderHeadAxis = (rowKey, frameHeight = '')=>{
            let { options } = this.context;
            let { dateProfile } = this.props;
            let range = dateProfile.renderRange;
            let dayCnt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bj__as__diffDays$3e$__["diffDays"])(range.start, range.end);
            // only do in day views (to avoid doing in week views that dont need it)
            let navLinkAttrs = dayCnt === 1 ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a___as__buildNavLinkAttrs$3e$__["buildNavLinkAttrs"])(this.context, range.start, 'week') : {};
            if (options.weekNumbers && rowKey === 'day') {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cn__as__WeekNumberContainer$3e$__["WeekNumberContainer"], {
                    elTag: "th",
                    elClasses: [
                        'fc-timegrid-axis',
                        'fc-scrollgrid-shrink'
                    ],
                    elAttrs: {
                        'aria-hidden': true
                    },
                    date: range.start,
                    defaultFormat: DEFAULT_WEEK_NUM_FORMAT
                }, (InnerContent)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                        className: [
                            'fc-timegrid-axis-frame',
                            'fc-scrollgrid-shrink-frame',
                            'fc-timegrid-axis-frame-liquid'
                        ].join(' '),
                        style: {
                            height: frameHeight
                        }
                    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(InnerContent, {
                        elTag: "a",
                        elClasses: [
                            'fc-timegrid-axis-cushion',
                            'fc-scrollgrid-shrink-cushion',
                            'fc-scrollgrid-sync-inner'
                        ],
                        elAttrs: navLinkAttrs
                    })));
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("th", {
                "aria-hidden": true,
                className: "fc-timegrid-axis"
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-timegrid-axis-frame",
                style: {
                    height: frameHeight
                }
            }));
        };
        /* Table Component Render Methods
        ------------------------------------------------------------------------------------------------------------------*/ // only a one-way height sync. we don't send the axis inner-content height to the DayGrid,
        // but DayGrid still needs to have classNames on inner elements in order to measure.
        this.renderTableRowAxis = (rowHeight)=>{
            let { options, viewApi } = this.context;
            let renderProps = {
                text: options.allDayText,
                view: viewApi
            };
            return(// TODO: make reusable hook. used in list view too
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__C__as__ContentContainer$3e$__["ContentContainer"], {
                elTag: "td",
                elClasses: [
                    'fc-timegrid-axis',
                    'fc-scrollgrid-shrink'
                ],
                elAttrs: {
                    'aria-hidden': true
                },
                renderProps: renderProps,
                generatorName: "allDayContent",
                customGenerator: options.allDayContent,
                defaultGenerator: renderAllDayInner,
                classNameGenerator: options.allDayClassNames,
                didMount: options.allDayDidMount,
                willUnmount: options.allDayWillUnmount
            }, (InnerContent)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                    className: [
                        'fc-timegrid-axis-frame',
                        'fc-scrollgrid-shrink-frame',
                        rowHeight == null ? ' fc-timegrid-axis-frame-liquid' : ''
                    ].join(' '),
                    style: {
                        height: rowHeight
                    }
                }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(InnerContent, {
                    elTag: "span",
                    elClasses: [
                        'fc-timegrid-axis-cushion',
                        'fc-scrollgrid-shrink-cushion',
                        'fc-scrollgrid-sync-inner'
                    ]
                }))));
        };
        this.handleSlatCoords = (slatCoords)=>{
            this.setState({
                slatCoords
            });
        };
    }
    // rendering
    // ----------------------------------------------------------------------------------------------------
    renderSimpleLayout(headerRowContent, allDayContent, timeContent) {
        let { context, props } = this;
        let sections = [];
        let stickyHeaderDates = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ca__as__getStickyHeaderDates$3e$__["getStickyHeaderDates"])(context.options);
        if (headerRowContent) {
            sections.push({
                type: 'header',
                key: 'header',
                isSticky: stickyHeaderDates,
                chunk: {
                    elRef: this.headerElRef,
                    tableClassName: 'fc-col-header',
                    rowContent: headerRowContent
                }
            });
        }
        if (allDayContent) {
            sections.push({
                type: 'body',
                key: 'all-day',
                chunk: {
                    content: allDayContent
                }
            });
            sections.push({
                type: 'body',
                key: 'all-day-divider',
                outerContent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tr", {
                    role: "presentation",
                    className: "fc-scrollgrid-section"
                }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("td", {
                    className: 'fc-timegrid-divider ' + context.theme.getClass('tableCellShaded')
                }))
            });
        }
        sections.push({
            type: 'body',
            key: 'body',
            liquid: true,
            expandRows: Boolean(context.options.expandRows),
            chunk: {
                scrollerElRef: this.scrollerElRef,
                content: timeContent
            }
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cq__as__ViewContainer$3e$__["ViewContainer"], {
            elRef: this.rootElRef,
            elClasses: [
                'fc-timegrid'
            ],
            viewSpec: context.viewSpec
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bZ__as__SimpleScrollGrid$3e$__["SimpleScrollGrid"], {
            liquid: !props.isHeightAuto && !props.forPrint,
            collapsibleWidth: props.forPrint,
            cols: [
                {
                    width: 'shrink'
                }
            ],
            sections: sections
        }));
    }
    renderHScrollLayout(headerRowContent, allDayContent, timeContent, colCnt, dayMinWidth, slatMetas, slatCoords) {
        let ScrollGrid = this.context.pluginHooks.scrollGridImpl;
        if (!ScrollGrid) {
            throw new Error('No ScrollGrid implementation');
        }
        let { context, props } = this;
        let stickyHeaderDates = !props.forPrint && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ca__as__getStickyHeaderDates$3e$__["getStickyHeaderDates"])(context.options);
        let stickyFooterScrollbar = !props.forPrint && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c9__as__getStickyFooterScrollbar$3e$__["getStickyFooterScrollbar"])(context.options);
        let sections = [];
        if (headerRowContent) {
            sections.push({
                type: 'header',
                key: 'header',
                isSticky: stickyHeaderDates,
                syncRowHeights: true,
                chunks: [
                    {
                        key: 'axis',
                        rowContent: (arg)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tr", {
                                role: "presentation"
                            }, this.renderHeadAxis('day', arg.rowSyncHeights[0]))
                    },
                    {
                        key: 'cols',
                        elRef: this.headerElRef,
                        tableClassName: 'fc-col-header',
                        rowContent: headerRowContent
                    }
                ]
            });
        }
        if (allDayContent) {
            sections.push({
                type: 'body',
                key: 'all-day',
                syncRowHeights: true,
                chunks: [
                    {
                        key: 'axis',
                        rowContent: (contentArg)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tr", {
                                role: "presentation"
                            }, this.renderTableRowAxis(contentArg.rowSyncHeights[0]))
                    },
                    {
                        key: 'cols',
                        content: allDayContent
                    }
                ]
            });
            sections.push({
                key: 'all-day-divider',
                type: 'body',
                outerContent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tr", {
                    role: "presentation",
                    className: "fc-scrollgrid-section"
                }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("td", {
                    colSpan: 2,
                    className: 'fc-timegrid-divider ' + context.theme.getClass('tableCellShaded')
                }))
            });
        }
        let isNowIndicator = context.options.nowIndicator;
        sections.push({
            type: 'body',
            key: 'body',
            liquid: true,
            expandRows: Boolean(context.options.expandRows),
            chunks: [
                {
                    key: 'axis',
                    content: (arg)=>// TODO: make this now-indicator arrow more DRY with TimeColsContent
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                            className: "fc-timegrid-axis-chunk"
                        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("table", {
                            "aria-hidden": true,
                            style: {
                                height: arg.expandRows ? arg.clientHeight : ''
                            }
                        }, arg.tableColGroupNode, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tbody", null, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeBodyAxis, {
                            slatMetas: slatMetas
                        }))), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                            className: "fc-timegrid-now-indicator-container"
                        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a6__as__NowTimer$3e$__["NowTimer"], {
                            unit: isNowIndicator ? 'minute' : 'day' /* hacky */ 
                        }, (nowDate)=>{
                            let nowIndicatorTop = isNowIndicator && slatCoords && slatCoords.safeComputeTop(nowDate); // might return void
                            if (typeof nowIndicatorTop === 'number') {
                                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ch__as__NowIndicatorContainer$3e$__["NowIndicatorContainer"], {
                                    elClasses: [
                                        'fc-timegrid-now-indicator-arrow'
                                    ],
                                    elStyle: {
                                        top: nowIndicatorTop
                                    },
                                    isAxis: true,
                                    date: nowDate
                                });
                            }
                            return null;
                        })))
                },
                {
                    key: 'cols',
                    scrollerElRef: this.scrollerElRef,
                    content: timeContent
                }
            ]
        });
        if (stickyFooterScrollbar) {
            sections.push({
                key: 'footer',
                type: 'footer',
                isSticky: true,
                chunks: [
                    {
                        key: 'axis',
                        content: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c8__as__renderScrollShim$3e$__["renderScrollShim"]
                    },
                    {
                        key: 'cols',
                        content: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__c8__as__renderScrollShim$3e$__["renderScrollShim"]
                    }
                ]
            });
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cq__as__ViewContainer$3e$__["ViewContainer"], {
            elRef: this.rootElRef,
            elClasses: [
                'fc-timegrid'
            ],
            viewSpec: context.viewSpec
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(ScrollGrid, {
            liquid: !props.isHeightAuto && !props.forPrint,
            forPrint: props.forPrint,
            collapsibleWidth: false,
            colGroups: [
                {
                    width: 'shrink',
                    cols: [
                        {
                            width: 'shrink'
                        }
                    ]
                },
                {
                    cols: [
                        {
                            span: colCnt,
                            minWidth: dayMinWidth
                        }
                    ]
                }
            ],
            sections: sections
        }));
    }
    /* Dimensions
    ------------------------------------------------------------------------------------------------------------------*/ getAllDayMaxEventProps() {
        let { dayMaxEvents, dayMaxEventRows } = this.context.options;
        if (dayMaxEvents === true || dayMaxEventRows === true) {
            dayMaxEvents = undefined;
            dayMaxEventRows = AUTO_ALL_DAY_MAX_EVENT_ROWS; // make sure "auto" goes to a real number
        }
        return {
            dayMaxEvents,
            dayMaxEventRows
        };
    }
}
function renderAllDayInner(renderProps) {
    return renderProps.text;
}
class TimeColsSlatsCoords {
    constructor(positions, dateProfile, slotDuration){
        this.positions = positions;
        this.dateProfile = dateProfile;
        this.slotDuration = slotDuration;
    }
    safeComputeTop(date) {
        let { dateProfile } = this;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__G__as__rangeContainsMarker$3e$__["rangeContainsMarker"])(dateProfile.currentRange, date)) {
            let startOfDayDate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__q__as__startOfDay$3e$__["startOfDay"])(date);
            let timeMs = date.valueOf() - startOfDayDate.valueOf();
            if (timeMs >= (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bq__as__asRoughMs$3e$__["asRoughMs"])(dateProfile.slotMinTime) && timeMs < (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bq__as__asRoughMs$3e$__["asRoughMs"])(dateProfile.slotMaxTime)) {
                return this.computeTimeTop((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__createDuration$3e$__["createDuration"])(timeMs));
            }
        }
        return null;
    }
    // Computes the top coordinate, relative to the bounds of the grid, of the given date.
    // A `startOfDayDate` must be given for avoiding ambiguity over how to treat midnight.
    computeDateTop(when, startOfDayDate) {
        if (!startOfDayDate) {
            startOfDayDate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__q__as__startOfDay$3e$__["startOfDay"])(when);
        }
        return this.computeTimeTop((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__createDuration$3e$__["createDuration"])(when.valueOf() - startOfDayDate.valueOf()));
    }
    // Computes the top coordinate, relative to the bounds of the grid, of the given time (a Duration).
    // This is a makeshify way to compute the time-top. Assumes all slatMetas dates are uniform.
    // Eventually allow computation with arbirary slat dates.
    computeTimeTop(duration) {
        let { positions, dateProfile } = this;
        let len = positions.els.length;
        // floating-point value of # of slots covered
        let slatCoverage = (duration.milliseconds - (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bq__as__asRoughMs$3e$__["asRoughMs"])(dateProfile.slotMinTime)) / (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bq__as__asRoughMs$3e$__["asRoughMs"])(this.slotDuration);
        let slatIndex;
        let slatRemainder;
        // compute a floating-point number for how many slats should be progressed through.
        // from 0 to number of slats (inclusive)
        // constrained because slotMinTime/slotMaxTime might be customized.
        slatCoverage = Math.max(0, slatCoverage);
        slatCoverage = Math.min(len, slatCoverage);
        // an integer index of the furthest whole slat
        // from 0 to number slats (*exclusive*, so len-1)
        slatIndex = Math.floor(slatCoverage);
        slatIndex = Math.min(slatIndex, len - 1);
        // how much further through the slatIndex slat (from 0.0-1.0) must be covered in addition.
        // could be 1.0 if slatCoverage is covering *all* the slots
        slatRemainder = slatCoverage - slatIndex;
        return positions.tops[slatIndex] + positions.getHeight(slatIndex) * slatRemainder;
    }
}
class TimeColsSlatsBody extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    render() {
        let { props, context } = this;
        let { options } = context;
        let { slatElRefs } = props;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tbody", null, props.slatMetas.map((slatMeta, i)=>{
            let renderProps = {
                time: slatMeta.time,
                date: context.dateEnv.toDate(slatMeta.date),
                view: context.viewApi
            };
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tr", {
                key: slatMeta.key,
                ref: slatElRefs.createRef(slatMeta.key)
            }, props.axis && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeColsAxisCell, Object.assign({}, slatMeta)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__C__as__ContentContainer$3e$__["ContentContainer"], {
                elTag: "td",
                elClasses: [
                    'fc-timegrid-slot',
                    'fc-timegrid-slot-lane',
                    !slatMeta.isLabeled && 'fc-timegrid-slot-minor'
                ],
                elAttrs: {
                    'data-time': slatMeta.isoTimeStr
                },
                renderProps: renderProps,
                generatorName: "slotLaneContent",
                customGenerator: options.slotLaneContent,
                classNameGenerator: options.slotLaneClassNames,
                didMount: options.slotLaneDidMount,
                willUnmount: options.slotLaneWillUnmount
            }));
        }));
    }
}
/*
for the horizontal "slats" that run width-wise. Has a time axis on a side. Depends on RTL.
*/ class TimeColsSlats extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    constructor(){
        super(...arguments);
        this.rootElRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.slatElRefs = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cd__as__RefMap$3e$__["RefMap"]();
    }
    render() {
        let { props, context } = this;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
            ref: this.rootElRef,
            className: "fc-timegrid-slots"
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("table", {
            "aria-hidden": true,
            className: context.theme.getClass('table'),
            style: {
                minWidth: props.tableMinWidth,
                width: props.clientWidth,
                height: props.minHeight
            }
        }, props.tableColGroupNode /* relies on there only being a single <col> for the axis */ , (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeColsSlatsBody, {
            slatElRefs: this.slatElRefs,
            axis: props.axis,
            slatMetas: props.slatMetas
        })));
    }
    componentDidMount() {
        this.updateSizing();
    }
    componentDidUpdate() {
        this.updateSizing();
    }
    componentWillUnmount() {
        if (this.props.onCoords) {
            this.props.onCoords(null);
        }
    }
    updateSizing() {
        let { context, props } = this;
        if (props.onCoords && props.clientWidth !== null // means sizing has stabilized
        ) {
            let rootEl = this.rootElRef.current;
            if (rootEl.offsetHeight) {
                props.onCoords(new TimeColsSlatsCoords(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b8__as__PositionCache$3e$__["PositionCache"](this.rootElRef.current, collectSlatEls(this.slatElRefs.currentMap, props.slatMetas), false, true), this.props.dateProfile, context.options.slotDuration));
            }
        }
    }
}
function collectSlatEls(elMap, slatMetas) {
    return slatMetas.map((slatMeta)=>elMap[slatMeta.key]);
}
function splitSegsByCol(segs, colCnt) {
    let segsByCol = [];
    let i;
    for(i = 0; i < colCnt; i += 1){
        segsByCol.push([]);
    }
    if (segs) {
        for(i = 0; i < segs.length; i += 1){
            segsByCol[segs[i].col].push(segs[i]);
        }
    }
    return segsByCol;
}
function splitInteractionByCol(ui, colCnt) {
    let byRow = [];
    if (!ui) {
        for(let i = 0; i < colCnt; i += 1){
            byRow[i] = null;
        }
    } else {
        for(let i = 0; i < colCnt; i += 1){
            byRow[i] = {
                affectedInstances: ui.affectedInstances,
                isEvent: ui.isEvent,
                segs: []
            };
        }
        for (let seg of ui.segs){
            byRow[seg.col].segs.push(seg);
        }
    }
    return byRow;
}
class TimeColMoreLink extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    render() {
        let { props } = this;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__co__as__MoreLinkContainer$3e$__["MoreLinkContainer"], {
            elClasses: [
                'fc-timegrid-more-link'
            ],
            elStyle: {
                top: props.top,
                bottom: props.bottom
            },
            allDayDate: null,
            moreCnt: props.hiddenSegs.length,
            allSegs: props.hiddenSegs,
            hiddenSegs: props.hiddenSegs,
            extraDateSpan: props.extraDateSpan,
            dateProfile: props.dateProfile,
            todayRange: props.todayRange,
            popoverContent: ()=>renderPlainFgSegs(props.hiddenSegs, props),
            defaultGenerator: renderMoreLinkInner,
            forceTimed: true
        }, (InnerContent)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(InnerContent, {
                elTag: "div",
                elClasses: [
                    'fc-timegrid-more-link-inner',
                    'fc-sticky'
                ]
            }));
    }
}
function renderMoreLinkInner(props) {
    return props.shortText;
}
// segInputs assumed sorted
function buildPositioning(segInputs, strictOrder, maxStackCnt) {
    let hierarchy = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__by__as__SegHierarchy$3e$__["SegHierarchy"]();
    if (strictOrder != null) {
        hierarchy.strictOrder = strictOrder;
    }
    if (maxStackCnt != null) {
        hierarchy.maxStackCnt = maxStackCnt;
    }
    let hiddenEntries = hierarchy.addSegs(segInputs);
    let hiddenGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bC__as__groupIntersectingEntries$3e$__["groupIntersectingEntries"])(hiddenEntries);
    let web = buildWeb(hierarchy);
    web = stretchWeb(web, 1); // all levelCoords/thickness will have 0.0-1.0
    let segRects = webToRects(web);
    return {
        segRects,
        hiddenGroups
    };
}
function buildWeb(hierarchy) {
    const { entriesByLevel } = hierarchy;
    const buildNode = cacheable((level, lateral)=>level + ':' + lateral, (level, lateral)=>{
        let siblingRange = findNextLevelSegs(hierarchy, level, lateral);
        let nextLevelRes = buildNodes(siblingRange, buildNode);
        let entry = entriesByLevel[level][lateral];
        return [
            Object.assign(Object.assign({}, entry), {
                nextLevelNodes: nextLevelRes[0]
            }),
            entry.thickness + nextLevelRes[1]
        ];
    });
    return buildNodes(entriesByLevel.length ? {
        level: 0,
        lateralStart: 0,
        lateralEnd: entriesByLevel[0].length
    } : null, buildNode)[0];
}
function buildNodes(siblingRange, buildNode) {
    if (!siblingRange) {
        return [
            [],
            0
        ];
    }
    let { level, lateralStart, lateralEnd } = siblingRange;
    let lateral = lateralStart;
    let pairs = [];
    while(lateral < lateralEnd){
        pairs.push(buildNode(level, lateral));
        lateral += 1;
    }
    pairs.sort(cmpDescPressures);
    return [
        pairs.map(extractNode),
        pairs[0][1]
    ];
}
function cmpDescPressures(a, b) {
    return b[1] - a[1];
}
function extractNode(a) {
    return a[0];
}
function findNextLevelSegs(hierarchy, subjectLevel, subjectLateral) {
    let { levelCoords, entriesByLevel } = hierarchy;
    let subjectEntry = entriesByLevel[subjectLevel][subjectLateral];
    let afterSubject = levelCoords[subjectLevel] + subjectEntry.thickness;
    let levelCnt = levelCoords.length;
    let level = subjectLevel;
    // skip past levels that are too high up
    for(; level < levelCnt && levelCoords[level] < afterSubject; level += 1); // do nothing
    for(; level < levelCnt; level += 1){
        let entries = entriesByLevel[level];
        let entry;
        let searchIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bB__as__binarySearch$3e$__["binarySearch"])(entries, subjectEntry.span.start, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bA__as__getEntrySpanEnd$3e$__["getEntrySpanEnd"]);
        let lateralStart = searchIndex[0] + searchIndex[1]; // if exact match (which doesn't collide), go to next one
        let lateralEnd = lateralStart;
        while((entry = entries[lateralEnd]) && // but not past the whole seg list
        entry.span.start < subjectEntry.span.end){
            lateralEnd += 1;
        }
        if (lateralStart < lateralEnd) {
            return {
                level,
                lateralStart,
                lateralEnd
            };
        }
    }
    return null;
}
function stretchWeb(topLevelNodes, totalThickness) {
    const stretchNode = cacheable((node, startCoord, prevThickness)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bz__as__buildEntryKey$3e$__["buildEntryKey"])(node), (node, startCoord, prevThickness)=>{
        let { nextLevelNodes, thickness } = node;
        let allThickness = thickness + prevThickness;
        let thicknessFraction = thickness / allThickness;
        let endCoord;
        let newChildren = [];
        if (!nextLevelNodes.length) {
            endCoord = totalThickness;
        } else {
            for (let childNode of nextLevelNodes){
                if (endCoord === undefined) {
                    let res = stretchNode(childNode, startCoord, allThickness);
                    endCoord = res[0];
                    newChildren.push(res[1]);
                } else {
                    let res = stretchNode(childNode, endCoord, 0);
                    newChildren.push(res[1]);
                }
            }
        }
        let newThickness = (endCoord - startCoord) * thicknessFraction;
        return [
            endCoord - newThickness,
            Object.assign(Object.assign({}, node), {
                thickness: newThickness,
                nextLevelNodes: newChildren
            })
        ];
    });
    return topLevelNodes.map((node)=>stretchNode(node, 0, 0)[1]);
}
// not sorted in any particular order
function webToRects(topLevelNodes) {
    let rects = [];
    const processNode = cacheable((node, levelCoord, stackDepth)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bz__as__buildEntryKey$3e$__["buildEntryKey"])(node), (node, levelCoord, stackDepth)=>{
        let rect = Object.assign(Object.assign({}, node), {
            levelCoord,
            stackDepth,
            stackForward: 0
        });
        rects.push(rect);
        return rect.stackForward = processNodes(node.nextLevelNodes, levelCoord + node.thickness, stackDepth + 1) + 1;
    });
    function processNodes(nodes, levelCoord, stackDepth) {
        let stackForward = 0;
        for (let node of nodes){
            stackForward = Math.max(processNode(node, levelCoord, stackDepth), stackForward);
        }
        return stackForward;
    }
    processNodes(topLevelNodes, 0, 0);
    return rects; // TODO: sort rects by levelCoord to be consistent with toRects?
}
// TODO: move to general util
function cacheable(keyFunc, workFunc) {
    const cache = {};
    return (...args)=>{
        let key = keyFunc(...args);
        return key in cache ? cache[key] : cache[key] = workFunc(...args);
    };
}
function computeSegVCoords(segs, colDate, slatCoords = null, eventMinHeight = 0) {
    let vcoords = [];
    if (slatCoords) {
        for(let i = 0; i < segs.length; i += 1){
            let seg = segs[i];
            let spanStart = slatCoords.computeDateTop(seg.start, colDate);
            let spanEnd = Math.max(spanStart + (eventMinHeight || 0), slatCoords.computeDateTop(seg.end, colDate));
            vcoords.push({
                start: Math.round(spanStart),
                end: Math.round(spanEnd)
            });
        }
    }
    return vcoords;
}
function computeFgSegPlacements(segs, segVCoords, eventOrderStrict, eventMaxStack) {
    let segInputs = [];
    let dumbSegs = []; // segs without coords
    for(let i = 0; i < segs.length; i += 1){
        let vcoords = segVCoords[i];
        if (vcoords) {
            segInputs.push({
                index: i,
                thickness: 1,
                span: vcoords
            });
        } else {
            dumbSegs.push(segs[i]);
        }
    }
    let { segRects, hiddenGroups } = buildPositioning(segInputs, eventOrderStrict, eventMaxStack);
    let segPlacements = [];
    for (let segRect of segRects){
        segPlacements.push({
            seg: segs[segRect.index],
            rect: segRect
        });
    }
    for (let dumbSeg of dumbSegs){
        segPlacements.push({
            seg: dumbSeg,
            rect: null
        });
    }
    return {
        segPlacements,
        hiddenGroups
    };
}
const DEFAULT_TIME_FORMAT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__["createFormatter"])({
    hour: 'numeric',
    minute: '2-digit',
    meridiem: false
});
class TimeColEvent extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    render() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cg__as__StandardEvent$3e$__["StandardEvent"], Object.assign({}, this.props, {
            elClasses: [
                'fc-timegrid-event',
                'fc-v-event',
                this.props.isShort && 'fc-timegrid-event-short'
            ],
            defaultTimeFormat: DEFAULT_TIME_FORMAT
        }));
    }
}
class TimeCol extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    constructor(){
        super(...arguments);
        this.sortEventSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bP__as__sortEventSegs$3e$__["sortEventSegs"]);
    }
    // TODO: memoize event-placement?
    render() {
        let { props, context } = this;
        let { options } = context;
        let isSelectMirror = options.selectMirror;
        let mirrorSegs = props.eventDrag && props.eventDrag.segs || props.eventResize && props.eventResize.segs || isSelectMirror && props.dateSelectionSegs || [];
        let interactionAffectedInstances = props.eventDrag && props.eventDrag.affectedInstances || props.eventResize && props.eventResize.affectedInstances || {};
        let sortedFgSegs = this.sortEventSegs(props.fgEventSegs, options.eventOrder);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ci__as__DayCellContainer$3e$__["DayCellContainer"], {
            elTag: "td",
            elRef: props.elRef,
            elClasses: [
                'fc-timegrid-col',
                ...props.extraClassNames || []
            ],
            elAttrs: Object.assign({
                role: 'gridcell'
            }, props.extraDataAttrs),
            date: props.date,
            dateProfile: props.dateProfile,
            todayRange: props.todayRange,
            extraRenderProps: props.extraRenderProps
        }, (InnerContent)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-timegrid-col-frame"
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-timegrid-col-bg"
            }, this.renderFillSegs(props.businessHourSegs, 'non-business'), this.renderFillSegs(props.bgEventSegs, 'bg-event'), this.renderFillSegs(props.dateSelectionSegs, 'highlight')), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-timegrid-col-events"
            }, this.renderFgSegs(sortedFgSegs, interactionAffectedInstances, false, false, false)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-timegrid-col-events"
            }, this.renderFgSegs(mirrorSegs, {}, Boolean(props.eventDrag), Boolean(props.eventResize), Boolean(isSelectMirror), 'mirror')), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: "fc-timegrid-now-indicator-container"
            }, this.renderNowIndicator(props.nowIndicatorSegs)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cj__as__hasCustomDayCellContent$3e$__["hasCustomDayCellContent"])(options) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(InnerContent, {
                elTag: "div",
                elClasses: [
                    'fc-timegrid-col-misc'
                ]
            })));
    }
    renderFgSegs(sortedFgSegs, segIsInvisible, isDragging, isResizing, isDateSelecting, forcedKey) {
        let { props } = this;
        if (props.forPrint) {
            return renderPlainFgSegs(sortedFgSegs, props);
        }
        return this.renderPositionedFgSegs(sortedFgSegs, segIsInvisible, isDragging, isResizing, isDateSelecting, forcedKey);
    }
    renderPositionedFgSegs(segs, segIsInvisible, isDragging, isResizing, isDateSelecting, forcedKey) {
        let { eventMaxStack, eventShortHeight, eventOrderStrict, eventMinHeight } = this.context.options;
        let { date, slatCoords, eventSelection, todayRange, nowDate } = this.props;
        let isMirror = isDragging || isResizing || isDateSelecting;
        let segVCoords = computeSegVCoords(segs, date, slatCoords, eventMinHeight);
        let { segPlacements, hiddenGroups } = computeFgSegPlacements(segs, segVCoords, eventOrderStrict, eventMaxStack);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, this.renderHiddenGroups(hiddenGroups, segs), segPlacements.map((segPlacement)=>{
            let { seg, rect } = segPlacement;
            let instanceId = seg.eventRange.instance.instanceId;
            let isVisible = isMirror || Boolean(!segIsInvisible[instanceId] && rect);
            let vStyle = computeSegVStyle(rect && rect.span);
            let hStyle = !isMirror && rect ? this.computeSegHStyle(rect) : {
                left: 0,
                right: 0
            };
            let isInset = Boolean(rect) && rect.stackForward > 0;
            let isShort = Boolean(rect) && rect.span.end - rect.span.start < eventShortHeight; // look at other places for this problem
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                className: 'fc-timegrid-event-harness' + (isInset ? ' fc-timegrid-event-harness-inset' : ''),
                key: forcedKey || instanceId,
                style: Object.assign(Object.assign({
                    visibility: isVisible ? '' : 'hidden'
                }, vStyle), hStyle)
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeColEvent, Object.assign({
                seg: seg,
                isDragging: isDragging,
                isResizing: isResizing,
                isDateSelecting: isDateSelecting,
                isSelected: instanceId === eventSelection,
                isShort: isShort
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__["getSegMeta"])(seg, todayRange, nowDate))));
        }));
    }
    // will already have eventMinHeight applied because segInputs already had it
    renderHiddenGroups(hiddenGroups, segs) {
        let { extraDateSpan, dateProfile, todayRange, nowDate, eventSelection, eventDrag, eventResize } = this.props;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, hiddenGroups.map((hiddenGroup)=>{
            let positionCss = computeSegVStyle(hiddenGroup.span);
            let hiddenSegs = compileSegsFromEntries(hiddenGroup.entries, segs);
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeColMoreLink, {
                key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bu__as__buildIsoString$3e$__["buildIsoString"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cp__as__computeEarliestSegStart$3e$__["computeEarliestSegStart"])(hiddenSegs)),
                hiddenSegs: hiddenSegs,
                top: positionCss.top,
                bottom: positionCss.bottom,
                extraDateSpan: extraDateSpan,
                dateProfile: dateProfile,
                todayRange: todayRange,
                nowDate: nowDate,
                eventSelection: eventSelection,
                eventDrag: eventDrag,
                eventResize: eventResize
            });
        }));
    }
    renderFillSegs(segs, fillType) {
        let { props, context } = this;
        let segVCoords = computeSegVCoords(segs, props.date, props.slatCoords, context.options.eventMinHeight); // don't assume all populated
        let children = segVCoords.map((vcoords, i)=>{
            let seg = segs[i];
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
                key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bR__as__buildEventRangeKey$3e$__["buildEventRangeKey"])(seg.eventRange),
                className: "fc-timegrid-bg-harness",
                style: computeSegVStyle(vcoords)
            }, fillType === 'bg-event' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cm__as__BgEvent$3e$__["BgEvent"], Object.assign({
                seg: seg
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__["getSegMeta"])(seg, props.todayRange, props.nowDate))) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cl__as__renderFill$3e$__["renderFill"])(fillType));
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, children);
    }
    renderNowIndicator(segs) {
        let { slatCoords, date } = this.props;
        if (!slatCoords) {
            return null;
        }
        return segs.map((seg, i)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ch__as__NowIndicatorContainer$3e$__["NowIndicatorContainer"], {
                // key doesn't matter. will only ever be one
                key: i,
                elClasses: [
                    'fc-timegrid-now-indicator-line'
                ],
                elStyle: {
                    top: slatCoords.computeDateTop(seg.start, date)
                },
                isAxis: false,
                date: date
            }));
    }
    computeSegHStyle(segHCoords) {
        let { isRtl, options } = this.context;
        let shouldOverlap = options.slotEventOverlap;
        let nearCoord = segHCoords.levelCoord; // the left side if LTR. the right side if RTL. floating-point
        let farCoord = segHCoords.levelCoord + segHCoords.thickness; // the right side if LTR. the left side if RTL. floating-point
        let left; // amount of space from left edge, a fraction of the total width
        let right; // amount of space from right edge, a fraction of the total width
        if (shouldOverlap) {
            // double the width, but don't go beyond the maximum forward coordinate (1.0)
            farCoord = Math.min(1, nearCoord + (farCoord - nearCoord) * 2);
        }
        if (isRtl) {
            left = 1 - farCoord;
            right = nearCoord;
        } else {
            left = nearCoord;
            right = 1 - farCoord;
        }
        let props = {
            zIndex: segHCoords.stackDepth + 1,
            left: left * 100 + '%',
            right: right * 100 + '%'
        };
        if (shouldOverlap && !segHCoords.stackForward) {
            // add padding to the edge so that forward stacked events don't cover the resizer's icon
            props[isRtl ? 'marginLeft' : 'marginRight'] = 10 * 2; // 10 is a guesstimate of the icon's width
        }
        return props;
    }
}
function renderPlainFgSegs(sortedFgSegs, { todayRange, nowDate, eventSelection, eventDrag, eventResize }) {
    let hiddenInstances = (eventDrag ? eventDrag.affectedInstances : null) || (eventResize ? eventResize.affectedInstances : null) || {};
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, sortedFgSegs.map((seg)=>{
        let instanceId = seg.eventRange.instance.instanceId;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
            key: instanceId,
            style: {
                visibility: hiddenInstances[instanceId] ? 'hidden' : ''
            }
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeColEvent, Object.assign({
            seg: seg,
            isDragging: false,
            isResizing: false,
            isDateSelecting: false,
            isSelected: instanceId === eventSelection,
            isShort: false
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__["getSegMeta"])(seg, todayRange, nowDate))));
    }));
}
function computeSegVStyle(segVCoords) {
    if (!segVCoords) {
        return {
            top: '',
            bottom: ''
        };
    }
    return {
        top: segVCoords.start,
        bottom: -segVCoords.end
    };
}
function compileSegsFromEntries(segEntries, allSegs) {
    return segEntries.map((segEntry)=>allSegs[segEntry.index]);
}
class TimeColsContent extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    constructor(){
        super(...arguments);
        this.splitFgEventSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitSegsByCol);
        this.splitBgEventSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitSegsByCol);
        this.splitBusinessHourSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitSegsByCol);
        this.splitNowIndicatorSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitSegsByCol);
        this.splitDateSelectionSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitSegsByCol);
        this.splitEventDrag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitInteractionByCol);
        this.splitEventResize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(splitInteractionByCol);
        this.rootElRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
        this.cellElRefs = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cd__as__RefMap$3e$__["RefMap"]();
    }
    render() {
        let { props, context } = this;
        let nowIndicatorTop = context.options.nowIndicator && props.slatCoords && props.slatCoords.safeComputeTop(props.nowDate); // might return void
        let colCnt = props.cells.length;
        let fgEventSegsByRow = this.splitFgEventSegs(props.fgEventSegs, colCnt);
        let bgEventSegsByRow = this.splitBgEventSegs(props.bgEventSegs, colCnt);
        let businessHourSegsByRow = this.splitBusinessHourSegs(props.businessHourSegs, colCnt);
        let nowIndicatorSegsByRow = this.splitNowIndicatorSegs(props.nowIndicatorSegs, colCnt);
        let dateSelectionSegsByRow = this.splitDateSelectionSegs(props.dateSelectionSegs, colCnt);
        let eventDragByRow = this.splitEventDrag(props.eventDrag, colCnt);
        let eventResizeByRow = this.splitEventResize(props.eventResize, colCnt);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
            className: "fc-timegrid-cols",
            ref: this.rootElRef
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("table", {
            role: "presentation",
            style: {
                minWidth: props.tableMinWidth,
                width: props.clientWidth
            }
        }, props.tableColGroupNode, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tbody", {
            role: "presentation"
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tr", {
            role: "row"
        }, props.axis && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("td", {
            "aria-hidden": true,
            className: "fc-timegrid-col fc-timegrid-axis"
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
            className: "fc-timegrid-col-frame"
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
            className: "fc-timegrid-now-indicator-container"
        }, typeof nowIndicatorTop === 'number' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ch__as__NowIndicatorContainer$3e$__["NowIndicatorContainer"], {
            elClasses: [
                'fc-timegrid-now-indicator-arrow'
            ],
            elStyle: {
                top: nowIndicatorTop
            },
            isAxis: true,
            date: props.nowDate
        })))), props.cells.map((cell, i)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeCol, {
                key: cell.key,
                elRef: this.cellElRefs.createRef(cell.key),
                dateProfile: props.dateProfile,
                date: cell.date,
                nowDate: props.nowDate,
                todayRange: props.todayRange,
                extraRenderProps: cell.extraRenderProps,
                extraDataAttrs: cell.extraDataAttrs,
                extraClassNames: cell.extraClassNames,
                extraDateSpan: cell.extraDateSpan,
                fgEventSegs: fgEventSegsByRow[i],
                bgEventSegs: bgEventSegsByRow[i],
                businessHourSegs: businessHourSegsByRow[i],
                nowIndicatorSegs: nowIndicatorSegsByRow[i],
                dateSelectionSegs: dateSelectionSegsByRow[i],
                eventDrag: eventDragByRow[i],
                eventResize: eventResizeByRow[i],
                slatCoords: props.slatCoords,
                eventSelection: props.eventSelection,
                forPrint: props.forPrint
            }))))));
    }
    componentDidMount() {
        this.updateCoords();
    }
    componentDidUpdate() {
        this.updateCoords();
    }
    updateCoords() {
        let { props } = this;
        if (props.onColCoords && props.clientWidth !== null // means sizing has stabilized
        ) {
            props.onColCoords(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__b8__as__PositionCache$3e$__["PositionCache"](this.rootElRef.current, collectCellEls(this.cellElRefs.currentMap, props.cells), true, false));
        }
    }
}
function collectCellEls(elMap, cells) {
    return cells.map((cell)=>elMap[cell.key]);
}
/* A component that renders one or more columns of vertical time slots
----------------------------------------------------------------------------------------------------------------------*/ class TimeCols extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.processSlotOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(processSlotOptions);
        this.state = {
            slatCoords: null
        };
        this.handleRootEl = (el)=>{
            if (el) {
                this.context.registerInteractiveComponent(this, {
                    el,
                    isHitComboAllowed: this.props.isHitComboAllowed
                });
            } else {
                this.context.unregisterInteractiveComponent(this);
            }
        };
        this.handleScrollRequest = (request)=>{
            let { onScrollTopRequest } = this.props;
            let { slatCoords } = this.state;
            if (onScrollTopRequest && slatCoords) {
                if (request.time) {
                    let top = slatCoords.computeTimeTop(request.time);
                    top = Math.ceil(top); // zoom can give weird floating-point values. rather scroll a little bit further
                    if (top) {
                        top += 1; // to overcome top border that slots beyond the first have. looks better
                    }
                    onScrollTopRequest(top);
                }
                return true;
            }
            return false;
        };
        this.handleColCoords = (colCoords)=>{
            this.colCoords = colCoords;
        };
        this.handleSlatCoords = (slatCoords)=>{
            this.setState({
                slatCoords
            });
            if (this.props.onSlatCoords) {
                this.props.onSlatCoords(slatCoords);
            }
        };
    }
    render() {
        let { props, state } = this;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("div", {
            className: "fc-timegrid-body",
            ref: this.handleRootEl,
            style: {
                // these props are important to give this wrapper correct dimensions for interactions
                // TODO: if we set it here, can we avoid giving to inner tables?
                width: props.clientWidth,
                minWidth: props.tableMinWidth
            }
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeColsSlats, {
            axis: props.axis,
            dateProfile: props.dateProfile,
            slatMetas: props.slatMetas,
            clientWidth: props.clientWidth,
            minHeight: props.expandRows ? props.clientHeight : '',
            tableMinWidth: props.tableMinWidth,
            tableColGroupNode: props.axis ? props.tableColGroupNode : null,
            onCoords: this.handleSlatCoords
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeColsContent, {
            cells: props.cells,
            axis: props.axis,
            dateProfile: props.dateProfile,
            businessHourSegs: props.businessHourSegs,
            bgEventSegs: props.bgEventSegs,
            fgEventSegs: props.fgEventSegs,
            dateSelectionSegs: props.dateSelectionSegs,
            eventSelection: props.eventSelection,
            eventDrag: props.eventDrag,
            eventResize: props.eventResize,
            todayRange: props.todayRange,
            nowDate: props.nowDate,
            nowIndicatorSegs: props.nowIndicatorSegs,
            clientWidth: props.clientWidth,
            tableMinWidth: props.tableMinWidth,
            tableColGroupNode: props.tableColGroupNode,
            slatCoords: state.slatCoords,
            onColCoords: this.handleColCoords,
            forPrint: props.forPrint
        }));
    }
    componentDidMount() {
        this.scrollResponder = this.context.createScrollResponder(this.handleScrollRequest);
    }
    componentDidUpdate(prevProps) {
        this.scrollResponder.update(prevProps.dateProfile !== this.props.dateProfile);
    }
    componentWillUnmount() {
        this.scrollResponder.detach();
    }
    queryHit(positionLeft, positionTop) {
        let { dateEnv, options } = this.context;
        let { colCoords } = this;
        let { dateProfile } = this.props;
        let { slatCoords } = this.state;
        let { snapDuration, snapsPerSlot } = this.processSlotOptions(this.props.slotDuration, options.snapDuration);
        let colIndex = colCoords.leftToIndex(positionLeft);
        let slatIndex = slatCoords.positions.topToIndex(positionTop);
        if (colIndex != null && slatIndex != null) {
            let cell = this.props.cells[colIndex];
            let slatTop = slatCoords.positions.tops[slatIndex];
            let slatHeight = slatCoords.positions.getHeight(slatIndex);
            let partial = (positionTop - slatTop) / slatHeight; // floating point number between 0 and 1
            let localSnapIndex = Math.floor(partial * snapsPerSlot); // the snap # relative to start of slat
            let snapIndex = slatIndex * snapsPerSlot + localSnapIndex;
            let dayDate = this.props.cells[colIndex].date;
            let time = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bn__as__addDurations$3e$__["addDurations"])(dateProfile.slotMinTime, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bm__as__multiplyDuration$3e$__["multiplyDuration"])(snapDuration, snapIndex));
            let start = dateEnv.add(dayDate, time);
            let end = dateEnv.add(start, snapDuration);
            return {
                dateProfile,
                dateSpan: Object.assign({
                    range: {
                        start,
                        end
                    },
                    allDay: false
                }, cell.extraDateSpan),
                dayEl: colCoords.els[colIndex],
                rect: {
                    left: colCoords.lefts[colIndex],
                    right: colCoords.rights[colIndex],
                    top: slatTop,
                    bottom: slatTop + slatHeight
                },
                layer: 0
            };
        }
        return null;
    }
}
function processSlotOptions(slotDuration, snapDurationOverride) {
    let snapDuration = snapDurationOverride || slotDuration;
    let snapsPerSlot = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__br__as__wholeDivideDurations$3e$__["wholeDivideDurations"])(slotDuration, snapDuration);
    if (snapsPerSlot === null) {
        snapDuration = slotDuration;
        snapsPerSlot = 1;
    // TODO: say warning?
    }
    return {
        snapDuration,
        snapsPerSlot
    };
}
class DayTimeColsSlicer extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bU__as__Slicer$3e$__["Slicer"] {
    sliceRange(range, dayRanges) {
        let segs = [];
        for(let col = 0; col < dayRanges.length; col += 1){
            let segRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__o__as__intersectRanges$3e$__["intersectRanges"])(range, dayRanges[col]);
            if (segRange) {
                segs.push({
                    start: segRange.start,
                    end: segRange.end,
                    isStart: segRange.start.valueOf() === range.start.valueOf(),
                    isEnd: segRange.end.valueOf() === range.end.valueOf(),
                    col
                });
            }
        }
        return segs;
    }
}
class DayTimeCols extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.buildDayRanges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(buildDayRanges);
        this.slicer = new DayTimeColsSlicer();
        this.timeColsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"])();
    }
    render() {
        let { props, context } = this;
        let { dateProfile, dayTableModel } = props;
        let { nowIndicator, nextDayThreshold } = context.options;
        let dayRanges = this.buildDayRanges(dayTableModel, dateProfile, context.dateEnv);
        // give it the first row of cells
        // TODO: would move this further down hierarchy, but sliceNowDate needs it
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a6__as__NowTimer$3e$__["NowTimer"], {
            unit: nowIndicator ? 'minute' : 'day'
        }, (nowDate, todayRange)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(TimeCols, Object.assign({
                ref: this.timeColsRef
            }, this.slicer.sliceProps(props, dateProfile, null, context, dayRanges), {
                forPrint: props.forPrint,
                axis: props.axis,
                dateProfile: dateProfile,
                slatMetas: props.slatMetas,
                slotDuration: props.slotDuration,
                cells: dayTableModel.cells[0],
                tableColGroupNode: props.tableColGroupNode,
                tableMinWidth: props.tableMinWidth,
                clientWidth: props.clientWidth,
                clientHeight: props.clientHeight,
                expandRows: props.expandRows,
                nowDate: nowDate,
                nowIndicatorSegs: nowIndicator && this.slicer.sliceNowDate(nowDate, dateProfile, nextDayThreshold, context, dayRanges),
                todayRange: todayRange,
                onScrollTopRequest: props.onScrollTopRequest,
                onSlatCoords: props.onSlatCoords
            })));
    }
}
function buildDayRanges(dayTableModel, dateProfile, dateEnv) {
    let ranges = [];
    for (let date of dayTableModel.headerDates){
        ranges.push({
            start: dateEnv.add(date, dateProfile.slotMinTime),
            end: dateEnv.add(date, dateProfile.slotMaxTime)
        });
    }
    return ranges;
}
// potential nice values for the slot-duration and interval-duration
// from largest to smallest
const STOCK_SUB_DURATIONS = [
    {
        hours: 1
    },
    {
        minutes: 30
    },
    {
        minutes: 15
    },
    {
        seconds: 30
    },
    {
        seconds: 15
    }
];
function buildSlatMetas(slotMinTime, slotMaxTime, explicitLabelInterval, slotDuration, dateEnv) {
    let dayStart = new Date(0);
    let slatTime = slotMinTime;
    let slatIterator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__createDuration$3e$__["createDuration"])(0);
    let labelInterval = explicitLabelInterval || computeLabelInterval(slotDuration);
    let metas = [];
    while((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bq__as__asRoughMs$3e$__["asRoughMs"])(slatTime) < (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bq__as__asRoughMs$3e$__["asRoughMs"])(slotMaxTime)){
        let date = dateEnv.add(dayStart, slatTime);
        let isLabeled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__br__as__wholeDivideDurations$3e$__["wholeDivideDurations"])(slatIterator, labelInterval) !== null;
        metas.push({
            date,
            time: slatTime,
            key: date.toISOString(),
            isoTimeStr: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bs__as__formatIsoTimeString$3e$__["formatIsoTimeString"])(date),
            isLabeled
        });
        slatTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bn__as__addDurations$3e$__["addDurations"])(slatTime, slotDuration);
        slatIterator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bn__as__addDurations$3e$__["addDurations"])(slatIterator, slotDuration);
    }
    return metas;
}
// Computes an automatic value for slotLabelInterval
function computeLabelInterval(slotDuration) {
    let i;
    let labelInterval;
    let slotsPerLabel;
    // find the smallest stock label interval that results in more than one slots-per-label
    for(i = STOCK_SUB_DURATIONS.length - 1; i >= 0; i -= 1){
        labelInterval = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__d__as__createDuration$3e$__["createDuration"])(STOCK_SUB_DURATIONS[i]);
        slotsPerLabel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__br__as__wholeDivideDurations$3e$__["wholeDivideDurations"])(labelInterval, slotDuration);
        if (slotsPerLabel !== null && slotsPerLabel > 1) {
            return labelInterval;
        }
    }
    return slotDuration; // fall back
}
class DayTimeColsView extends TimeColsView {
    constructor(){
        super(...arguments);
        this.buildTimeColsModel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(buildTimeColsModel);
        this.buildSlatMetas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(buildSlatMetas);
    }
    render() {
        let { options, dateEnv, dateProfileGenerator } = this.context;
        let { props } = this;
        let { dateProfile } = props;
        let dayTableModel = this.buildTimeColsModel(dateProfile, dateProfileGenerator);
        let splitProps = this.allDaySplitter.splitProps(props);
        let slatMetas = this.buildSlatMetas(dateProfile.slotMinTime, dateProfile.slotMaxTime, options.slotLabelInterval, options.slotDuration, dateEnv);
        let { dayMinWidth } = options;
        let hasAttachedAxis = !dayMinWidth;
        let hasDetachedAxis = dayMinWidth;
        let headerContent = options.dayHeaders && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bI__as__DayHeader$3e$__["DayHeader"], {
            dates: dayTableModel.headerDates,
            dateProfile: dateProfile,
            datesRepDistinctDays: true,
            renderIntro: hasAttachedAxis ? this.renderHeadAxis : null
        });
        let allDayContent = options.allDaySlot !== false && ((contentArg)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$daygrid$2f$internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DayTable"], Object.assign({}, splitProps.allDay, {
                dateProfile: dateProfile,
                dayTableModel: dayTableModel,
                nextDayThreshold: options.nextDayThreshold,
                tableMinWidth: contentArg.tableMinWidth,
                colGroupNode: contentArg.tableColGroupNode,
                renderRowIntro: hasAttachedAxis ? this.renderTableRowAxis : null,
                showWeekNumbers: false,
                expandRows: false,
                headerAlignElRef: this.headerElRef,
                clientWidth: contentArg.clientWidth,
                clientHeight: contentArg.clientHeight,
                forPrint: props.forPrint
            }, this.getAllDayMaxEventProps())));
        let timeGridContent = (contentArg)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(DayTimeCols, Object.assign({}, splitProps.timed, {
                dayTableModel: dayTableModel,
                dateProfile: dateProfile,
                axis: hasAttachedAxis,
                slotDuration: options.slotDuration,
                slatMetas: slatMetas,
                forPrint: props.forPrint,
                tableColGroupNode: contentArg.tableColGroupNode,
                tableMinWidth: contentArg.tableMinWidth,
                clientWidth: contentArg.clientWidth,
                clientHeight: contentArg.clientHeight,
                onSlatCoords: this.handleSlatCoords,
                expandRows: contentArg.expandRows,
                onScrollTopRequest: this.handleScrollTopRequest
            }));
        return hasDetachedAxis ? this.renderHScrollLayout(headerContent, allDayContent, timeGridContent, dayTableModel.colCnt, dayMinWidth, slatMetas, this.state.slatCoords) : this.renderSimpleLayout(headerContent, allDayContent, timeGridContent);
    }
}
function buildTimeColsModel(dateProfile, dateProfileGenerator) {
    let daySeries = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bM__as__DaySeriesModel$3e$__["DaySeriesModel"](dateProfile.renderRange, dateProfileGenerator);
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bT__as__DayTableModel$3e$__["DayTableModel"](daySeries, false);
}
var css_248z = ".fc-v-event{background-color:var(--fc-event-bg-color);border:1px solid var(--fc-event-border-color);display:block}.fc-v-event .fc-event-main{color:var(--fc-event-text-color);height:100%}.fc-v-event .fc-event-main-frame{display:flex;flex-direction:column;height:100%}.fc-v-event .fc-event-time{flex-grow:0;flex-shrink:0;max-height:100%;overflow:hidden}.fc-v-event .fc-event-title-container{flex-grow:1;flex-shrink:1;min-height:0}.fc-v-event .fc-event-title{bottom:0;max-height:100%;overflow:hidden;top:0}.fc-v-event:not(.fc-event-start){border-top-left-radius:0;border-top-right-radius:0;border-top-width:0}.fc-v-event:not(.fc-event-end){border-bottom-left-radius:0;border-bottom-right-radius:0;border-bottom-width:0}.fc-v-event.fc-event-selected:before{left:-10px;right:-10px}.fc-v-event .fc-event-resizer-start{cursor:n-resize}.fc-v-event .fc-event-resizer-end{cursor:s-resize}.fc-v-event:not(.fc-event-selected) .fc-event-resizer{height:var(--fc-event-resizer-thickness);left:0;right:0}.fc-v-event:not(.fc-event-selected) .fc-event-resizer-start{top:calc(var(--fc-event-resizer-thickness)/-2)}.fc-v-event:not(.fc-event-selected) .fc-event-resizer-end{bottom:calc(var(--fc-event-resizer-thickness)/-2)}.fc-v-event.fc-event-selected .fc-event-resizer{left:50%;margin-left:calc(var(--fc-event-resizer-dot-total-width)/-2)}.fc-v-event.fc-event-selected .fc-event-resizer-start{top:calc(var(--fc-event-resizer-dot-total-width)/-2)}.fc-v-event.fc-event-selected .fc-event-resizer-end{bottom:calc(var(--fc-event-resizer-dot-total-width)/-2)}.fc .fc-timegrid .fc-daygrid-body{z-index:2}.fc .fc-timegrid-divider{padding:0 0 2px}.fc .fc-timegrid-body{min-height:100%;position:relative;z-index:1}.fc .fc-timegrid-axis-chunk{position:relative}.fc .fc-timegrid-axis-chunk>table,.fc .fc-timegrid-slots{position:relative;z-index:1}.fc .fc-timegrid-slot{border-bottom:0;height:1.5em}.fc .fc-timegrid-slot:empty:before{content:\"\\00a0\"}.fc .fc-timegrid-slot-minor{border-top-style:dotted}.fc .fc-timegrid-slot-label-cushion{display:inline-block;white-space:nowrap}.fc .fc-timegrid-slot-label{vertical-align:middle}.fc .fc-timegrid-axis-cushion,.fc .fc-timegrid-slot-label-cushion{padding:0 4px}.fc .fc-timegrid-axis-frame-liquid{height:100%}.fc .fc-timegrid-axis-frame{align-items:center;display:flex;justify-content:flex-end;overflow:hidden}.fc .fc-timegrid-axis-cushion{flex-shrink:0;max-width:60px}.fc-direction-ltr .fc-timegrid-slot-label-frame{text-align:right}.fc-direction-rtl .fc-timegrid-slot-label-frame{text-align:left}.fc-liquid-hack .fc-timegrid-axis-frame-liquid{bottom:0;height:auto;left:0;position:absolute;right:0;top:0}.fc .fc-timegrid-col.fc-day-today{background-color:var(--fc-today-bg-color)}.fc .fc-timegrid-col-frame{min-height:100%;position:relative}.fc-media-screen.fc-liquid-hack .fc-timegrid-col-frame{bottom:0;height:auto;left:0;position:absolute;right:0;top:0}.fc-media-screen .fc-timegrid-cols{bottom:0;left:0;position:absolute;right:0;top:0}.fc-media-screen .fc-timegrid-cols>table{height:100%}.fc-media-screen .fc-timegrid-col-bg,.fc-media-screen .fc-timegrid-col-events,.fc-media-screen .fc-timegrid-now-indicator-container{left:0;position:absolute;right:0;top:0}.fc .fc-timegrid-col-bg{z-index:2}.fc .fc-timegrid-col-bg .fc-non-business{z-index:1}.fc .fc-timegrid-col-bg .fc-bg-event{z-index:2}.fc .fc-timegrid-col-bg .fc-highlight{z-index:3}.fc .fc-timegrid-bg-harness{left:0;position:absolute;right:0}.fc .fc-timegrid-col-events{z-index:3}.fc .fc-timegrid-now-indicator-container{bottom:0;overflow:hidden}.fc-direction-ltr .fc-timegrid-col-events{margin:0 2.5% 0 2px}.fc-direction-rtl .fc-timegrid-col-events{margin:0 2px 0 2.5%}.fc-timegrid-event-harness{position:absolute}.fc-timegrid-event-harness>.fc-timegrid-event{bottom:0;left:0;position:absolute;right:0;top:0}.fc-timegrid-event-harness-inset .fc-timegrid-event,.fc-timegrid-event.fc-event-mirror,.fc-timegrid-more-link{box-shadow:0 0 0 1px var(--fc-page-bg-color)}.fc-timegrid-event,.fc-timegrid-more-link{border-radius:3px;font-size:var(--fc-small-font-size)}.fc-timegrid-event{margin-bottom:1px}.fc-timegrid-event .fc-event-main{padding:1px 1px 0}.fc-timegrid-event .fc-event-time{font-size:var(--fc-small-font-size);margin-bottom:1px;white-space:nowrap}.fc-timegrid-event-short .fc-event-main-frame{flex-direction:row;overflow:hidden}.fc-timegrid-event-short .fc-event-time:after{content:\"\\00a0-\\00a0\"}.fc-timegrid-event-short .fc-event-title{font-size:var(--fc-small-font-size)}.fc-timegrid-more-link{background:var(--fc-more-link-bg-color);color:var(--fc-more-link-text-color);cursor:pointer;margin-bottom:1px;position:absolute;z-index:9999}.fc-timegrid-more-link-inner{padding:3px 2px;top:0}.fc-direction-ltr .fc-timegrid-more-link{right:0}.fc-direction-rtl .fc-timegrid-more-link{left:0}.fc .fc-timegrid-now-indicator-arrow,.fc .fc-timegrid-now-indicator-line{pointer-events:none}.fc .fc-timegrid-now-indicator-line{border-color:var(--fc-now-indicator-color);border-style:solid;border-width:1px 0 0;left:0;position:absolute;right:0;z-index:4}.fc .fc-timegrid-now-indicator-arrow{border-color:var(--fc-now-indicator-color);border-style:solid;margin-top:-5px;position:absolute;z-index:4}.fc-direction-ltr .fc-timegrid-now-indicator-arrow{border-bottom-color:transparent;border-top-color:transparent;border-width:5px 0 5px 6px;left:0}.fc-direction-rtl .fc-timegrid-now-indicator-arrow{border-bottom-color:transparent;border-top-color:transparent;border-width:5px 6px 5px 0;right:0}";
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ct__as__injectStyles$3e$__["injectStyles"])(css_248z);
;
}),
"[project]/node_modules/@fullcalendar/timegrid/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>index
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$timegrid$2f$internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/timegrid/internal.js [app-client] (ecmascript)");
;
;
;
;
;
const OPTION_REFINERS = {
    allDaySlot: Boolean
};
var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createPlugin"])({
    name: '@fullcalendar/timegrid',
    initialView: 'timeGridWeek',
    optionRefiners: OPTION_REFINERS,
    views: {
        timeGrid: {
            component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$timegrid$2f$internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DayTimeColsView"],
            usesMinMaxTime: true,
            allDaySlot: true,
            slotDuration: '00:30:00',
            slotEventOverlap: true
        },
        timeGridDay: {
            type: 'timeGrid',
            duration: {
                days: 1
            }
        },
        timeGridWeek: {
            type: 'timeGrid',
            duration: {
                weeks: 1
            }
        }
    }
});
;
}),
"[project]/node_modules/@fullcalendar/list/internal.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ListView",
    ()=>ListView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export B as BaseComponent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a3__as__getUniqueDomId$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export a3 as getUniqueDomId>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__aY__as__getDateMeta$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export aY as getDateMeta>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a___as__buildNavLinkAttrs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export a_ as buildNavLinkAttrs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__C__as__ContentContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export C as ContentContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__aX__as__getDayClassNames$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export aX as getDayClassNames>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bt__as__formatDayString$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bt as formatDayString>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export x as createFormatter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ck__as__EventContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ck as EventContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bS__as__getSegAnchorAttrs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bS as getSegAnchorAttrs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ax__as__isMultiDayRange$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ax as isMultiDayRange>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bO__as__buildSegTimeText$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bO as buildSegTimeText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bc as DateComponent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export z as memoize>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cq__as__ViewContainer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cq as ViewContainer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cb__as__Scroller$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export cb as Scroller>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a6__as__NowTimer$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export a6 as NowTimer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bP__as__sortEventSegs$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bP as sortEventSegs>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export bQ as getSegMeta>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ad__as__sliceEventStore$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ad as sliceEventStore>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__o__as__intersectRanges$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export o as intersectRanges>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__q__as__startOfDay$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export q as startOfDay>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__t__as__addDays$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export t as addDays>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ct__as__injectStyles$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export ct as injectStyles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/preact/dist/preact.module.js [app-client] (ecmascript)");
;
;
class ListViewHeaderRow extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    constructor(){
        super(...arguments);
        this.state = {
            textId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a3__as__getUniqueDomId$3e$__["getUniqueDomId"])()
        };
    }
    render() {
        let { theme, dateEnv, options, viewApi } = this.context;
        let { cellId, dayDate, todayRange } = this.props;
        let { textId } = this.state;
        let dayMeta = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__aY__as__getDateMeta$3e$__["getDateMeta"])(dayDate, todayRange);
        // will ever be falsy?
        let text = options.listDayFormat ? dateEnv.format(dayDate, options.listDayFormat) : '';
        // will ever be falsy? also, BAD NAME "alt"
        let sideText = options.listDaySideFormat ? dateEnv.format(dayDate, options.listDaySideFormat) : '';
        let renderProps = Object.assign({
            date: dateEnv.toDate(dayDate),
            view: viewApi,
            textId,
            text,
            sideText,
            navLinkAttrs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a___as__buildNavLinkAttrs$3e$__["buildNavLinkAttrs"])(this.context, dayDate),
            sideNavLinkAttrs: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a___as__buildNavLinkAttrs$3e$__["buildNavLinkAttrs"])(this.context, dayDate, 'day', false)
        }, dayMeta);
        // TODO: make a reusable HOC for dayHeader (used in daygrid/timegrid too)
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__C__as__ContentContainer$3e$__["ContentContainer"], {
            elTag: "tr",
            elClasses: [
                'fc-list-day',
                ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__aX__as__getDayClassNames$3e$__["getDayClassNames"])(dayMeta, theme)
            ],
            elAttrs: {
                'data-date': (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bt__as__formatDayString$3e$__["formatDayString"])(dayDate)
            },
            renderProps: renderProps,
            generatorName: "dayHeaderContent",
            customGenerator: options.dayHeaderContent,
            defaultGenerator: renderInnerContent,
            classNameGenerator: options.dayHeaderClassNames,
            didMount: options.dayHeaderDidMount,
            willUnmount: options.dayHeaderWillUnmount
        }, (InnerContent)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("th", {
                scope: "colgroup",
                colSpan: 3,
                id: cellId,
                "aria-labelledby": textId
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(InnerContent, {
                elTag: "div",
                elClasses: [
                    'fc-list-day-cushion',
                    theme.getClass('tableCellShaded')
                ]
            })));
    }
}
function renderInnerContent(props) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, props.text && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("a", Object.assign({
        id: props.textId,
        className: "fc-list-day-text"
    }, props.navLinkAttrs), props.text), props.sideText && /* not keyboard tabbable */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("a", Object.assign({
        "aria-hidden": true,
        className: "fc-list-day-side-text"
    }, props.sideNavLinkAttrs), props.sideText));
}
const DEFAULT_TIME_FORMAT = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__["createFormatter"])({
    hour: 'numeric',
    minute: '2-digit',
    meridiem: 'short'
});
class ListViewEventRow extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__B__as__BaseComponent$3e$__["BaseComponent"] {
    render() {
        let { props, context } = this;
        let { options } = context;
        let { seg, timeHeaderId, eventHeaderId, dateHeaderId } = props;
        let timeFormat = options.eventTimeFormat || DEFAULT_TIME_FORMAT;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ck__as__EventContainer$3e$__["EventContainer"], Object.assign({}, props, {
            elTag: "tr",
            elClasses: [
                'fc-list-event',
                seg.eventRange.def.url && 'fc-event-forced-url'
            ],
            defaultGenerator: ()=>renderEventInnerContent(seg, context),
            seg: seg,
            timeText: "",
            disableDragging: true,
            disableResizing: true
        }), (InnerContent, eventContentArg)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], null, buildTimeContent(seg, timeFormat, context, timeHeaderId, dateHeaderId), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("td", {
                "aria-hidden": true,
                className: "fc-list-event-graphic"
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("span", {
                className: "fc-list-event-dot",
                style: {
                    borderColor: eventContentArg.borderColor || eventContentArg.backgroundColor
                }
            })), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(InnerContent, {
                elTag: "td",
                elClasses: [
                    'fc-list-event-title'
                ],
                elAttrs: {
                    headers: `${eventHeaderId} ${dateHeaderId}`
                }
            })));
    }
}
function renderEventInnerContent(seg, context) {
    let interactiveAttrs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bS__as__getSegAnchorAttrs$3e$__["getSegAnchorAttrs"])(seg, context);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("a", Object.assign({}, interactiveAttrs), seg.eventRange.def.title);
}
function buildTimeContent(seg, timeFormat, context, timeHeaderId, dateHeaderId) {
    let { options } = context;
    if (options.displayEventTime !== false) {
        let eventDef = seg.eventRange.def;
        let eventInstance = seg.eventRange.instance;
        let doAllDay = false;
        let timeText;
        if (eventDef.allDay) {
            doAllDay = true;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ax__as__isMultiDayRange$3e$__["isMultiDayRange"])(seg.eventRange.range)) {
            if (seg.isStart) {
                timeText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bO__as__buildSegTimeText$3e$__["buildSegTimeText"])(seg, timeFormat, context, null, null, eventInstance.range.start, seg.end);
            } else if (seg.isEnd) {
                timeText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bO__as__buildSegTimeText$3e$__["buildSegTimeText"])(seg, timeFormat, context, null, null, seg.start, eventInstance.range.end);
            } else {
                doAllDay = true;
            }
        } else {
            timeText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bO__as__buildSegTimeText$3e$__["buildSegTimeText"])(seg, timeFormat, context);
        }
        if (doAllDay) {
            let renderProps = {
                text: context.options.allDayText,
                view: context.viewApi
            };
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__C__as__ContentContainer$3e$__["ContentContainer"], {
                elTag: "td",
                elClasses: [
                    'fc-list-event-time'
                ],
                elAttrs: {
                    headers: `${timeHeaderId} ${dateHeaderId}`
                },
                renderProps: renderProps,
                generatorName: "allDayContent",
                customGenerator: options.allDayContent,
                defaultGenerator: renderAllDayInner,
                classNameGenerator: options.allDayClassNames,
                didMount: options.allDayDidMount,
                willUnmount: options.allDayWillUnmount
            });
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("td", {
            className: "fc-list-event-time"
        }, timeText);
    }
    return null;
}
function renderAllDayInner(renderProps) {
    return renderProps.text;
}
/*
Responsible for the scroller, and forwarding event-related actions into the "grid".
*/ class ListView extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bc__as__DateComponent$3e$__["DateComponent"] {
    constructor(){
        super(...arguments);
        this.computeDateVars = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(computeDateVars);
        this.eventStoreToSegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__z__as__memoize$3e$__["memoize"])(this._eventStoreToSegs);
        this.state = {
            timeHeaderId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a3__as__getUniqueDomId$3e$__["getUniqueDomId"])(),
            eventHeaderId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a3__as__getUniqueDomId$3e$__["getUniqueDomId"])(),
            dateHeaderIdRoot: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a3__as__getUniqueDomId$3e$__["getUniqueDomId"])()
        };
        this.setRootEl = (rootEl)=>{
            if (rootEl) {
                this.context.registerInteractiveComponent(this, {
                    el: rootEl
                });
            } else {
                this.context.unregisterInteractiveComponent(this);
            }
        };
    }
    render() {
        let { props, context } = this;
        let { dayDates, dayRanges } = this.computeDateVars(props.dateProfile);
        let eventSegs = this.eventStoreToSegs(props.eventStore, props.eventUiBases, dayRanges);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cq__as__ViewContainer$3e$__["ViewContainer"], {
            elRef: this.setRootEl,
            elClasses: [
                'fc-list',
                context.theme.getClass('table'),
                context.options.stickyHeaderDates !== false ? 'fc-list-sticky' : ''
            ],
            viewSpec: context.viewSpec
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__cb__as__Scroller$3e$__["Scroller"], {
            liquid: !props.isHeightAuto,
            overflowX: props.isHeightAuto ? 'visible' : 'hidden',
            overflowY: props.isHeightAuto ? 'visible' : 'auto'
        }, eventSegs.length > 0 ? this.renderSegList(eventSegs, dayDates) : this.renderEmptyMessage()));
    }
    renderEmptyMessage() {
        let { options, viewApi } = this.context;
        let renderProps = {
            text: options.noEventsText,
            view: viewApi
        };
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__C__as__ContentContainer$3e$__["ContentContainer"], {
            elTag: "div",
            elClasses: [
                'fc-list-empty'
            ],
            renderProps: renderProps,
            generatorName: "noEventsContent",
            customGenerator: options.noEventsContent,
            defaultGenerator: renderNoEventsInner,
            classNameGenerator: options.noEventsClassNames,
            didMount: options.noEventsDidMount,
            willUnmount: options.noEventsWillUnmount
        }, (InnerContent)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(InnerContent, {
                elTag: "div",
                elClasses: [
                    'fc-list-empty-cushion'
                ]
            }));
    }
    renderSegList(allSegs, dayDates) {
        let { theme, options } = this.context;
        let { timeHeaderId, eventHeaderId, dateHeaderIdRoot } = this.state;
        let segsByDay = groupSegsByDay(allSegs); // sparse array
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__a6__as__NowTimer$3e$__["NowTimer"], {
            unit: "day"
        }, (nowDate, todayRange)=>{
            let innerNodes = [];
            for(let dayIndex = 0; dayIndex < segsByDay.length; dayIndex += 1){
                let daySegs = segsByDay[dayIndex];
                if (daySegs) {
                    let dayStr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bt__as__formatDayString$3e$__["formatDayString"])(dayDates[dayIndex]);
                    let dateHeaderId = dateHeaderIdRoot + '-' + dayStr;
                    // append a day header
                    innerNodes.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(ListViewHeaderRow, {
                        key: dayStr,
                        cellId: dateHeaderId,
                        dayDate: dayDates[dayIndex],
                        todayRange: todayRange
                    }));
                    daySegs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bP__as__sortEventSegs$3e$__["sortEventSegs"])(daySegs, options.eventOrder);
                    for (let seg of daySegs){
                        innerNodes.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])(ListViewEventRow, Object.assign({
                            key: dayStr + ':' + seg.eventRange.instance.instanceId /* are multiple segs for an instanceId */ ,
                            seg: seg,
                            isDragging: false,
                            isResizing: false,
                            isDateSelecting: false,
                            isSelected: false,
                            timeHeaderId: timeHeaderId,
                            eventHeaderId: eventHeaderId,
                            dateHeaderId: dateHeaderId
                        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__bQ__as__getSegMeta$3e$__["getSegMeta"])(seg, todayRange, nowDate))));
                    }
                }
            }
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("table", {
                className: 'fc-list-table ' + theme.getClass('table')
            }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("thead", null, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tr", null, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("th", {
                scope: "col",
                id: timeHeaderId
            }, options.timeHint), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("th", {
                scope: "col",
                "aria-hidden": true
            }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("th", {
                scope: "col",
                id: eventHeaderId
            }, options.eventHint))), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$preact$2f$dist$2f$preact$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("tbody", null, innerNodes));
        });
    }
    _eventStoreToSegs(eventStore, eventUiBases, dayRanges) {
        return this.eventRangesToSegs((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ad__as__sliceEventStore$3e$__["sliceEventStore"])(eventStore, eventUiBases, this.props.dateProfile.activeRange, this.context.options.nextDayThreshold).fg, dayRanges);
    }
    eventRangesToSegs(eventRanges, dayRanges) {
        let segs = [];
        for (let eventRange of eventRanges){
            segs.push(...this.eventRangeToSegs(eventRange, dayRanges));
        }
        return segs;
    }
    eventRangeToSegs(eventRange, dayRanges) {
        let { dateEnv } = this.context;
        let { nextDayThreshold } = this.context.options;
        let range = eventRange.range;
        let allDay = eventRange.def.allDay;
        let dayIndex;
        let segRange;
        let seg;
        let segs = [];
        for(dayIndex = 0; dayIndex < dayRanges.length; dayIndex += 1){
            segRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__o__as__intersectRanges$3e$__["intersectRanges"])(range, dayRanges[dayIndex]);
            if (segRange) {
                seg = {
                    component: this,
                    eventRange,
                    start: segRange.start,
                    end: segRange.end,
                    isStart: eventRange.isStart && segRange.start.valueOf() === range.start.valueOf(),
                    isEnd: eventRange.isEnd && segRange.end.valueOf() === range.end.valueOf(),
                    dayIndex
                };
                segs.push(seg);
                // detect when range won't go fully into the next day,
                // and mutate the latest seg to the be the end.
                if (!seg.isEnd && !allDay && dayIndex + 1 < dayRanges.length && range.end < dateEnv.add(dayRanges[dayIndex + 1].start, nextDayThreshold)) {
                    seg.end = range.end;
                    seg.isEnd = true;
                    break;
                }
            }
        }
        return segs;
    }
}
function renderNoEventsInner(renderProps) {
    return renderProps.text;
}
function computeDateVars(dateProfile) {
    let dayStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__q__as__startOfDay$3e$__["startOfDay"])(dateProfile.renderRange.start);
    let viewEnd = dateProfile.renderRange.end;
    let dayDates = [];
    let dayRanges = [];
    while(dayStart < viewEnd){
        dayDates.push(dayStart);
        dayRanges.push({
            start: dayStart,
            end: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__t__as__addDays$3e$__["addDays"])(dayStart, 1)
        });
        dayStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__t__as__addDays$3e$__["addDays"])(dayStart, 1);
    }
    return {
        dayDates,
        dayRanges
    };
}
// Returns a sparse array of arrays, segs grouped by their dayIndex
function groupSegsByDay(segs) {
    let segsByDay = []; // sparse array
    let i;
    let seg;
    for(i = 0; i < segs.length; i += 1){
        seg = segs[i];
        (segsByDay[seg.dayIndex] || (segsByDay[seg.dayIndex] = [])).push(seg);
    }
    return segsByDay;
}
var css_248z = ":root{--fc-list-event-dot-width:10px;--fc-list-event-hover-bg-color:#f5f5f5}.fc-theme-standard .fc-list{border:1px solid var(--fc-border-color)}.fc .fc-list-empty{align-items:center;background-color:var(--fc-neutral-bg-color);display:flex;height:100%;justify-content:center}.fc .fc-list-empty-cushion{margin:5em 0}.fc .fc-list-table{border-style:hidden;width:100%}.fc .fc-list-table tr>*{border-left:0;border-right:0}.fc .fc-list-sticky .fc-list-day>*{background:var(--fc-page-bg-color);position:sticky;top:0}.fc .fc-list-table thead{left:-10000px;position:absolute}.fc .fc-list-table tbody>tr:first-child th{border-top:0}.fc .fc-list-table th{padding:0}.fc .fc-list-day-cushion,.fc .fc-list-table td{padding:8px 14px}.fc .fc-list-day-cushion:after{clear:both;content:\"\";display:table}.fc-theme-standard .fc-list-day-cushion{background-color:var(--fc-neutral-bg-color)}.fc-direction-ltr .fc-list-day-text,.fc-direction-rtl .fc-list-day-side-text{float:left}.fc-direction-ltr .fc-list-day-side-text,.fc-direction-rtl .fc-list-day-text{float:right}.fc-direction-ltr .fc-list-table .fc-list-event-graphic{padding-right:0}.fc-direction-rtl .fc-list-table .fc-list-event-graphic{padding-left:0}.fc .fc-list-event.fc-event-forced-url{cursor:pointer}.fc .fc-list-event:hover td{background-color:var(--fc-list-event-hover-bg-color)}.fc .fc-list-event-graphic,.fc .fc-list-event-time{white-space:nowrap;width:1px}.fc .fc-list-event-dot{border:calc(var(--fc-list-event-dot-width)/2) solid var(--fc-event-border-color);border-radius:calc(var(--fc-list-event-dot-width)/2);box-sizing:content-box;display:inline-block;height:0;width:0}.fc .fc-list-event-title a{color:inherit;text-decoration:none}.fc .fc-list-event.fc-event-forced-url:hover a{text-decoration:underline}";
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ct__as__injectStyles$3e$__["injectStyles"])(css_248z);
;
}),
"[project]/node_modules/@fullcalendar/list/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>index
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$list$2f$internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/list/internal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__identity$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export n as identity>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__ = __turbopack_context__.i("[project]/node_modules/@fullcalendar/core/internal-common.js [app-client] (ecmascript) <export x as createFormatter>");
;
;
;
;
const OPTION_REFINERS = {
    listDayFormat: createFalsableFormatter,
    listDaySideFormat: createFalsableFormatter,
    noEventsClassNames: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__identity$3e$__["identity"],
    noEventsContent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__identity$3e$__["identity"],
    noEventsDidMount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__identity$3e$__["identity"],
    noEventsWillUnmount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__n__as__identity$3e$__["identity"]
};
function createFalsableFormatter(input) {
    return input === false ? null : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$internal$2d$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__x__as__createFormatter$3e$__["createFormatter"])(input);
}
var index = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$core$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createPlugin"])({
    name: '@fullcalendar/list',
    optionRefiners: OPTION_REFINERS,
    views: {
        list: {
            component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fullcalendar$2f$list$2f$internal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ListView"],
            buttonTextKey: 'list',
            listDayFormat: {
                month: 'long',
                day: 'numeric',
                year: 'numeric'
            }
        },
        listDay: {
            type: 'list',
            duration: {
                days: 1
            },
            listDayFormat: {
                weekday: 'long'
            }
        },
        listWeek: {
            type: 'list',
            duration: {
                weeks: 1
            },
            listDayFormat: {
                weekday: 'long'
            },
            listDaySideFormat: {
                month: 'long',
                day: 'numeric',
                year: 'numeric'
            }
        },
        listMonth: {
            type: 'list',
            duration: {
                month: 1
            },
            listDaySideFormat: {
                weekday: 'long'
            }
        },
        listYear: {
            type: 'list',
            duration: {
                year: 1
            },
            listDaySideFormat: {
                weekday: 'long'
            }
        }
    }
});
;
}),
]);

//# sourceMappingURL=node_modules_0wuvfkc._.js.map