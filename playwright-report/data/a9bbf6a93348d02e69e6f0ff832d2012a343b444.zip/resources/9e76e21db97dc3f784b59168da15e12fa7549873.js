(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_recharts_es6_util_0e~a.sq._.js","static/chunks/node_modules_recharts_es6_state_0ll4lpv._.js","static/chunks/node_modules_recharts_es6_component_0ogcxsx._.js","static/chunks/node_modules_recharts_es6_cartesian_0x8000w._.js","static/chunks/node_modules_recharts_es6_0f6rsum._.js","static/chunks/node_modules_0.9ts5p._.js","static/chunks/src_11ud.0n._.js"],
    source: "dynamic"
});
