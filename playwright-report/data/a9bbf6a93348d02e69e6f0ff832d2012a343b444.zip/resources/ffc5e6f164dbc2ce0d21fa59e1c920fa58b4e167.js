(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__02nfq85._.css","static/chunks/node_modules_sonner_dist_index_mjs_0cj4pkc._.js","static/chunks/node_modules_next_dist_0hdnf-1._.js","static/chunks/node_modules_@firebase_auth_dist_esm_0wcr-pn._.js","static/chunks/node_modules_@firebase_firestore_dist_10i8a8v._.js","static/chunks/node_modules_@firebase_storage_dist_index_esm_005w5vr.js","static/chunks/node_modules_0emkru7._.js","static/chunks/src_0ed83gy._.js"],
    source: "dynamic"
});
