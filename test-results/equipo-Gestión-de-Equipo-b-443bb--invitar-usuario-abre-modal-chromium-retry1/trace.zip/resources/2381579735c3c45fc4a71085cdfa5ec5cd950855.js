(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0tm1~3x._.js","static/chunks/node_modules_0x-55n_._.js"],
    source: "dynamic"
});
