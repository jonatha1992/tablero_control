(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/driver.js/dist/driver.js.mjs [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_driver_js_dist_driver_js_mjs_115nthh._.js",
  "static/chunks/node_modules_driver_js_dist_driver_js_mjs_0efnw_f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/driver.js/dist/driver.js.mjs [app-client] (ecmascript)");
    });
});
}),
]);