(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_driver_js_dist_driver_js_mjs_0w2jk75._.js","static/chunks/src_07bs~a7._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_next_0djrnzx._.js","static/chunks/node_modules_01j8olk._.js","static/chunks/node_modules_driver_js_dist_driver_0qcqqq~.css"],
    source: "dynamic"
});
